module github.com/ncruces/go-sqlite3-wasm/v6

go 1.26.0

tool (
	github.com/ncruces/wasm2go
	github.com/ncruces/wasm2go/libc-gen
)

require (
	github.com/ncruces/wasm2go v0.4.20 // indirect
	golang.org/x/tools v0.52.0 // indirect
)
