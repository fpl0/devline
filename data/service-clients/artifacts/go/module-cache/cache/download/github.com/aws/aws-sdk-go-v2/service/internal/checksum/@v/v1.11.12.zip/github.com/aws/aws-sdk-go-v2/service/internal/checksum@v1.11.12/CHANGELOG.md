# v1.11.12 (2026-11-06)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.11.11 (2026-11-05)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.11.10 (2026-11-04)

* **Dependency Update**: Update to smithy-go v1.28.8.
* **Dependency Update**: Updated to the latest SDK module versions

# v1.11.9 (2026-10-27)

* **Dependency Update**: Update to smithy-go v1.28.7.
* **Dependency Update**: Updated to the latest SDK module versions

# v1.11.8 (2026-10-22)

* **Bug Fix**: Update smithy-go to v1.28.6
* **Dependency Update**: Updated to the latest SDK module versions

# v1.11.7 (2026-10-09.2)

* **Dependency Update**: Update to smithy-go v1.28.5.
* **Dependency Update**: Updated to the latest SDK module versions

# v1.11.6 (2026-10-08)

* **Dependency Update**: Update to smithy-go v1.28.4.
* **Dependency Update**: Updated to the latest SDK module versions

# v1.11.5 (2026-09-24)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.11.4 (2026-09-23)

* **Bug Fix**: Checksum non-200 http responses

# v1.11.3 (2026-09-09)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.11.2 (2026-09-04)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.11.1 (2026-08-28)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.11.0 (2026-08-27)

* **Feature**: Support connection read timeouts in the SDK. This is currently available on an opt-in basis by setting env `AWS_ENABLE_DEFAULT_SOCKET_TIMEOUT_2026=true`.
* **Dependency Update**: Updated to the latest SDK module versions

# v1.10.0 (2026-08-26)

* **Feature**: Stop registering the `ComputeContentLength` middleware in generated clients. `Content-Length` is now set when the request body is set via `SetStream`.
* **Dependency Update**: Update to smithy-go v1.28.0.
* **Dependency Update**: Updated to the latest SDK module versions

# v1.9.32 (2026-08-25)

* **Dependency Update**: Update to smithy-go v1.27.10.
* **Dependency Update**: Updated to the latest SDK module versions

# v1.9.31 (2026-08-20)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.9.30 (2026-08-14)

* **Dependency Update**: Update to smithy-go v1.27.8.
* **Dependency Update**: Updated to the latest SDK module versions

# v1.9.29 (2026-08-10)

* **Dependency Update**: Update to smithy-go v1.27.7.
* **Dependency Update**: Updated to the latest SDK module versions

# v1.9.28 (2026-08-05)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.9.27 (2026-07-31.2)

* **Dependency Update**: Updated to the latest SDK module versions
* **Dependency Update**: Upgrade to smithy-go v1.27.6 to fix various serde issues in HTTP binding services.

# v1.9.26 (2026-07-29)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.9.25 (2026-07-28)

* **Dependency Update**: Update to smithy-go v1.27.5.
* **Dependency Update**: Updated to the latest SDK module versions

# v1.9.24 (2026-07-21)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.9.23 (2026-07-01)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.9.22 (2026-06-08)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.9.21 (2026-06-04)

* **Dependency Update**: Update to smithy-go v1.27.1 to fix several union-related deserialization bugs in schema-serde-enabled services.
* **Dependency Update**: Updated to the latest SDK module versions

# v1.9.20 (2026-06-03)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.9.19 (2026-06-02)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.9.18 (2026-05-29)

* **Dependency Update**: Update to smithy-go v1.26.0.
* **Dependency Update**: Updated to the latest SDK module versions

# v1.9.17 (2026-05-28)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.9.16 (2026-05-27)

* No change notes available for this release.

# v1.9.15 (2026-04-29)

* **Dependency Update**: Update to smithy-go v1.25.1.
* **Dependency Update**: Updated to the latest SDK module versions

# v1.9.14 (2026-04-17)

* **Dependency Update**: Bump smithy-go to 1.25.0 to support endpointBdd trait
* **Dependency Update**: Updated to the latest SDK module versions

# v1.9.13 (2026-03-26)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.9.12 (2026-03-13)

* **Bug Fix**: Replace usages of the old ioutil/ package throughout the SDK.
* **Dependency Update**: Updated to the latest SDK module versions

# v1.9.11 (2026-03-03)

* **Bug Fix**: Modernize non codegen files with go fix
* **Dependency Update**: Bump minimum Go version to 1.24
* **Dependency Update**: Updated to the latest SDK module versions

# v1.9.10 (2026-02-26)

* **Bug Fix**: Allow sending unkown checksum values if the value is precalculated on the input request

# v1.9.9 (2026-02-23)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.9.8 (2026-01-09)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.9.7 (2025-12-08)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.9.6 (2025-12-02)

* **Dependency Update**: Updated to the latest SDK module versions
* **Dependency Update**: Upgrade to smithy-go v1.24.0. Notably this version of the library reduces the allocation footprint of the middleware system. We observe a ~10% reduction in allocations per SDK call with this change.

# v1.9.5 (2025-11-19.2)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.9.4 (2025-11-04)

* **Dependency Update**: Updated to the latest SDK module versions
* **Dependency Update**: Upgrade to smithy-go v1.23.2 which should convey some passive reduction of overall allocations, especially when not using the metrics system.

# v1.9.3 (2025-10-30)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.9.2 (2025-10-23)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.9.1 (2025-10-16)

* **Dependency Update**: Bump minimum Go version to 1.23.
* **Dependency Update**: Updated to the latest SDK module versions

# v1.9.0 (2025-10-07)

* **Feature**: Cache first calculated checksum and reuse it in retry, this feature avoids checksum re-calculation and enables request payload consistency check among attempts.

# v1.8.9 (2025-09-26)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.8.8 (2025-09-23)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.8.7 (2025-09-08)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.8.6 (2025-08-29)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.8.5 (2025-08-27)

* **Dependency Update**: Update to smithy-go v1.23.0.
* **Dependency Update**: Updated to the latest SDK module versions

# v1.8.4 (2025-08-21)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.8.3 (2025-08-11)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.8.2 (2025-08-04)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.8.1 (2025-07-30)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.8.0 (2025-07-28)

* **Feature**: Add support for HTTP interceptors.
* **Dependency Update**: Updated to the latest SDK module versions

# v1.7.5 (2025-07-19)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.7.4 (2025-06-17)

* **Dependency Update**: Update to smithy-go v1.22.4.
* **Dependency Update**: Updated to the latest SDK module versions

# v1.7.3 (2025-06-10)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.7.2 (2025-05-22)

* **Bug Fix**: Handle checksum for unseekable body with 0 content length

# v1.7.1 (2025-04-28)

* **Bug Fix**: Don't emit warnings about lack of checksum validation for non-200 responses.

# v1.7.0 (2025-03-11)

* **Feature**: Add extra check during output checksum validation so the validation skip warning would not be logged if object is not fetched from s3

# v1.6.2 (2025-02-27)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.6.1 (2025-02-18)

* **Bug Fix**: Bump go version to 1.22
* **Dependency Update**: Updated to the latest SDK module versions

# v1.6.0 (2025-02-10)

* **Feature**: Support CRC64NVME flex checksums.

# v1.5.6 (2025-02-05)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.5.5 (2025-01-31)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.5.4 (2025-01-30)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.5.3 (2025-01-24)

* **Bug Fix**: Enable request checksum validation mode by default
* **Dependency Update**: Updated to the latest SDK module versions
* **Dependency Update**: Upgrade to smithy-go v1.22.2.

# v1.5.2 (2025-01-17)

* **Bug Fix**: Fix bug where credentials weren't refreshed during retry loop.

# v1.5.1 (2025-01-16)

* **Bug Fix**: Fix nil dereference panic for operations that require checksums, but do not have an input setting for which algorithm to use.

# v1.5.0 (2025-01-15)

* **Feature**: S3 client behavior is updated to always calculate a checksum by default for operations that support it (such as PutObject or UploadPart), or require it (such as DeleteObjects). The checksum algorithm used by default now becomes CRC32. Checksum behavior can be configured using `when_supported` and `when_required` options - in code using RequestChecksumCalculation, in shared config using request_checksum_calculation, or as env variable using AWS_REQUEST_CHECKSUM_CALCULATION. The S3 client attempts to validate response checksums for all S3 API operations that support checksums. However, if the SDK has not implemented the specified checksum algorithm then this validation is skipped. Checksum validation behavior can be configured using `when_supported` and `when_required` options - in code using ResponseChecksumValidation, in shared config using response_checksum_validation, or as env variable using AWS_RESPONSE_CHECKSUM_VALIDATION.
* **Dependency Update**: Updated to the latest SDK module versions

# v1.4.8 (2025-01-09)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.4.7 (2024-12-19)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.4.6 (2024-12-02)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.4.5 (2024-11-18)

* **Dependency Update**: Update to smithy-go v1.22.1.
* **Dependency Update**: Updated to the latest SDK module versions

# v1.4.4 (2024-11-06)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.4.3 (2024-10-28)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.4.2 (2024-10-08)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.4.1 (2024-10-07)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.4.0 (2024-10-04)

* **Feature**: Add support for HTTP client metrics.
* **Dependency Update**: Updated to the latest SDK module versions

# v1.3.20 (2024-09-20)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.3.19 (2024-09-03)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.3.18 (2024-08-15)

* **Dependency Update**: Bump minimum Go version to 1.21.
* **Dependency Update**: Updated to the latest SDK module versions

# v1.3.17 (2024-07-10.2)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.3.16 (2024-07-10)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.3.15 (2024-06-28)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.3.14 (2024-06-19)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.3.13 (2024-06-18)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.3.12 (2024-06-17)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.3.11 (2024-06-07)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.3.10 (2024-06-03)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.3.9 (2024-05-16)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.3.8 (2024-05-15)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.3.7 (2024-03-29)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.3.6 (2024-03-18)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.3.5 (2024-03-07)

* **Bug Fix**: Remove dependency on go-cmp.
* **Dependency Update**: Updated to the latest SDK module versions

# v1.3.4 (2024-03-05)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.3.3 (2024-03-04)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.3.2 (2024-02-23)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.3.1 (2024-02-21)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.3.0 (2024-02-13)

* **Feature**: Bump minimum Go version to 1.20 per our language support policy.
* **Dependency Update**: Updated to the latest SDK module versions

# v1.2.10 (2024-01-04)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.2.9 (2023-12-07)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.2.8 (2023-12-01)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.2.7 (2023-11-30)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.2.6 (2023-11-29)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.2.5 (2023-11-28.2)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.2.4 (2023-11-20)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.2.3 (2023-11-15)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.2.2 (2023-11-09)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.2.1 (2023-11-01)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.2.0 (2023-10-31)

* **Feature**: **BREAKING CHANGE**: Bump minimum go version to 1.19 per the revised [go version support policy](https://aws.amazon.com/blogs/developer/aws-sdk-for-go-aligns-with-go-release-policy-on-supported-runtimes/).
* **Dependency Update**: Updated to the latest SDK module versions

# v1.1.38 (2023-10-12)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.1.37 (2023-10-06)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.1.36 (2023-08-21)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.1.35 (2023-08-18)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.1.34 (2023-08-17)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.1.33 (2023-08-07)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.1.32 (2023-07-31)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.1.31 (2023-07-28)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.1.30 (2023-07-13)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.1.29 (2023-06-13)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.1.28 (2023-04-24)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.1.27 (2023-04-07)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.1.26 (2023-03-21)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.1.25 (2023-03-10)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.1.24 (2023-02-20)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.1.23 (2023-02-03)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.1.22 (2022-12-15)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.1.21 (2022-12-02)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.1.20 (2022-10-24)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.1.19 (2022-10-21)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.1.18 (2022-09-20)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.1.17 (2022-09-14)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.1.16 (2022-09-02)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.1.15 (2022-08-31)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.1.14 (2022-08-29)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.1.13 (2022-08-11)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.1.12 (2022-08-09)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.1.11 (2022-08-08)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.1.10 (2022-08-01)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.1.9 (2022-07-05)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.1.8 (2022-06-29)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.1.7 (2022-06-07)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.1.6 (2022-05-17)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.1.5 (2022-04-27)

* **Bug Fix**: Fixes a bug that could cause the SigV4 payload hash to be incorrectly encoded, leading to signing errors.

# v1.1.4 (2022-04-25)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.1.3 (2022-03-30)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.1.2 (2022-03-24)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.1.1 (2022-03-23)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.1.0 (2022-03-08)

* **Feature**:  Updates the SDK's checksum validation logic to require opt-in to output response payload validation. The SDK was always preforming output response payload checksum validation, not respecting the output validation model option. Fixes [#1606](https://github.com/aws/aws-sdk-go-v2/issues/1606)
* **Feature**: Updated `github.com/aws/smithy-go` to latest version
* **Dependency Update**: Updated to the latest SDK module versions

# v1.0.0 (2022-02-24)

* **Release**: New module for computing checksums
* **Feature**: Updated `github.com/aws/smithy-go` to latest version
* **Dependency Update**: Updated to the latest SDK module versions

