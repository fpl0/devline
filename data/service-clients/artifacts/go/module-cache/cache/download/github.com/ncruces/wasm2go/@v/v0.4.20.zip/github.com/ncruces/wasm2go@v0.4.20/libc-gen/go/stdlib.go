package libc

import (
	"bytes"
	"strconv"
	"unsafe"
)

// unsafe.String is used to call strconv.ParseFloat/Int/Uint
// avoiding copies.

func strtod(s, endptr sptr_t) float64 {
	return strtod_helper(s, endptr, 64)
}

func strtof(s, endptr sptr_t) float32 {
	return float32(strtod_helper(s, endptr, 32))
}

func strtoll(s, endptr sptr_t, base int32) int64 {
	return strtoll_helper(s, endptr, base, 64)
}

func strtoull(s, endptr sptr_t, base int32) uint64 {
	return strtoull_helper(s, endptr, base, 64)
}

func strtol(s, endptr sptr_t, base int32) int32 {
	return int32(strtoll_helper(s, endptr, base, 32))
}

func strtoul(s, endptr sptr_t, base int32) uint32 {
	return uint32(strtoull_helper(s, endptr, base, 32))
}

func strtod_helper(s, endptr sptr_t, bitSize int) float64 {
	m0 := memory[uptr_t(s):]
	m1 := bytes.TrimLeft(m0, " \t\n\v\f\r")
	m2 := bytes.TrimLeft(m1, "+-.0123456789abcdefinptxyABCDEFINPTXY")
	prefix := len(m0) - len(m1)
	digits := len(m1) - len(m2)

	var val float64
	for ; digits > 0; digits-- {
		var err error
		str := unsafe.String(&m1[0], digits)
		val, err = strconv.ParseFloat(str, bitSize)
		if e, ok := err.(*strconv.NumError); !ok || e.Err == strconv.ErrRange {
			break
		}
	}

	if endptr != 0 {
		if digits > 0 {
			s += sptr_t(prefix + digits)
		}
		store32(memory, cptr_t(endptr), uint32(s))
	}
	return val
}

func strtoll_helper(s, endptr sptr_t, base int32, bitSize int) int64 {
	m0 := memory[uptr_t(s):]
	m1 := bytes.TrimLeft(m0, " \t\n\v\f\r")

	m2 := m1
	switch {
	case bytes.HasPrefix(m1, []byte("-")):
		fallthrough
	case bytes.HasPrefix(m1, []byte("+")):
		m2 = m2[1:]
	}

	m2 = bytes.TrimLeft(m2, "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ")
	prefix := len(m0) - len(m1)
	digits := len(m1) - len(m2)

	var val int64
	for ; digits > 0; digits-- {
		var err error
		str := unsafe.String(&m1[0], digits)
		val, err = strconv.ParseInt(str, int(base), bitSize)
		if e, ok := err.(*strconv.NumError); !ok || e.Err == strconv.ErrRange {
			break
		}
	}

	if endptr != 0 {
		if digits > 0 {
			s += sptr_t(prefix + digits)
		}
		store32(memory, cptr_t(endptr), uint32(s))
	}
	return val
}

func strtoull_helper(s, endptr sptr_t, base int32, bitSize int) uint64 {
	m0 := memory[uptr_t(s):]
	m1 := bytes.TrimLeft(m0, " \t\n\v\f\r")

	var neg bool
	switch {
	case bytes.HasPrefix(m1, []byte("-")):
		neg = true
		fallthrough
	case bytes.HasPrefix(m1, []byte("+")):
		m1 = m1[1:]
	}

	m2 := bytes.TrimLeft(m1, "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ")
	prefix := len(m0) - len(m1)
	digits := len(m1) - len(m2)

	var val uint64
	for ; digits > 0; digits-- {
		var err error
		str := unsafe.String(&m1[0], digits)
		val, err = strconv.ParseUint(str, int(base), bitSize)
		if e, ok := err.(*strconv.NumError); !ok || e.Err == strconv.ErrRange {
			break
		}
	}

	if neg {
		if bitSize == 32 {
			val = uint64(-uint32(val))
		} else {
			val = -val
		}
	}

	if endptr != 0 {
		if digits > 0 {
			s += sptr_t(prefix + digits)
		}
		store32(memory, cptr_t(endptr), uint32(s))
	}
	return val
}
