module github.com/aws/aws-sdk-go-v2/aws/protocol/eventstream

go 1.24

require github.com/aws/smithy-go v1.28.8

replace github.com/aws/aws-sdk-go-v2 => ../../../
