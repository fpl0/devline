module github.com/aws/aws-sdk-go-v2/internal/configsources

go 1.24

require github.com/aws/aws-sdk-go-v2 v1.47.8

require github.com/aws/smithy-go v1.28.8 // indirect

replace github.com/aws/aws-sdk-go-v2 => ../../
