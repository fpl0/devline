package helpers

import (
	"encoding/binary"
	"math"
	"math/bits"
	"runtime"
	"sync/atomic"
)

// Prevent constant folding/propagation,
// ensuring code using them compiles
// and overflows/panics at runtime.

//go:nosplit
func i32(x int32) int32 { return x }

//go:nosplit
func i64(x int64) int64 { return x }

// Prevent constant folding/propagation,
// ensuring correct NaN handling.
// Only used with nanbox.

//go:nosplit
func f32(x float32) float32 {
	runtime.KeepAlive(&x)
	return x
}

//go:nosplit
func f64(x float64) float64 {
	runtime.KeepAlive(&x)
	return x
}

// Clears the MSB by halving negative addresses so
// subsequent offset additions cannot wrap around,
// while keeping them large enough to reliably
// trap slice bounds checks.

//go:nosplit
func p64(x int64) uint64 { return uint64(x) >> (uint64(x) >> 63) }

// Detect signed integer overflow.
// Folded away for constant y.
// They generate sub-optimal code on Intel.

//go:nosplit
func i32_div_s(x, y int32) int32 {
	if y == -1 && x == math.MinInt32 {
		panic("integer overflow")
	}
	return x / y
}

//go:nosplit
func i64_div_s(x, y int64) int64 {
	if y == -1 && x == math.MinInt64 {
		panic("integer overflow")
	}
	return x / y
}

//go:nosplit
func i32_neg_s(x int32) int32 {
	if x == math.MinInt32 {
		panic("integer overflow")
	}
	return -x
}

//go:nosplit
func i64_neg_s(x int64) int64 {
	if x == math.MinInt64 {
		panic("integer overflow")
	}
	return -x
}

// Needed for correct y wrap around behavior.
// Folded away for constant y.

//go:nosplit
func i32_shl(x, y int32) int32 {
	return x << (y & 31)
}

//go:nosplit
func i32_shr_s(x, y int32) int32 {
	return x >> (y & 31)
}

//go:nosplit
func i32_shr_u(x, y int32) int32 {
	return int32(uint32(x) >> (y & 31))
}

//go:nosplit
func i64_shl(x, y int64) int64 {
	return x << (y & 63)
}

//go:nosplit
func i64_shr_s(x, y int64) int64 {
	return x >> (y & 63)
}

//go:nosplit
func i64_shr_u(x, y int64) int64 {
	return int64(uint64(x) >> (y & 63))
}

//go:nosplit
func i32_rotl(x, y int32) int32 {
	return int32(bits.RotateLeft32(uint32(x), int(y)))
}

//go:nosplit
func i32_rotr(x, y int32) int32 {
	return int32(bits.RotateLeft32(uint32(x), -int(y)))
}

//go:nosplit
func i64_rotl(x, y int64) int64 {
	return int64(bits.RotateLeft64(uint64(x), int(y)))
}

//go:nosplit
func i64_rotr(x, y int64) int64 {
	return int64(bits.RotateLeft64(uint64(x), -int(y)))
}

// Must be implemented as bitwise operations,
// like the math versions are for float64.

//go:nosplit
func f32_abs(x float32) float32 {
	return math.Float32frombits(math.Float32bits(x) &^ (1 << 31))
}

//go:nosplit
func f32_copysign(x, y float32) float32 {
	return math.Float32frombits(math.Float32bits(x)&^(1<<31) | math.Float32bits(y)&(1<<31))
}

// Must return canonical NaNs,
// which they don't on amd64.
// Only used with nanbox.

//go:nosplit
func f32_min(x, y float32) float32 {
	if m := min(x, y); m == m {
		return m
	}
	return math.Float32frombits(0x7fc00000)
}

//go:nosplit
func f32_max(x, y float32) float32 {
	if m := max(x, y); m == m {
		return m
	}
	return math.Float32frombits(0x7fc00000)
}

//go:nosplit
func f64_min(x, y float64) float64 {
	if m := min(x, y); m == m {
		return m
	}
	return math.Float64frombits(0x7ff8000000000000)
}

//go:nosplit
func f64_max(x, y float64) float64 {
	if m := max(x, y); m == m {
		return m
	}
	return math.Float64frombits(0x7ff8000000000000)
}

// Float to int conversions.

// All i64 conversions use >= because both MaxInt64 and MaxUint64
// round up when converted to a float64.

// go.dev/issues/76264 can speed these up

//go:nosplit
func i32_trunc_f64_s(f float64) int32 {
	x := math.Trunc(f)
	switch {
	case f != f:
		panic("invalid conversion to integer")
	case x < math.MinInt32 || x > math.MaxInt32:
		panic("integer overflow")
	}
	return int32(x)
}

//go:nosplit
func i32_trunc_f32_s(f float32) int32 {
	x := math.Trunc(float64(f))
	switch {
	case f != f:
		panic("invalid conversion to integer")
	case x < math.MinInt32 || x > math.MaxInt32:
		panic("integer overflow")
	}
	return int32(x)
}

//go:nosplit
func i32_trunc_f64_u(f float64) int32 {
	x := math.Trunc(f)
	switch {
	case f != f:
		panic("invalid conversion to integer")
	case x < 0 || x > math.MaxUint32:
		panic("integer overflow")
	}
	return int32(uint32(x))
}

//go:nosplit
func i32_trunc_f32_u(f float32) int32 {
	x := math.Trunc(float64(f))
	switch {
	case f != f:
		panic("invalid conversion to integer")
	case x < 0 || x > math.MaxUint32:
		panic("integer overflow")
	}
	return int32(uint32(x))
}

//go:nosplit
func i64_trunc_f64_s(f float64) int64 {
	x := math.Trunc(f)
	switch {
	case f != f:
		panic("invalid conversion to integer")
	case x < math.MinInt64 || x >= math.MaxInt64:
		panic("integer overflow")
	}
	return int64(x)
}

//go:nosplit
func i64_trunc_f32_s(f float32) int64 {
	x := math.Trunc(float64(f))
	switch {
	case f != f:
		panic("invalid conversion to integer")
	case x < math.MinInt64 || x >= math.MaxInt64:
		panic("integer overflow")
	}
	return int64(x)
}

//go:nosplit
func i64_trunc_f64_u(f float64) int64 {
	x := math.Trunc(f)
	switch {
	case f != f:
		panic("invalid conversion to integer")
	case x < 0 || x >= math.MaxUint64:
		panic("integer overflow")
	}
	return int64(uint64(x))
}

//go:nosplit
func i64_trunc_f32_u(f float32) int64 {
	x := math.Trunc(float64(f))
	switch {
	case f != f:
		panic("invalid conversion to integer")
	case x < 0 || x >= math.MaxUint64:
		panic("integer overflow")
	}
	return int64(uint64(x))
}

//go:nosplit
func i32_trunc_sat_f64_s(f float64) int32 {
	switch {
	case f <= math.MinInt32:
		return math.MinInt32
	case f >= math.MaxInt32:
		return math.MaxInt32
	case f != f:
		return 0
	}
	return int32(f)
}

//go:nosplit
func i32_trunc_sat_f32_s(f float32) int32 {
	switch {
	case f <= math.MinInt32:
		return math.MinInt32
	case f >= math.MaxInt32:
		return math.MaxInt32
	case f != f:
		return 0
	}
	return int32(f)
}

//go:nosplit
func i32_trunc_sat_f64_u(f float64) int32 {
	var i uint32
	switch {
	case f <= 0 || f != f:
		i = 0
	case f >= math.MaxUint32:
		i = math.MaxUint32
	default:
		i = uint32(f)
	}
	return int32(i)
}

//go:nosplit
func i32_trunc_sat_f32_u(f float32) int32 {
	var i uint32
	switch {
	case f <= 0 || f != f:
		i = 0
	case f >= math.MaxUint32:
		i = math.MaxUint32
	default:
		i = uint32(f)
	}
	return int32(i)
}

//go:nosplit
func i64_trunc_sat_f64_s(f float64) int64 {
	switch {
	case f < math.MinInt64:
		return math.MinInt64
	case f >= math.MaxInt64:
		return math.MaxInt64
	case f != f:
		return 0
	}
	return int64(f)
}

//go:nosplit
func i64_trunc_sat_f32_s(f float32) int64 {
	switch {
	case f < math.MinInt64:
		return math.MinInt64
	case f >= math.MaxInt64:
		return math.MaxInt64
	case f != f:
		return 0
	}
	return int64(f)
}

//go:nosplit
func i64_trunc_sat_f64_u(f float64) int64 {
	var i uint64
	switch {
	case f <= 0 || f != f:
		i = 0
	case f >= math.MaxUint64:
		i = math.MaxUint64
	default:
		i = uint64(f)
	}
	return int64(i)
}

//go:nosplit
func i64_trunc_sat_f32_u(f float32) int64 {
	var i uint64
	switch {
	case f <= 0 || f != f:
		i = 0
	case f >= math.MaxUint64:
		i = math.MaxUint64
	default:
		i = uint64(f)
	}
	return int64(i)
}

// Wide Arithmetic.

//go:nosplit
func i64_add128(xl, xh, yl, yh int64) (int64, int64) {
	lo, carry := bits.Add64(uint64(xl), uint64(yl), 0)
	hi, _ := bits.Add64(uint64(xh), uint64(yh), carry)
	return int64(lo), int64(hi)
}

//go:nosplit
func i64_sub128(xl, xh, yl, yh int64) (int64, int64) {
	lo, borrow := bits.Sub64(uint64(xl), uint64(yl), 0)
	hi, _ := bits.Sub64(uint64(xh), uint64(yh), borrow)
	return int64(lo), int64(hi)
}

//go:nosplit
func i64_add_wide(x, y int64) (int64, int64) {
	lo, carry := bits.Add64(uint64(x), uint64(y), 0)
	return int64(lo), int64(carry)
}

//go:nosplit
func i64_sub_wide(x, y int64) (int64, int64) {
	lo, borrow := bits.Sub64(uint64(x), uint64(y), 0)
	return int64(lo), int64(-borrow)
}

//go:nosplit
func i64_mul_wide_u(x, y int64) (int64, int64) {
	hi, lo := bits.Mul64(uint64(x), uint64(y))
	return int64(lo), int64(hi)
}

//go:nosplit
func i64_mul_wide_s(x, y int64) (int64, int64) {
	hi, lo := bits.Mul64(uint64(x), uint64(y))
	if x < 0 {
		hi -= uint64(y)
	}
	if y < 0 {
		hi -= uint64(x)
	}
	return int64(lo), int64(hi)
}

// Multi-byte loads/stores.

//go:nosplit
func load16[T uint32 | uint64](mem []byte, addr T) uint16 {
	a := uint64(addr)
	return binary.LittleEndian.Uint16(mem[:0:len(mem)][a : a+2 : a+2])
}

//go:nosplit
func store16[T uint32 | uint64](mem []byte, addr T, val uint16) {
	a := uint64(addr)
	binary.LittleEndian.PutUint16(mem[:0:len(mem)][a:a+2:a+2], val)
}

//go:nosplit
func load32[T uint32 | uint64](mem []byte, addr T) uint32 {
	a := uint64(addr)
	return binary.LittleEndian.Uint32(mem[:0:len(mem)][a : a+4 : a+4])
}

//go:nosplit
func store32[T uint32 | uint64](mem []byte, addr T, val uint32) {
	a := uint64(addr)
	binary.LittleEndian.PutUint32(mem[:0:len(mem)][a:a+4:a+4], val)
}

//go:nosplit
func load64[T uint32 | uint64](mem []byte, addr T) uint64 {
	a := uint64(addr)
	return binary.LittleEndian.Uint64(mem[:0:len(mem)][a : a+8 : a+8])
}

//go:nosplit
func store64[T uint32 | uint64](mem []byte, addr T, val uint64) {
	a := uint64(addr)
	binary.LittleEndian.PutUint64(mem[:0:len(mem)][a:a+8:a+8], val)
}

// Bulk memory operations.

func memory_grow(mem *[]byte, delta, max int64) int64 {
	buf := *mem
	len := len(buf)
	old := len >> 16
	if delta == 0 {
		return int64(old)
	}
	max = int64(min(uint64(max), math.MaxInt>>16))
	new, c := bits.Add64(uint64(old), uint64(delta), 0)
	if c != 0 || new > uint64(max) {
		return -1
	}
	*mem = append(buf, make([]byte, int(new<<16)-len)...)
	return int64(old)
}

func memory_init[T1, T2 int | uint32 | uint64](mem []byte, data string, dest T1, src, n T2) {
	x := uint64(dest)
	z := uint64(src)
	y := x + uint64(n)
	w := z + uint64(n)
	copy(mem[x:y:len(mem)], data[z:w])
}

func memory_copy[T uint32 | uint64](mem []byte, dest, src, n T) {
	x := uint64(dest)
	z := uint64(src)
	y := x + uint64(n)
	w := z + uint64(n)
	copy(mem[x:y:len(mem)], mem[z:w:len(mem)])
}

func memory_fill[T uint32 | uint64](mem []byte, dest T, val int32, n T) {
	x := uint64(dest)
	y := x + uint64(n)
	buf := mem[x:y:len(mem)]
	if len(buf) > 0 {
		buf[0] = byte(val)
		for i := 1; i < len(buf); {
			chunk := min(i, 8192)
			i += copy(buf[i:], buf[:chunk])
		}
	}
}

func memory_zero[T uint32 | uint64](mem []byte, dest, n T) {
	x := uint64(dest)
	y := x + uint64(n)
	clear(mem[x:y:len(mem)])
}

func table_init[T1, T2, T3 int | int32 | int64](tab, elems []any, dest T1, src T2, n T3) {
	x := uint64(dest)
	z := uint64(src)
	y := x + uint64(n)
	w := z + uint64(n)
	copy(tab[x:y:len(tab)], elems[z:w:len(elems)])
}

func table_copy[T1, T2, T3 int32 | int64](dst, tab []any, dest T1, src T2, n T3) {
	x := uint64(dest)
	z := uint64(src)
	y := x + uint64(n)
	w := z + uint64(n)
	copy(dst[x:y:len(dst)], tab[z:w:len(tab)])
}

func table_fill[T int32 | int64](tab []any, dest T, val any, n T) {
	x := uint64(dest)
	y := x + uint64(n)
	buf := tab[x:y:len(tab)]
	if val == nil {
		clear(buf)
		return
	}
	for i := range buf {
		buf[i] = val
	}
}

func table_grow[T int32 | int64](tab *[]any, val any, delta, max T) T {
	buf := *tab
	old := len(buf)
	if delta == 0 {
		return T(old)
	}
	new, c := bits.Add64(uint64(old), uint64(delta), 0)
	if c != 0 || new > uint64(max) {
		return -1
	}
	buf = append(buf, make([]any, delta)...)
	if val != nil {
		cpy := buf[old:]
		for i := range cpy {
			cpy[i] = val
		}
	}
	*tab = buf
	return T(old)
}

//go:nosplit
func atomic_fence() {
	var b atomic.Bool
	b.Swap(true)
}
