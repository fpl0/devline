// Copyright 2012-2026 The NATS Authors
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package test

import (
	"bytes"
	"context"
	"errors"
	"fmt"
	"math"
	"regexp"
	"strings"
	"sync"
	"sync/atomic"
	"testing"
	"time"

	"github.com/nats-io/nats.go"
	testservice "github.com/synadia-io/orbit.go/ntf-client"
)

func TestCloseLeakingGoRoutines(t *testing.T) {
	// Goroutine baseline must be captured BEFORE the connection is created;
	// otherwise the conn's own goroutines are in the base and Close() trivially
	// satisfies the leak check (they all exit, delta is non-positive).
	c := newTester(t)
	inst := c.CreateServer(t, false)
	t.Cleanup(func() { inst.Destroy(t) })

	base := getStableNumGoroutine(t)

	nc, err := nats.Connect(inst.Servers[0].URL)
	if err != nil {
		t.Fatalf("nats.Connect: %v", err)
	}
	nc.Flush()
	nc.Close()

	checkNoGoroutineLeak(t, base, "Close()")

	nc.Close()
}

func TestLeakingGoRoutinesOnFailedConnect(t *testing.T) {
	base := getStableNumGoroutine(t)

	// Use a port that is guaranteed to fail (privileged + no listener).
	// Cannot use nats.DefaultURL here because in the host-side dev workflow
	// the tester publishes its own management server on localhost:4222.
	nc, err := nats.Connect("nats://127.0.0.1:1")
	if err == nil {
		nc.Close()
		t.Fatalf("Expected failure to connect")
	}

	checkNoGoroutineLeak(t, base, "failed connect")
}

func TestTLSConnectionStateNonTLS(t *testing.T) {
	withServer(t, func(t *testing.T, nc *nats.Conn) {
		_, err := nc.TLSConnectionState()
		if err != nats.ErrConnectionNotTLS {
			t.Fatalf("Expected a not tls error, got: %v", err)
		}
	})
}

func TestConnectedServer(t *testing.T) {
	withServerInstance(t, func(t *testing.T, nc *nats.Conn, inst *testservice.Instance) {
		wantURL := inst.Servers[0].URL
		if u := nc.ConnectedUrl(); u == "" || u != wantURL {
			t.Fatalf("Unexpected connected URL of %s (want %s)", u, wantURL)
		}
		if id := nc.ConnectedServerId(); id == "" {
			t.Fatalf("Expected a connected server id, got %s", id)
		}
		if name := nc.ConnectedServerName(); name == "" {
			t.Fatalf("Expected a connected server name, got %s", name)
		}
		if jsEnabled, _ := nc.ConnectedServerJetStream(); jsEnabled {
			t.Fatalf("Expected JetStream to be disabled")
		}
		if nc.IsSystemAccount() {
			t.Fatalf("Expected non-system account")
		}

		nc.Close()
		if u := nc.ConnectedUrl(); u != "" {
			t.Fatalf("Expected a nil connected URL, got %s", u)
		}
		if id := nc.ConnectedServerId(); id != "" {
			t.Fatalf("Expected a nil connect server, got %s", id)
		}
		if name := nc.ConnectedServerName(); name != "" {
			t.Fatalf("Expected a nil connect server name, got %s", name)
		}
		if jsEnabled, _ := nc.ConnectedServerJetStream(); jsEnabled {
			t.Fatalf("Expected JetStream to be disabled after close")
		}
		if nc.IsSystemAccount() {
			t.Fatalf("Expected non-system account after close")
		}
	})
}

func TestConnectedClusterName(t *testing.T) {
	c := newTester(t)
	inst := c.CreateCluster(t, 3, false)
	t.Cleanup(func() { inst.Destroy(t) })

	want := inst.Servers[0].Cluster
	if want == "" {
		t.Fatal("Expected the tester to report a cluster name")
	}

	nc := dialInstance(t, inst)
	if got := nc.ConnectedClusterName(); got != want {
		t.Fatalf("Expected cluster name %q, got %q", want, got)
	}

	nc.Close()
	if got := nc.ConnectedClusterName(); got != "" {
		t.Fatalf("Expected an empty cluster name after close, got %q", got)
	}
}

func TestConnectedDomain(t *testing.T) {
	withJSServer(t, func(t *testing.T, nc *nats.Conn) {
		if got := nc.ConnectedDomain(); got != "ABC" {
			t.Fatalf("Expected domain %q, got %q", "ABC", got)
		}

		nc.Close()
		if got := nc.ConnectedDomain(); got != "" {
			t.Fatalf("Expected an empty domain after close, got %q", got)
		}
	}, testservice.WithJetStream(`domain: ABC`))

	t.Run("no domain configured", func(t *testing.T) {
		withJSServer(t, func(t *testing.T, nc *nats.Conn) {
			if got := nc.ConnectedDomain(); got != "" {
				t.Fatalf("Expected an empty domain, got %q", got)
			}
		})
	})
}

func TestConnectedServerJetStream(t *testing.T) {
	c := newTester(t)
	inst := c.CreateServer(t, true)
	t.Cleanup(func() { inst.Destroy(t) })

	nc := dialInstance(t, inst)
	jsEnabled, jsApiLevel := nc.ConnectedServerJetStream()
	if !jsEnabled {
		t.Fatalf("Expected JetStream to be enabled")
	}
	if jsApiLevel == 0 {
		t.Fatalf("Expected non-zero JetStream API level")
	}
}

func TestIsSystemAccount(t *testing.T) {
	const accountsSnippet = `
accounts: {
    SYS: {
        users: [ {user: "sys", password: "pass"} ]
    }
    APP: {
        users: [ {user: "app", password: "pass"} ]
    }
}`

	c := newTester(t)
	inst := c.CreateServer(t, false,
		testservice.WithAccounts(accountsSnippet),
		testservice.WithAuthorization("# auth required, no no_auth_user"),
		testservice.WithSystemAccount("system_account: SYS"),
	)
	t.Cleanup(func() { inst.Destroy(t) })

	nc := dialInstance(t, inst, nats.UserInfo("sys", "pass"))

	// IsSystemAccount is sent by the server in an async INFO after connect.
	checkFor(t, time.Second, 15*time.Millisecond, func() error {
		if !nc.IsSystemAccount() {
			return fmt.Errorf("expected system account")
		}
		return nil
	})

	nc2 := dialInstance(t, inst, nats.UserInfo("app", "pass"))
	if nc2.IsSystemAccount() {
		t.Fatalf("Expected non-system account")
	}
}

func TestRemoteAccount(t *testing.T) {
	const accountsSnippet = `
accounts: {
    SYS: {
        users: [ {user: "sys", password: "pass"} ]
    }
    APP: {
        users: [ {user: "app", password: "pass"} ]
    }
}`

	c := newTester(t)
	accInst := c.CreateServer(t, false,
		testservice.WithAccounts(accountsSnippet),
		testservice.WithAuthorization("# auth required, no no_auth_user"),
		testservice.WithSystemAccount("system_account: SYS"),
	)
	t.Cleanup(func() { accInst.Destroy(t) })
	globalInst := c.CreateServer(t, false,
		testservice.WithAccounts("# no accounts, clients bind to $G"),
		testservice.WithAuthorization("# no auth"),
		testservice.WithSystemAccount("# default system account"),
	)
	t.Cleanup(func() { globalInst.Destroy(t) })

	tests := []struct {
		name    string
		inst    *testservice.Instance
		opts    []nats.Option
		account string
		isSys   bool
	}{
		{"named account", accInst, []nats.Option{nats.UserInfo("app", "pass")}, "APP", false},
		{"system account", accInst, []nats.Option{nats.UserInfo("sys", "pass")}, "SYS", true},
		{"global account", globalInst, nil, "$G", false},
	}
	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			nc := dialInstance(t, test.inst, test.opts...)
			// The server sends the account in an INFO right after the PONG
			// to the first PING, so it is in hand once Flush's PONG arrives.
			if err := nc.Flush(); err != nil {
				t.Fatalf("Error on flush: %v", err)
			}
			if acc := nc.RemoteAccount(); acc != test.account {
				t.Fatalf("Expected account %q, got %q", test.account, acc)
			}
			if isSys := nc.IsSystemAccount(); isSys != test.isSys {
				t.Fatalf("Expected IsSystemAccount %v, got %v", test.isSys, isSys)
			}

			nc.Close()
			if acc := nc.RemoteAccount(); acc != "" {
				t.Fatalf("Expected an empty account after close, got %q", acc)
			}
		})
	}
}

func TestRemoteAccountKeptAcrossAsyncInfo(t *testing.T) {
	c := newTester(t)
	clusterInst := c.CreateCluster(t, 2, false,
		testservice.WithAccounts(`accounts: { SYS: { users: [ {user: "sys", password: "pass"} ] } }`),
		testservice.WithAuthorization("# auth required, no no_auth_user"),
		testservice.WithSystemAccount("system_account: SYS"),
	)
	t.Cleanup(func() { clusterInst.Destroy(t) })
	s1, s2 := clusterInst.Servers[0], clusterInst.Servers[1]
	clusterInst.StopServer(t, s2)

	nc, err := nats.Connect(s1.URL, nats.UserInfo("sys", "pass"))
	if err != nil {
		t.Fatalf("Error on connect: %v", err)
	}
	defer nc.Close()
	if err := nc.Flush(); err != nil {
		t.Fatalf("Error on flush: %v", err)
	}
	check := func() {
		t.Helper()
		if acc := nc.RemoteAccount(); acc != "SYS" {
			t.Fatalf("Expected account %q, got %q", "SYS", acc)
		}
		if !nc.IsSystemAccount() {
			t.Fatalf("Expected system account")
		}
	}
	check()

	// s2 joining the cluster makes s1 send an INFO with new connect_urls
	// and no account fields.
	clusterInst.StartServer(t, s2)
	checkFor(t, 5*time.Second, 50*time.Millisecond, func() error {
		if n := len(nc.Servers()); n != 2 {
			return fmt.Errorf("expected 2 servers in the pool, got %d", n)
		}
		return nil
	})
	check()
}

func TestRemoteAccountRefreshedOnReconnect(t *testing.T) {
	accounts := func(name string) string {
		return fmt.Sprintf(`accounts: { %s: { users: [ {user: "app", password: "pass"} ] } }`, name)
	}
	noAuthUser := testservice.WithAuthorization("# auth required, no no_auth_user")
	defaultSys := testservice.WithSystemAccount("# default system account")

	c := newTester(t)
	inst := c.CreateServer(t, false, testservice.WithAccounts(accounts("APP1")), noAuthUser, defaultSys)
	t.Cleanup(func() { inst.Destroy(t) })
	s := inst.Servers[0]

	rch := make(chan bool, 1)
	nc := dialInstance(t, inst,
		nats.UserInfo("app", "pass"),
		nats.ReconnectWait(50*time.Millisecond),
		nats.ReconnectHandler(func(_ *nats.Conn) { rch <- true }),
	)
	if err := nc.Flush(); err != nil {
		t.Fatalf("Error on flush: %v", err)
	}
	if acc := nc.RemoteAccount(); acc != "APP1" {
		t.Fatalf("Expected account %q, got %q", "APP1", acc)
	}

	// Bind the same user to another account; the new connection must not
	// report the previous connection's account.
	inst.StopServer(t, s)
	inst.UpdateServer(t, s, testservice.WithAccounts(accounts("APP2")), noAuthUser, defaultSys)
	inst.StartServer(t, s)
	if err := Wait(rch); err != nil {
		t.Fatal("Did not reconnect")
	}
	if err := nc.Flush(); err != nil {
		t.Fatalf("Error on flush: %v", err)
	}
	if acc := nc.RemoteAccount(); acc != "APP2" {
		t.Fatalf("Expected account %q, got %q", "APP2", acc)
	}
}

func TestMultipleClose(t *testing.T) {
	withServer(t, func(t *testing.T, nc *nats.Conn) {
		var wg sync.WaitGroup
		for i := 0; i < 10; i++ {
			wg.Add(1)
			go func() {
				nc.Close()
				wg.Done()
			}()
		}
		wg.Wait()
	})
}

func TestBadOptionTimeoutConnect(t *testing.T) {
	withServerInstance(t, func(t *testing.T, _ *nats.Conn, inst *testservice.Instance) {
		opts := nats.GetDefaultOptions()
		opts.Timeout = -1
		opts.Url = inst.Servers[0].URL

		_, err := opts.Connect()
		if err == nil {
			t.Fatal("Expected an error")
		}
		if !strings.Contains(err.Error(), "invalid") {
			t.Fatalf("Expected a ErrNoServers error: Got %v", err)
		}
	})
}

func TestSimplePublish(t *testing.T) {
	withServer(t, func(t *testing.T, nc *nats.Conn) {
		if err := nc.Publish("foo", []byte("Hello World")); err != nil {
			t.Fatal("Failed to publish string message: ", err)
		}
	})
}

func TestSimplePublishNoData(t *testing.T) {
	withServer(t, func(t *testing.T, nc *nats.Conn) {
		if err := nc.Publish("foo", nil); err != nil {
			t.Fatal("Failed to publish empty message: ", err)
		}
	})
}

func TestPublishDoesNotFailOnSlowConsumer(t *testing.T) {
	withServer(t, func(t *testing.T, nc *nats.Conn) {
		nc.SetErrorHandler(func(_ *nats.Conn, _ *nats.Subscription, _ error) {})

		sub, err := nc.SubscribeSync("foo")
		if err != nil {
			t.Fatalf("Unable to create subscription: %v", err)
		}
		if err := sub.SetPendingLimits(1, 1000); err != nil {
			t.Fatalf("Unable to set pending limits: %v", err)
		}

		var pubErr error
		msg := []byte("Hello")
		for i := 0; i < 10; i++ {
			pubErr = nc.Publish("foo", msg)
			if pubErr != nil {
				break
			}
			nc.Flush()
		}
		if pubErr != nil {
			t.Fatalf("Publish() should not fail because of slow consumer. Got '%v'", pubErr)
		}
	})
}

func TestAsyncSubscribe(t *testing.T) {
	withServer(t, func(t *testing.T, nc *nats.Conn) {
		omsg := []byte("Hello World")
		ch := make(chan bool)

		if _, err := nc.Subscribe("foo", nil); err == nil {
			t.Fatal("Creating subscription without callback should have failed")
		}

		_, err := nc.Subscribe("foo", func(m *nats.Msg) {
			if !bytes.Equal(m.Data, omsg) {
				t.Fatal("Message received does not match")
			}
			if m.Sub == nil {
				t.Fatal("Callback does not have a valid Subscription")
			}
			ch <- true
		})
		if err != nil {
			t.Fatal("Failed to subscribe: ", err)
		}
		nc.Publish("foo", omsg)
		if e := Wait(ch); e != nil {
			t.Fatal("Message not received for subscription")
		}
	})
}

func TestAsyncSubscribeRoutineLeakOnUnsubscribe(t *testing.T) {
	withServer(t, func(t *testing.T, nc *nats.Conn) {
		ch := make(chan bool)

		base := getStableNumGoroutine(t)

		sub, err := nc.Subscribe("foo", func(m *nats.Msg) { ch <- true })
		if err != nil {
			t.Fatal("Failed to subscribe: ", err)
		}

		nc.Publish("foo", []byte("hello"))

		if err := Wait(ch); err != nil {
			t.Fatal("Failed to receive message")
		}

		time.Sleep(200 * time.Millisecond)
		sub.Unsubscribe()
		checkNoGoroutineLeak(t, base, "Unsubscribe()")
	})
}

func TestAsyncSubscribeRoutineLeakOnClose(t *testing.T) {
	withServerInstance(t, func(t *testing.T, _ *nats.Conn, inst *testservice.Instance) {
		ch := make(chan bool)

		// Take the base BEFORE the connection is created so the connection's
		// goroutines count toward the leak delta.
		base := getStableNumGoroutine(t)

		nc := dialInstance(t, inst)

		_, err := nc.Subscribe("foo", func(m *nats.Msg) { ch <- true })
		if err != nil {
			t.Fatal("Failed to subscribe: ", err)
		}
		nc.Publish("foo", []byte("hello"))
		if err := Wait(ch); err != nil {
			t.Fatal("Failed to receive message")
		}

		time.Sleep(200 * time.Millisecond)
		nc.Close()
		checkNoGoroutineLeak(t, base, "Close()")
	})
}

func TestSyncSubscribe(t *testing.T) {
	withServer(t, func(t *testing.T, nc *nats.Conn) {
		sub, err := nc.SubscribeSync("foo")
		if err != nil {
			t.Fatal("Failed to subscribe: ", err)
		}
		omsg := []byte("Hello World")
		nc.Publish("foo", omsg)
		msg, err := sub.NextMsg(1 * time.Second)
		if err != nil || !bytes.Equal(msg.Data, omsg) {
			t.Fatal("Message received does not match")
		}
	})
}

func TestPubSubWithReply(t *testing.T) {
	withServer(t, func(t *testing.T, nc *nats.Conn) {
		sub, err := nc.SubscribeSync("foo")
		if err != nil {
			t.Fatal("Failed to subscribe: ", err)
		}
		omsg := []byte("Hello World")
		nc.PublishMsg(&nats.Msg{Subject: "foo", Reply: "bar", Data: omsg})
		msg, err := sub.NextMsg(10 * time.Second)
		if err != nil || !bytes.Equal(msg.Data, omsg) {
			t.Fatal("Message received does not match")
		}
	})
}

func TestMsgRespond(t *testing.T) {
	withServer(t, func(t *testing.T, nc *nats.Conn) {
		m := &nats.Msg{}
		if err := m.Respond(nil); err != nats.ErrMsgNotBound {
			t.Fatal("Expected ErrMsgNotBound error")
		}

		sub, err := nc.Subscribe("req", func(msg *nats.Msg) {
			msg.Respond([]byte("42"))
		})
		if err != nil {
			t.Fatal("Failed to subscribe: ", err)
		}

		m.Sub = sub
		if err := m.Respond(nil); err != nats.ErrMsgNoReply {
			t.Fatal("Expected ErrMsgNoReply error")
		}

		response, err := nc.Request("req", []byte("help"), 50*time.Millisecond)
		if err != nil {
			t.Fatal("Request Failed: ", err)
		}
		if string(response.Data) != "42" {
			t.Fatalf("Expected '42', got %q", response.Data)
		}
	})
}

func TestFlush(t *testing.T) {
	withServer(t, func(t *testing.T, nc *nats.Conn) {
		omsg := []byte("Hello World")
		for i := 0; i < 10000; i++ {
			nc.Publish("flush", omsg)
		}
		if err := nc.FlushTimeout(0); err == nil {
			t.Fatal("Calling FlushTimeout() with invalid timeout should fail")
		}
		if err := nc.Flush(); err != nil {
			t.Fatalf("Received error from flush: %s", err)
		}
		if nb, _ := nc.Buffered(); nb > 0 {
			t.Fatalf("Outbound buffer not empty: %d bytes", nb)
		}

		nc.Close()
		if _, err := nc.Buffered(); err == nil {
			t.Fatal("Calling Buffered() on closed connection should fail")
		}
	})
}

func TestQueueSubscriber(t *testing.T) {
	withServer(t, func(t *testing.T, nc *nats.Conn) {
		s1, _ := nc.QueueSubscribeSync("foo", "bar")
		s2, _ := nc.QueueSubscribeSync("foo", "bar")
		omsg := []byte("Hello World")
		nc.Publish("foo", omsg)
		nc.Flush()
		r1, _, _ := s1.Pending()
		r2, _, _ := s2.Pending()
		if (r1 + r2) != 1 {
			t.Fatal("Received too many messages for multiple queue subscribers")
		}
		s1.NextMsg(time.Second)
		s2.NextMsg(time.Second)

		total := 1000
		for i := 0; i < total; i++ {
			nc.Publish("foo", omsg)
		}
		nc.Flush()
		v := uint(float32(total) * 0.15)
		r1, _, _ = s1.Pending()
		r2, _, _ = s2.Pending()
		if r1+r2 != total {
			t.Fatalf("Incorrect number of messages: %d vs %d", (r1 + r2), total)
		}
		expected := total / 2
		d1 := uint(math.Abs(float64(expected - r1)))
		d2 := uint(math.Abs(float64(expected - r2)))
		if d1 > v || d2 > v {
			t.Fatalf("Too much variance in totals: %d, %d > %d", d1, d2, v)
		}
	})
}

func TestReplyArg(t *testing.T) {
	withServer(t, func(t *testing.T, nc *nats.Conn) {
		ch := make(chan bool)
		replyExpected := "bar"

		nc.Subscribe("foo", func(m *nats.Msg) {
			if m.Reply != replyExpected {
				t.Fatalf("Did not receive correct reply arg in callback: "+
					"('%s' vs '%s')", m.Reply, replyExpected)
			}
			ch <- true
		})
		nc.PublishMsg(&nats.Msg{Subject: "foo", Reply: replyExpected, Data: []byte("Hello")})
		if e := Wait(ch); e != nil {
			t.Fatal("Did not receive callback")
		}
	})
}

func TestSyncReplyArg(t *testing.T) {
	withServer(t, func(t *testing.T, nc *nats.Conn) {
		replyExpected := "bar"
		sub, _ := nc.SubscribeSync("foo")
		nc.PublishMsg(&nats.Msg{Subject: "foo", Reply: replyExpected, Data: []byte("Hello")})
		msg, err := sub.NextMsg(1 * time.Second)
		if err != nil {
			t.Fatal("Received an err on NextMsg()")
		}
		if msg.Reply != replyExpected {
			t.Fatalf("Did not receive correct reply arg in callback: "+
				"('%s' vs '%s')", msg.Reply, replyExpected)
		}
	})
}

func TestUnsubscribe(t *testing.T) {
	withServer(t, func(t *testing.T, nc *nats.Conn) {
		received := int32(0)
		max := int32(10)
		ch := make(chan bool)
		nc.Subscribe("foo", func(m *nats.Msg) {
			atomic.AddInt32(&received, 1)
			if received == max {
				err := m.Sub.Unsubscribe()
				if err != nil {
					t.Fatal("Unsubscribe failed with err:", err)
				}
				ch <- true
			}
		})
		send := 20
		for i := 0; i < send; i++ {
			nc.Publish("foo", []byte("hello"))
		}
		nc.Flush()
		<-ch

		r := atomic.LoadInt32(&received)
		if r != max {
			t.Fatalf("Received wrong # of messages after unsubscribe: %d vs %d",
				r, max)
		}
	})
}

func TestDoubleUnsubscribe(t *testing.T) {
	withServer(t, func(t *testing.T, nc *nats.Conn) {
		sub, err := nc.SubscribeSync("foo")
		if err != nil {
			t.Fatal("Failed to subscribe: ", err)
		}
		if err = sub.Unsubscribe(); err != nil {
			t.Fatal("Unsubscribe failed with err:", err)
		}
		if err = sub.Unsubscribe(); err == nil {
			t.Fatal("Unsubscribe should have reported an error")
		}
	})
}

func TestRequestTimeout(t *testing.T) {
	withServer(t, func(t *testing.T, nc *nats.Conn) {
		// We need a responder by default otherwise we get a no responders error.
		nc.SubscribeSync("foo")

		if _, err := nc.Request("foo", []byte("help"), 10*time.Millisecond); err != nats.ErrTimeout {
			t.Fatalf("Expected to receive a timeout error")
		}
	})
}

func TestBasicNoRespondersSupport(t *testing.T) {
	withServerInstance(t, func(t *testing.T, nc *nats.Conn, inst *testservice.Instance) {
		// Default new-style request
		if m, err := nc.Request("foo", nil, time.Second); err != nats.ErrNoResponders {
			t.Fatalf("Expected a no responders error and nil msg, got m:%+v and err: %v", m, err)
		}
		ctx, cancel := context.WithTimeout(context.Background(), time.Second)
		defer cancel()
		if m, err := nc.RequestWithContext(ctx, "foo", nil); err != nats.ErrNoResponders {
			t.Fatalf("Expected a no responders error and nil msg, got m:%+v and err: %v", m, err)
		}

		// Old request style (separate connection)
		ncOld := dialInstance(t, inst, nats.UseOldRequestStyle())
		if m, err := ncOld.Request("foo", nil, time.Second); err != nats.ErrNoResponders {
			t.Fatalf("Expected a no responders error and nil msg, got m:%+v and err: %v", m, err)
		}
		ctx2, cancel2 := context.WithTimeout(context.Background(), time.Second)
		defer cancel2()
		if m, err := ncOld.RequestWithContext(ctx2, "foo", nil); err != nats.ErrNoResponders {
			t.Fatalf("Expected a no responders error and nil msg, got m:%+v and err: %v", m, err)
		}

		// SubscribeSync style
		inbox := nats.NewInbox()
		sub, err := ncOld.SubscribeSync(inbox)
		if err != nil {
			t.Fatal(err)
		}
		if err := ncOld.PublishRequest("foo", inbox, nil); err != nil {
			t.Fatal(err)
		}
		if m, err := sub.NextMsg(2 * time.Second); err != nats.ErrNoResponders {
			t.Fatalf("Expected a no responders error and nil msg, got m:%+v and err: %v", m, err)
		}
	})
}

func TestOldRequest(t *testing.T) {
	withServerInstance(t, func(t *testing.T, _ *nats.Conn, inst *testservice.Instance) {
		nc := dialInstance(t, inst, nats.UseOldRequestStyle())

		response := []byte("I will help you")
		nc.Subscribe("foo", func(m *nats.Msg) {
			m.Respond(response)
		})
		msg, err := nc.Request("foo", []byte("help"), 500*time.Millisecond)
		if err != nil {
			t.Fatalf("Received an error on Request test: %s", err)
		}
		if !bytes.Equal(msg.Data, response) {
			t.Fatalf("Received invalid response")
		}

		// Check that Close() kicks out a Request()
		errCh := make(chan error, 1)
		start := time.Now()
		go func() {
			sub, _ := nc.SubscribeSync("checkClose")
			defer sub.Unsubscribe()
			_, err := nc.Request("checkClose", []byte("should be kicked out on close"), time.Second)
			errCh <- err
		}()
		time.Sleep(100 * time.Millisecond)
		nc.Close()
		if e := <-errCh; e != nats.ErrConnectionClosed {
			t.Fatalf("Unexpected error: %v", e)
		}
		if dur := time.Since(start); dur >= time.Second {
			t.Fatalf("Request took too long to bail out: %v", dur)
		}
	})
}

func TestRequest(t *testing.T) {
	withServer(t, func(t *testing.T, nc *nats.Conn) {
		response := []byte("I will help you")
		nc.Subscribe("foo", func(m *nats.Msg) {
			nc.Publish(m.Reply, response)
		})
		msg, err := nc.Request("foo", []byte("help"), 500*time.Millisecond)
		if err != nil {
			t.Fatalf("Received an error on Request test: %s", err)
		}
		if !bytes.Equal(msg.Data, response) {
			t.Fatalf("Received invalid response")
		}
	})
}

func TestRequestNoBody(t *testing.T) {
	withServer(t, func(t *testing.T, nc *nats.Conn) {
		response := []byte("I will help you")
		nc.Subscribe("foo", func(m *nats.Msg) {
			nc.Publish(m.Reply, response)
		})
		msg, err := nc.Request("foo", nil, 500*time.Millisecond)
		if err != nil {
			t.Fatalf("Received an error on Request test: %s", err)
		}
		if !bytes.Equal(msg.Data, response) {
			t.Fatalf("Received invalid response")
		}
	})
}

func TestSimultaneousRequests(t *testing.T) {
	withServer(t, func(t *testing.T, nc *nats.Conn) {
		response := []byte("I will help you")
		nc.Subscribe("foo", func(m *nats.Msg) {
			nc.Publish(m.Reply, response)
		})

		wg := sync.WaitGroup{}
		wg.Add(50)
		errCh := make(chan error, 50)
		for i := 0; i < 50; i++ {
			go func() {
				defer wg.Done()
				if _, err := nc.Request("foo", nil, 2*time.Second); err != nil {
					errCh <- fmt.Errorf("Error on request: %v", err)
				}
			}()
		}
		wg.Wait()
		checkErrChannel(t, errCh)
	})
}

func TestRequestClose(t *testing.T) {
	withServer(t, func(t *testing.T, nc *nats.Conn) {
		wg := &sync.WaitGroup{}
		wg.Add(1)
		go func() {
			defer wg.Done()
			time.Sleep(100 * time.Millisecond)
			nc.Close()
		}()
		nc.SubscribeSync("foo")
		if _, err := nc.Request("foo", []byte("help"), 2*time.Second); err != nats.ErrInvalidConnection && err != nats.ErrConnectionClosed {
			t.Fatalf("Expected connection error: got %v", err)
		}
		wg.Wait()
	})
}

func TestRequestCloseTimeout(t *testing.T) {
	withServer(t, func(t *testing.T, nc *nats.Conn) {
		response := []byte("I will help you")
		nc.Subscribe("foo", func(m *nats.Msg) {
			nc.Publish(m.Reply, response)
			nc.Close()
		})
		if _, err := nc.Request("foo", nil, 1*time.Second); err == nil {
			t.Fatalf("Expected to receive a timeout error")
		}
	})
}

func TestFlushInCB(t *testing.T) {
	withServer(t, func(t *testing.T, nc *nats.Conn) {
		ch := make(chan bool)

		nc.Subscribe("foo", func(_ *nats.Msg) {
			nc.Flush()
			ch <- true
		})
		nc.Publish("foo", []byte("Hello"))
		if e := Wait(ch); e != nil {
			t.Fatal("Flush did not return properly in callback")
		}
	})
}

func TestReleaseFlush(t *testing.T) {
	withServer(t, func(t *testing.T, nc *nats.Conn) {
		for i := 0; i < 1000; i++ {
			nc.Publish("foo", []byte("Hello"))
		}
		go nc.Close()
		nc.Flush()
	})
}

func TestInbox(t *testing.T) {
	inbox := nats.NewInbox()
	if matched, _ := regexp.Match(`_INBOX.\S`, []byte(inbox)); !matched {
		t.Fatal("Bad INBOX format")
	}
}

func TestStats(t *testing.T) {
	withServer(t, func(t *testing.T, nc *nats.Conn) {
		data := []byte("The quick brown fox jumped over the lazy dog")
		iter := 10

		for i := 0; i < iter; i++ {
			nc.Publish("foo", data)
		}

		if nc.OutMsgs != uint64(iter) {
			t.Fatalf("Not properly tracking OutMsgs: received %d, wanted %d", nc.OutMsgs, iter)
		}
		obb := uint64(iter * len(data))
		if nc.OutBytes != obb {
			t.Fatalf("Not properly tracking OutBytes: received %d, wanted %d", nc.OutBytes, obb)
		}

		nc.OutMsgs, nc.OutBytes = 0, 0

		nc.Subscribe("foo", func(_ *nats.Msg) {})
		nc.SubscribeSync("foo")

		for i := 0; i < iter; i++ {
			nc.Publish("foo", data)
		}
		nc.Flush()

		if nc.InMsgs != uint64(2*iter) {
			t.Fatalf("Not properly tracking InMsgs: received %d, wanted %d", nc.InMsgs, 2*iter)
		}

		ibb := 2 * obb
		if nc.InBytes != ibb {
			t.Fatalf("Not properly tracking InBytes: received %d, wanted %d", nc.InBytes, ibb)
		}
	})
}

func TestRaceSafeStats(t *testing.T) {
	withServer(t, func(t *testing.T, nc *nats.Conn) {
		go nc.Publish("foo", []byte("Hello World"))
		time.Sleep(200 * time.Millisecond)

		stats := nc.Stats()
		if stats.OutMsgs != uint64(1) {
			t.Fatalf("Not properly tracking OutMsgs: received %d, wanted %d", nc.OutMsgs, 1)
		}
	})
}

func TestBadSubject(t *testing.T) {
	withServer(t, func(t *testing.T, nc *nats.Conn) {
		if err := nc.Publish("", []byte("Hello World")); !errors.Is(err, nats.ErrBadSubject) {
			t.Fatalf("Expected a ErrBadSubject error: Got %v", err)
		}
		if err := nc.Publish("foo bar", []byte("Hello World")); !errors.Is(err, nats.ErrBadSubject) {
			t.Fatalf("Expected a ErrBadSubject error: Got %v", err)
		}
		msg := &nats.Msg{Subject: "foo", Reply: "bar baz", Data: []byte("Hello World")}
		if err := nc.PublishMsg(msg); !errors.Is(err, nats.ErrBadSubject) {
			t.Fatalf("Expected a ErrBadSubject error: Got %v", err)
		}
	})
}

func TestOptions(t *testing.T) {
	withServerInstance(t, func(t *testing.T, _ *nats.Conn, inst *testservice.Instance) {
		rch := make(chan bool, 1)
		cch := make(chan bool, 1)

		nc, err := nats.Connect(inst.Servers[0].URL,
			nats.Name("myName"),
			nats.MaxReconnects(2),
			nats.ReconnectWait(50*time.Millisecond),
			nats.ReconnectJitter(0, 0),
			nats.PingInterval(20*time.Millisecond),
		)
		if err != nil {
			t.Fatalf("Failed to connect: %v", err)
		}
		t.Cleanup(nc.Close)

		nc.SetReconnectHandler(func(_ *nats.Conn) { rch <- true })
		nc.SetClosedHandler(func(_ *nats.Conn) { cch <- true })

		// Stop + Start the only server on the same port to trigger reconnect.
		inst.StopServer(t, inst.Servers[0])
		inst.StartServer(t, inst.Servers[0])

		if err := Wait(rch); err != nil {
			t.Fatal("Failed getting reconnected cb")
		}

		nc.Close()
		if err := Wait(cch); err != nil {
			t.Fatal("Failed getting closed cb")
		}

		// Second connection with NoReconnect — stopping the server should NOT
		// trigger a reconnect callback.
		nc2, err := nats.Connect(inst.Servers[0].URL, nats.NoReconnect())
		if err != nil {
			t.Fatalf("Failed to connect: %v", err)
		}
		t.Cleanup(nc2.Close)

		nc2.SetReconnectHandler(func(_ *nats.Conn) { rch <- true })
		nc2.SetClosedHandler(func(_ *nats.Conn) { cch <- true })

		inst.StopServer(t, inst.Servers[0])

		if err := WaitTime(rch, time.Second); err == nil {
			t.Fatal("Unexpected reconnect cb")
		}

		nc2.Close()
		if err := Wait(cch); err != nil {
			t.Fatal("Failed getting closed cb")
		}
	})
}

func TestNilConnection(t *testing.T) {
	var nc *nats.Conn
	data := []byte("ok")

	if err := nc.Publish("foo", data); err == nil || err != nats.ErrInvalidConnection {
		t.Fatalf("Expected ErrInvalidConnection error, got %v", err)
	}
	if err := nc.PublishMsg(nil); err == nil || err != nats.ErrInvalidMsg {
		t.Fatalf("Expected ErrInvalidMsg error, got %v", err)
	}
	if err := nc.PublishMsg(&nats.Msg{}); err == nil || err != nats.ErrInvalidConnection {
		t.Fatalf("Expected ErrInvalidConnection error, got %v", err)
	}
	if err := nc.PublishRequest("foo", "reply", data); err == nil || err != nats.ErrInvalidConnection {
		t.Fatalf("Expected ErrInvalidConnection error, got %v", err)
	}

	if _, err := nc.Subscribe("foo", nil); err == nil || err != nats.ErrInvalidConnection {
		t.Fatalf("Expected ErrInvalidConnection error, got %v", err)
	}
	if _, err := nc.SubscribeSync("foo"); err == nil || err != nats.ErrInvalidConnection {
		t.Fatalf("Expected ErrInvalidConnection error, got %v", err)
	}
	if _, err := nc.QueueSubscribe("foo", "bar", nil); err == nil || err != nats.ErrInvalidConnection {
		t.Fatalf("Expected ErrInvalidConnection error, got %v", err)
	}
	ch := make(chan *nats.Msg)
	if _, err := nc.ChanSubscribe("foo", ch); err == nil || err != nats.ErrInvalidConnection {
		t.Fatalf("Expected ErrInvalidConnection error, got %v", err)
	}
	if _, err := nc.ChanQueueSubscribe("foo", "bar", ch); err == nil || err != nats.ErrInvalidConnection {
		t.Fatalf("Expected ErrInvalidConnection error, got %v", err)
	}
	if _, err := nc.QueueSubscribeSyncWithChan("foo", "bar", ch); err == nil || err != nats.ErrInvalidConnection {
		t.Fatalf("Expected ErrInvalidConnection error, got %v", err)
	}

	if err := nc.Flush(); err == nil || err != nats.ErrInvalidConnection {
		t.Fatalf("Expected ErrInvalidConnection error, got %v", err)
	}
	if err := nc.FlushTimeout(time.Millisecond); err == nil || err != nats.ErrInvalidConnection {
		t.Fatalf("Expected ErrInvalidConnection error, got %v", err)
	}

	var sub *nats.Subscription
	if sub.Type() != nats.NilSubscription {
		t.Fatalf("Got wrong type for nil subscription, %v", sub.Type())
	}
	if sub.IsValid() {
		t.Fatalf("Expected IsValid() to return false")
	}
	if err := sub.Unsubscribe(); err == nil || err != nats.ErrBadSubscription {
		t.Fatalf("Expected Unsubscribe to return proper error, got %v", err)
	}
	if err := sub.AutoUnsubscribe(1); err == nil || err != nats.ErrBadSubscription {
		t.Fatalf("Expected ErrBadSubscription error, got %v", err)
	}
	if _, err := sub.NextMsg(time.Millisecond); err == nil || err != nats.ErrBadSubscription {
		t.Fatalf("Expected ErrBadSubscription error, got %v", err)
	}
	if _, _, err := sub.Pending(); err == nil || err != nats.ErrBadSubscription {
		t.Fatalf("Expected ErrBadSubscription error, got %v", err)
	}
	if _, _, err := sub.MaxPending(); err == nil || err != nats.ErrBadSubscription {
		t.Fatalf("Expected ErrBadSubscription error, got %v", err)
	}
	if err := sub.ClearMaxPending(); err == nil || err != nats.ErrBadSubscription {
		t.Fatalf("Expected ErrBadSubscription error, got %v", err)
	}
	if _, _, err := sub.PendingLimits(); err == nil || err != nats.ErrBadSubscription {
		t.Fatalf("Expected ErrBadSubscription error, got %v", err)
	}
	if err := sub.SetPendingLimits(1, 1); err == nil || err != nats.ErrBadSubscription {
		t.Fatalf("Expected ErrBadSubscription error, got %v", err)
	}
	if _, err := sub.Delivered(); err == nil || err != nats.ErrBadSubscription {
		t.Fatalf("Expected ErrBadSubscription error, got %v", err)
	}
	if _, err := sub.Dropped(); err == nil || err != nats.ErrBadSubscription {
		t.Fatalf("Expected ErrBadSubscription error, got %v", err)
	}
}
