// Copyright 2022-2023 The NATS Authors
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package jetstream

import (
	"errors"
	"fmt"
	"testing"
	"testing/synctest"
	"time"

	"github.com/nats-io/nats.go"
)

func TestJetStreamReconnectErrorCallback(t *testing.T) {
	synctest.Test(t, func(t *testing.T) {
		msg := &nats.Msg{Subject: "events", Data: []byte("pending")}
		called := make(chan struct{}, 1)
		js := &jetStream{publisher: &jetStreamClient{}}
		js.publisher.connStatusCh = make(chan nats.Status)
		js.publisher.acks = map[string]*pubAckFuture{"pending": {msg: msg}}
		done := js.PublishAsyncComplete()
		js.publisher.aecb = func(ctx JetStream, got *nats.Msg, err error) {
			if got != msg || !errors.Is(err, nats.ErrDisconnected) {
				t.Errorf("Unexpected callback: message=%p, error=%v", got, err)
			}
			if pending := ctx.PublishAsyncPending(); pending != 0 {
				t.Errorf("Expected pending publishes to be cleared, got %d", pending)
			}
			select {
			case <-done:
				t.Error("PublishAsyncComplete closed before the error callback returned")
			default:
			}
			called <- struct{}{}
		}
		go js.resetPendingAcksOnReconnect()
		defer func() {
			close(js.publisher.connStatusCh)
			synctest.Wait()
		}()
		js.publisher.connStatusCh <- nats.RECONNECTING
		synctest.Wait()
		select {
		case <-called:
		default:
			t.Fatal("Reconnect error callback was deferred until shutdown")
		}
		select {
		case <-done:
		default:
			t.Fatal("PublishAsyncComplete was not closed after the error callback returned")
		}
	})
}

func TestMessageMetadata(t *testing.T) {
	tests := []struct {
		name             string
		givenReply       string
		expectedMetadata MsgMetadata
		withError        error
	}{
		{
			name:       "valid metadata",
			givenReply: "$JS.ACK.domain.hash-123.stream.cons.5.10.20.123456789.1.token",
			expectedMetadata: MsgMetadata{
				Sequence: SequencePair{
					Consumer: 20,
					Stream:   10,
				},
				NumDelivered: 5,
				NumPending:   1,
				Timestamp:    time.Unix(0, 123456789),
				Stream:       "stream",
				Consumer:     "cons",
				Domain:       "domain",
			},
		},
		{
			name:       "no reply subject",
			givenReply: "",
			withError:  ErrMsgNoReply,
		},
		{
			name:       "not a JetStream message",
			givenReply: "ABC",
			withError:  ErrNotJSMessage,
		},
	}

	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			msg := &jetStreamMsg{
				msg: &nats.Msg{
					Reply: test.givenReply,
					Sub:   &nats.Subscription{},
				},
			}
			res, err := msg.Metadata()
			if test.withError != nil {
				if err == nil || !errors.Is(err, test.withError) {
					t.Fatalf("Expected error: %v; got: %v", test.withError, err)
				}
				return
			}
			if err != nil {
				t.Fatalf("Unexpected error: %v", err)
			}
			if *res != test.expectedMetadata {
				t.Fatalf("Invalid metadata; want: %v; got: %v", test.expectedMetadata, res)
			}
		})
	}
}

func TestValidateSubject(t *testing.T) {
	tests := []struct {
		subject   string
		withError bool
	}{
		{"test.A", false},
		{"test.*", false},
		{"*", false},
		{"*.*", false},
		{"test.*.A", false},
		{"test.>", false},
		{">", false},
		{">.", true},
		{"test.>.A", true},
		{"", true},
		{"test A", true},
	}

	for _, test := range tests {
		tName := fmt.Sprintf("subj=%s,err=%t", test.subject, test.withError)
		t.Run(tName, func(t *testing.T) {
			err := validateSubject(test.subject)
			if test.withError {
				if err == nil {
					t.Fatal("Expected error; got nil")
				}
				return
			}
			if err != nil {
				t.Fatalf("Unexpected error: %v", err)
			}
		})
	}
}

func TestValidateStreamName(t *testing.T) {
	tests := []struct {
		name      string
		withError bool
	}{
		{"test", false},
		{"test-stream_1", false},
		{"", true},
		{"stream.name", true},
		{"stream name", true},
		{"stream>", true},
		{"stream*", true},
		{"stream/name", true},
		{"stream\\name", true},
		{"stream\tname", true},
		{"stream\rname", true},
		{"stream\nname", true},
	}

	for _, test := range tests {
		t.Run(fmt.Sprintf("name=%q,err=%t", test.name, test.withError), func(t *testing.T) {
			err := validateStreamName(test.name)
			if test.withError {
				if err == nil {
					t.Fatal("Expected error; got nil")
				}
				return
			}
			if err != nil {
				t.Fatalf("Unexpected error: %v", err)
			}
		})
	}
}

func TestValidateConsumerName(t *testing.T) {
	tests := []struct {
		name      string
		withError bool
	}{
		{"test", false},
		{"test-consumer_1", false},
		{"", true},
		{"consumer.name", true},
		{"consumer name", true},
		{"consumer>", true},
		{"consumer*", true},
		{"consumer/name", true},
		{"consumer\\name", true},
		{"consumer\tname", true},
		{"consumer\rname", true},
		{"consumer\nname", true},
	}

	for _, test := range tests {
		t.Run(fmt.Sprintf("name=%q,err=%t", test.name, test.withError), func(t *testing.T) {
			err := validateConsumerName(test.name)
			if test.withError {
				if err == nil {
					t.Fatal("Expected error; got nil")
				}
				return
			}
			if err != nil {
				t.Fatalf("Unexpected error: %v", err)
			}
		})
	}
}

func TestRetryWithBackoff(t *testing.T) {
	tests := []struct {
		name                  string
		givenOpts             backoffOpts
		withError             bool
		timeout               time.Duration
		cancelAfter           time.Duration
		successfulAttemptNum  int
		expectedAttemptsCount int
	}{
		{
			name: "infinite attempts, 5 tries before success",
			givenOpts: backoffOpts{
				attempts:        -1,
				initialInterval: 10 * time.Millisecond,
				maxInterval:     60 * time.Millisecond,
			},
			withError:            false,
			successfulAttemptNum: 5,
			// 0ms + 10ms + 20ms + 40ms + 60ms = 130ms
			timeout:               200 * time.Millisecond,
			expectedAttemptsCount: 5,
		},
		{
			name: "infinite attempts, 5 tries before success, without initial execution",
			givenOpts: backoffOpts{
				attempts:                -1,
				initialInterval:         10 * time.Millisecond,
				disableInitialExecution: true,
				factor:                  2,
				maxInterval:             60 * time.Millisecond,
			},
			withError:            false,
			successfulAttemptNum: 5,
			// 10ms + 20ms + 40ms + 60ms + 60 = 190ms
			timeout:               250 * time.Millisecond,
			expectedAttemptsCount: 5,
		},
		{
			name: "5 attempts, unsuccessful",
			givenOpts: backoffOpts{
				attempts:        5,
				initialInterval: 10 * time.Millisecond,
				factor:          2,
				maxInterval:     60 * time.Millisecond,
			},
			withError: true,
			// 0ms + 10ms + 20ms + 40ms + 60ms = 130ms
			timeout:               200 * time.Millisecond,
			expectedAttemptsCount: 5,
		},
		{
			name: "custom backoff values, should override other settings",
			givenOpts: backoffOpts{
				initialInterval: 2 * time.Second,
				factor:          2,
				maxInterval:     100 * time.Millisecond,
				customBackoff:   []time.Duration{10 * time.Millisecond, 20 * time.Millisecond, 30 * time.Millisecond, 40 * time.Millisecond, 50 * time.Millisecond},
			},
			withError:            false,
			successfulAttemptNum: 4,
			// 10ms + 20ms + 30ms + 40ms = 100ms
			timeout:               150 * time.Millisecond,
			expectedAttemptsCount: 4,
		},
		{
			name: "no custom backoff, with cancel",
			givenOpts: backoffOpts{
				attempts:        -1,
				initialInterval: 100 * time.Millisecond,
				factor:          1,
			},
			withError:             false,
			cancelAfter:           150 * time.Millisecond,
			timeout:               200 * time.Millisecond,
			expectedAttemptsCount: 2,
		},
		{
			name: "custom backoff, with cancel",
			givenOpts: backoffOpts{
				customBackoff: []time.Duration{100 * time.Millisecond, 100 * time.Millisecond, 100 * time.Millisecond},
			},
			cancelAfter:           150 * time.Millisecond,
			expectedAttemptsCount: 1,
			timeout:               200 * time.Millisecond,
		},
		{
			name: "attempts num not provided",
			givenOpts: backoffOpts{
				initialInterval: 100 * time.Millisecond,
				factor:          1,
			},
			withError:             true,
			timeout:               1 * time.Second,
			expectedAttemptsCount: 1,
		},
		{
			name: "custom backoff, but attempts num provided",
			givenOpts: backoffOpts{
				customBackoff: []time.Duration{100 * time.Millisecond, 100 * time.Millisecond, 100 * time.Millisecond},
				attempts:      5,
			},
			withError:             true,
			timeout:               1 * time.Second,
			expectedAttemptsCount: 1,
		},
	}

	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			ok := make(chan struct{})
			errs := make(chan error, 1)

			var cancelChan chan struct{}
			if test.cancelAfter != 0 {
				cancelChan = make(chan struct{})
				test.givenOpts.cancel = cancelChan
			}
			var count int
			go func() {
				err := retryWithBackoff(func(attempt int) (bool, error) {
					count = attempt
					if test.successfulAttemptNum != 0 && attempt == test.successfulAttemptNum-1 {
						return false, nil
					}
					return true, fmt.Errorf("error %d", attempt)
				}, test.givenOpts)
				if err != nil {
					errs <- err
					return
				}
				close(ok)
			}()
			if test.cancelAfter > 0 {
				go func() {
					time.Sleep(test.cancelAfter)
					close(cancelChan)
				}()
			}
			select {
			case <-ok:
				if test.withError {
					t.Fatal("Expected error; got nil")
				}
			case err := <-errs:
				if !test.withError {
					t.Fatalf("Unexpected error: %v", err)
				}
			case <-time.After(test.timeout):
				t.Fatalf("Timeout after %v", test.timeout)
			}

			if count != test.expectedAttemptsCount-1 {
				t.Fatalf("Invalid count; got: %d, want: %d", count, test.expectedAttemptsCount-1)
			}
		})
	}
}

func TestPullConsumer_checkPendingAfterDone(t *testing.T) {
	// Once the subscription is stopped or drained, pullMessages no longer
	// reads fetchNext. Messages delivered while draining still call
	// checkPending (with the lock held), and fetchNext only buffers one
	// request, so checkPending must not block on a full fetchNext.
	sub := &pullSubscription{
		pending: pendingMsgs{
			msgCount: 4,
		},
		consumeOpts: &consumeOpts{
			ThresholdMessages: 5,
			MaxMessages:       10,
		},
		done:      make(chan struct{}, 1),
		fetchNext: make(chan *pullRequest, 1),
	}
	// A request queued before pullMessages returned, which nobody reads.
	sub.fetchNext <- &pullRequest{}
	close(sub.done)

	returned := make(chan struct{})
	go func() {
		sub.Lock()
		sub.checkPending()
		sub.Unlock()
		close(returned)
	}()
	select {
	case <-returned:
	case <-time.After(5 * time.Second):
		t.Fatal("checkPending blocked on fetchNext after the subscription was done")
	}
}

func TestPullSubscriptionResetPendingStopAfter(t *testing.T) {
	for _, tc := range []struct {
		name                       string
		stopAfter, delivered, want int
	}{
		{"unlimited", 0, 200, 500},
		{"full batch", 800, 200, 500},
		{"initial shortened batch", 450, 0, 450},
		{"remaining shortened batch", 450, 200, 250},
		{"complete", 450, 450, 0},
	} {
		t.Run(tc.name, func(t *testing.T) {
			sub := &pullSubscription{
				consumeOpts: &consumeOpts{MaxMessages: 500, MaxBytes: 10000, StopAfter: tc.stopAfter},
				delivered:   tc.delivered,
			}
			sub.resetPendingMsgs()
			if got := sub.pending.msgCount; got != tc.want {
				t.Errorf("pending messages: got %d, want %d", got, tc.want)
			}
			if got := sub.pending.byteCount; got != 10000 {
				t.Errorf("pending bytes: got %d, want 10000", got)
			}
		})
	}
}

func TestPullConsumer_checkPending(t *testing.T) {

	tests := []struct {
		name                string
		givenSub            *pullSubscription
		fetchInProgress     bool
		shouldSend          bool
		expectedPullRequest *pullRequest
		expectedPendingMsgs int
	}{
		{
			name:                "msgs threshold not reached, bytes not set, no pull request",
			expectedPendingMsgs: 10,
			givenSub: &pullSubscription{
				pending: pendingMsgs{
					msgCount: 10,
				},
				consumeOpts: &consumeOpts{
					ThresholdMessages: 5,
					MaxMessages:       10,
				},
			},
			shouldSend: false,
		},
		{
			name:                "pending msgs below threshold, send pull request",
			expectedPendingMsgs: 10,
			givenSub: &pullSubscription{
				pending: pendingMsgs{
					msgCount:  4,
					byteCount: 400, // byte count should be ignored
				},
				consumeOpts: &consumeOpts{
					ThresholdMessages: 5,
					MaxMessages:       10,
				},
			},
			shouldSend: true,
			expectedPullRequest: &pullRequest{
				Batch:    6,
				MaxBytes: 0,
			},
		},
		{
			name:                "pending msgs below threshold but PR in progress",
			expectedPendingMsgs: 4,
			givenSub: &pullSubscription{
				pending: pendingMsgs{
					msgCount: 4,
				},
				consumeOpts: &consumeOpts{
					ThresholdMessages: 5,
					MaxMessages:       10,
				},
			},
			fetchInProgress: true,
			shouldSend:      false,
		},
		{
			name:                "pending bytes below threshold, send pull request",
			expectedPendingMsgs: 1000000,
			givenSub: &pullSubscription{
				pending: pendingMsgs{
					byteCount: 400,
					msgCount:  1000000, // msgs count should be ignored
				},
				consumeOpts: &consumeOpts{
					MaxMessages:    1000000,
					ThresholdBytes: 500,
					MaxBytes:       1000,
				},
			},
			shouldSend: true,
			expectedPullRequest: &pullRequest{
				Batch:    1000000,
				MaxBytes: 600,
			},
		},
		{
			name:                "pending bytes above threshold, no pull request",
			expectedPendingMsgs: 0,
			givenSub: &pullSubscription{
				pending: pendingMsgs{
					byteCount: 600,
				},
				consumeOpts: &consumeOpts{
					ThresholdBytes: 500,
					MaxBytes:       1000,
				},
			},
			shouldSend: false,
		},
		{
			name:                "pending bytes below threshold, fetch in progress, no pull request",
			expectedPendingMsgs: 0,
			givenSub: &pullSubscription{
				pending: pendingMsgs{
					byteCount: 400,
				},
				consumeOpts: &consumeOpts{
					ThresholdBytes: 500,
					MaxBytes:       1000,
				},
			},
			fetchInProgress: true,
			shouldSend:      false,
		},
		{
			name:                "StopAfter set, pending msgs below StopAfter, send pull request",
			expectedPendingMsgs: 6,
			givenSub: &pullSubscription{
				pending: pendingMsgs{
					msgCount: 4,
				},
				consumeOpts: &consumeOpts{
					ThresholdMessages: 5,
					MaxMessages:       10,
					StopAfter:         8,
				},
				delivered: 2,
			},
			shouldSend: true,
			expectedPullRequest: &pullRequest{
				Batch:    2, // StopAfter (8) - delivered (2) - pending (4)
				MaxBytes: 0,
			},
		},
		{
			name:                "StopAfter with message and byte limits",
			expectedPendingMsgs: 6,
			givenSub: &pullSubscription{
				pending: pendingMsgs{msgCount: 4, byteCount: 400},
				consumeOpts: &consumeOpts{
					ThresholdMessages: 5, MaxMessages: 10, MaxBytes: 1000,
					LimitSize: true, StopAfter: 8,
				},
				delivered: 2,
			},
			shouldSend:          true,
			expectedPullRequest: &pullRequest{Batch: 2, MaxBytes: 1000},
		},
		{
			name:                "StopAfter with bytes threshold",
			expectedPendingMsgs: 6,
			givenSub: &pullSubscription{
				pending: pendingMsgs{msgCount: 4, byteCount: 400},
				consumeOpts: &consumeOpts{
					MaxMessages: 1000000, ThresholdBytes: 500, MaxBytes: 1000, StopAfter: 8,
				},
				delivered: 2,
			},
			shouldSend:          true,
			expectedPullRequest: &pullRequest{Batch: 2, MaxBytes: 600},
		},
		{
			name:                "StopAfter set, pending msgs equal to StopAfter, no pull request",
			expectedPendingMsgs: 6,
			givenSub: &pullSubscription{
				pending: pendingMsgs{
					msgCount: 6,
				},
				consumeOpts: &consumeOpts{
					ThresholdMessages: 5,
					MaxMessages:       10,
					StopAfter:         6,
				},
				delivered: 0,
			},
			shouldSend: false,
		},
	}

	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			prChan := make(chan *pullRequest, 1)
			test.givenSub.fetchNext = prChan
			if test.fetchInProgress {
				test.givenSub.fetchInProgress.Store(1)
			}
			errs := make(chan error, 1)
			ok := make(chan struct{}, 1)
			go func() {
				if test.shouldSend {
					select {
					case pr := <-prChan:
						if *pr != *test.expectedPullRequest {
							errs <- fmt.Errorf("Invalid pull request; want: %#v; got: %#v", test.expectedPullRequest, pr)
							return
						}
						ok <- struct{}{}
					case <-time.After(1 * time.Second):
						errs <- errors.New("Timeout")
						return
					}
				} else {
					select {
					case <-prChan:
						errs <- errors.New("Unexpected pull request")
					case <-time.After(100 * time.Millisecond):
						ok <- struct{}{}
						return
					}
				}
			}()

			test.givenSub.checkPending()
			if got := test.givenSub.pending.msgCount; got != test.expectedPendingMsgs {
				t.Errorf("pending message count: got %d, want %d", got, test.expectedPendingMsgs)
			}
			select {
			case <-ok:
				// ok
			case err := <-errs:
				t.Fatal(err)
			}

		})
	}
}

func TestHeartbeatMonitorReleasedOnSubscriptionEnd(t *testing.T) {
	// A heartbeat timer left armed after consuming ended keeps the
	// subscription, and through it the consumer and the connection,
	// reachable until it fires (2x the heartbeat interval).
	const heartbeat = time.Hour

	// timerActive reports whether the monitor's timer was still pending.
	// It stops the timer as a side effect.
	timerActive := func(hb *hbMonitor) bool {
		hb.Lock()
		defer hb.Unlock()
		return hb.timer.Stop()
	}

	t.Run("pull, subscription already closed", func(t *testing.T) {
		nc := &nats.Conn{}
		sub := &pullSubscription{
			consumer:          &pullConsumer{js: &jetStream{conn: nc}},
			subscription:      &nats.Subscription{}, // not valid, as after the connection was closed
			done:              make(chan struct{}),
			errs:              make(chan error, 10),
			connStatusChanged: nc.StatusChanged(nats.CONNECTED, nats.RECONNECTING, nats.CLOSED),
			consumeOpts:       &consumeOpts{Heartbeat: heartbeat},
		}
		sub.hbMonitor = sub.scheduleHeartbeatCheck(heartbeat)

		sub.Stop()
		sub.cleanup()

		if timerActive(sub.hbMonitor) {
			t.Fatal("Expected heartbeat timer to be stopped after cleanup")
		}
		select {
		case _, ok := <-sub.connStatusChanged:
			if ok {
				t.Fatal("Unexpected status on removed listener")
			}
		default:
			t.Fatal("Expected status listener to be removed after cleanup")
		}

		// A message handler or the status goroutine still in flight
		// must not re-arm the timer.
		sub.hbMonitor.Reset(2 * heartbeat)
		if timerActive(sub.hbMonitor) {
			t.Fatal("Expected heartbeat timer not to be re-armed after cleanup")
		}
	})

	t.Run("push, drained", func(t *testing.T) {
		nc := &nats.Conn{}
		sub := &pushSubscription{
			conn:              nc,
			subscription:      &nats.Subscription{},
			done:              make(chan struct{}),
			errs:              make(chan error, 1),
			connStatusChanged: nc.StatusChanged(nats.CONNECTED, nats.RECONNECTING),
			idleHeartbeat:     heartbeat,
		}
		sub.hbMonitor = sub.scheduleHeartbeatCheck(heartbeat)

		sub.Drain()

		// While draining, buffered messages are still delivered to the
		// handler, which resets the timer when it returns.
		sub.hbMonitor.Reset(2 * heartbeat)
		if timerActive(sub.hbMonitor) {
			t.Fatal("Expected heartbeat timer not to be re-armed after drain")
		}
		select {
		case _, ok := <-sub.connStatusChanged:
			if ok {
				t.Fatal("Unexpected status on removed listener")
			}
		default:
			t.Fatal("Expected status listener to be removed after drain")
		}
	})
}

func TestPullSubscriptionDrainConcurrentWithNext(t *testing.T) {
	// Next must not report a draining iterator as closed while messages
	// are still buffered. The race window is a few instructions wide,
	// hence the repetitions.
	const buffered = 50
	for range 2000 {
		sub := &pullSubscription{
			consumer:    &pullConsumer{js: &jetStream{conn: &nats.Conn{}}},
			msgs:        make(chan *nats.Msg, buffered),
			done:        make(chan struct{}),
			consumeOpts: &consumeOpts{},
		}
		// Nothing serves pull requests here.
		sub.fetchInProgress.Store(1)
		for range buffered {
			sub.msgs <- &nats.Msg{Subject: "foo", Data: []byte("x")}
		}

		drained := make(chan struct{})
		go func() {
			sub.Drain()
			close(drained)
		}()
		for i := range buffered {
			if _, err := sub.Next(); err != nil {
				t.Fatalf("Next %d of %d buffered messages: %v", i+1, buffered, err)
			}
		}
		<-drained
	}
}

func TestIsWrongLastSeqErr(t *testing.T) {
	// 10164 is the replicated-stream variant of the 10071 "wrong last
	// sequence" CAS conflict; both must be recognized (issue #2097).
	for _, code := range []ErrorCode{JSErrCodeStreamWrongLastSequence, JSErrCodeStreamWrongLastSequenceConstant} {
		if !isWrongLastSeqErr(&APIError{Code: 400, ErrorCode: code}) {
			t.Fatalf("err code %d should be recognized as wrong-last-sequence", code)
		}
	}
	if isWrongLastSeqErr(&APIError{Code: 404, ErrorCode: JSErrCodeStreamNotFound}) {
		t.Fatal("unrelated error code should not be recognized")
	}
}

func TestMapRevisionMismatch(t *testing.T) {
	// Both 10071 and its replicated-stream variant 10164 must map to
	// ErrKeyRevisionMismatch, while preserving the underlying
	// APIError for callers that inspect the code.
	for _, code := range []ErrorCode{JSErrCodeStreamWrongLastSequence, JSErrCodeStreamWrongLastSequenceConstant} {
		err := mapRevisionMismatch(&APIError{Code: 400, ErrorCode: code})
		if !errors.Is(err, ErrKeyRevisionMismatch) {
			t.Fatalf("err code %d should map to ErrKeyRevisionMismatch, got: %v", code, err)
		}
		var apiErr *APIError
		if !errors.As(err, &apiErr) || apiErr.ErrorCode != code {
			t.Fatalf("underlying APIError (code %d) should be preserved, got: %v", code, err)
		}
	}

	// Unrelated errors pass through untouched.
	other := &APIError{Code: 404, ErrorCode: JSErrCodeStreamNotFound}
	if err := mapRevisionMismatch(other); err != other || errors.Is(err, ErrKeyRevisionMismatch) {
		t.Fatalf("unrelated error should pass through unchanged, got: %v", err)
	}

	if mapRevisionMismatch(nil) != nil {
		t.Fatal("nil should map to nil")
	}
}

func TestKV_keyValid(t *testing.T) {
	tests := []struct {
		key string
		ok  bool
	}{
		{key: "foo123", ok: true},
		{key: "foo.bar", ok: true},
		{key: "Foo.123=bar_baz-abc", ok: true},
		{key: "foo.*.bar", ok: false},
		{key: "foo.>", ok: false},
		{key: ">", ok: false},
		{key: "*", ok: false},
		{key: "foo!", ok: false},
		{key: "foo bar", ok: false},
		{key: "", ok: false},
		{key: " ", ok: false},
		{key: ".", ok: false},
		{key: ".foo", ok: false},
		{key: "foo.", ok: false},
	}

	for _, test := range tests {
		t.Run(test.key, func(t *testing.T) {
			res := keyValid(test.key)
			if res != test.ok {
				t.Fatalf("Invalid result; want: %v; got: %v", test.ok, res)
			}
		})
	}
}

func TestKV_searchKeyValid(t *testing.T) {
	tests := []struct {
		key string
		ok  bool
	}{
		{key: "foo123", ok: true},
		{key: "foo.bar", ok: true},
		{key: "Foo.123=bar_baz-abc", ok: true},
		{key: "foo.*.bar", ok: true},
		{key: "foo.>", ok: true},
		{key: ">", ok: true},
		{key: "*", ok: true},
		{key: "foo!", ok: false},
		{key: "foo bar", ok: false},
		{key: "", ok: false},
		{key: " ", ok: false},
		{key: ".", ok: false},
		{key: ".foo", ok: false},
		{key: "foo.", ok: false},
	}

	for _, test := range tests {
		t.Run(test.key, func(t *testing.T) {
			res := searchKeyValid(test.key)
			if res != test.ok {
				t.Fatalf("Invalid result; want: %v; got: %v", test.ok, res)
			}
		})
	}
}

func TestKV_bucketValid(t *testing.T) {
	tests := []struct {
		key string
		ok  bool
	}{
		{key: "foo123", ok: true},
		{key: "Foo123-bar_baz", ok: true},
		{key: "foo.bar", ok: false},
		{key: "foo.*.bar", ok: false},
		{key: "foo.>", ok: false},
		{key: ">", ok: false},
		{key: "*", ok: false},
		{key: "foo!", ok: false},
		{key: "foo bar", ok: false},
		{key: "", ok: false},
		{key: " ", ok: false},
		{key: ".", ok: false},
		{key: ".foo", ok: false},
		{key: "foo.", ok: false},
	}

	for _, test := range tests {
		t.Run(test.key, func(t *testing.T) {
			res := bucketValid(test.key)
			if res != test.ok {
				t.Fatalf("Invalid result; want: %v; got: %v", test.ok, res)
			}
		})
	}
}

func TestSerialNumberFromConsumer(t *testing.T) {
	tests := []struct {
		name     string
		expected int
	}{
		{name: "prefix_5", expected: 5},
		{name: "prefix_with_underscores_12", expected: 12},
		{name: "prefix", expected: 0},
		{name: "prefix_", expected: 0},
		{name: "prefix_abc", expected: 0},
		{name: "", expected: 0},
	}

	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			if res := serialNumberFromConsumer(test.name); res != test.expected {
				t.Fatalf("Invalid result; want: %d; got: %d", test.expected, res)
			}
		})
	}

	t.Run("no allocations", func(t *testing.T) {
		allocs := testing.AllocsPerRun(100, func() {
			if serialNumberFromConsumer("prefix_5") != 5 {
				t.Fatal("invalid serial")
			}
		})
		if allocs != 0 {
			t.Fatalf("Expected no allocations; got: %v", allocs)
		}
	})
}
