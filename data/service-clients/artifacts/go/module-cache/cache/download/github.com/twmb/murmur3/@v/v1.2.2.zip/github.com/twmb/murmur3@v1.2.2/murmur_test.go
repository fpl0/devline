package murmur3_test

import (
	"crypto/rand"
	"encoding/binary"
	"fmt"
	"hash"
	"io"
	"strconv"
	"testing"
	"testing/quick"
	"unsafe"

	. "github.com/twmb/murmur3"
	"github.com/twmb/murmur3/testdata"
)

var isLittleEndian = func() bool {
	i := uint16(1)
	return (*(*[2]byte)(unsafe.Pointer(&i)))[0] == 1
}()

var data = []struct {
	h32   uint32
	h64_1 uint64
	h64_2 uint64
	s     string
}{
	{0x00000000, 0x0000000000000000, 0x0000000000000000, ""},
	{0x248bfa47, 0xcbd8a7b341bd9b02, 0x5b1e906a48ae1d19, "hello"},
	{0x149bbb7f, 0x342fac623a5ebc8e, 0x4cdcbc079642414d, "hello, world"},
	{0xe31e8a70, 0xb89e5988b737affc, 0x664fc2950231b2cb, "19 Jan 2038 at 3:14:07 AM"},
	{0xd5c48bfc, 0xcd99481f9ee902c9, 0x695da1a38987b6e7, "The quick brown fox jumps over the lazy dog."},
}

func TestRef(t *testing.T) {
	for _, elem := range data {

		var h32 hash.Hash32 = New32()
		h32.Write([]byte(elem.s))
		if v := h32.Sum32(); v != elem.h32 {
			t.Errorf("'%s': 0x%x (want 0x%x)", elem.s, v, elem.h32)
		}

		var h32_byte hash.Hash32 = New32()
		h32_byte.Write([]byte(elem.s))
		target := fmt.Sprintf("%08x", elem.h32)
		if p := fmt.Sprintf("%x", h32_byte.Sum(nil)); p != target {
			t.Errorf("'%s': %s (want %s)", elem.s, p, target)
		}
		if n := h32_byte.Size(); n != 4 {
			t.Errorf("New32: Size %d (want 4)", n)
		}

		if v := Sum32([]byte(elem.s)); v != elem.h32 {
			t.Errorf("'%s': 0x%x (want 0x%x)", elem.s, v, elem.h32)
		}

		var h64 hash.Hash64 = New64()
		h64.Write([]byte(elem.s))
		if v := h64.Sum64(); v != elem.h64_1 {
			t.Errorf("'%s': 0x%x (want 0x%x)", elem.s, v, elem.h64_1)
		}

		var h64_byte hash.Hash64 = New64()
		h64_byte.Write([]byte(elem.s))
		target = fmt.Sprintf("%016x", elem.h64_1)
		if p := fmt.Sprintf("%x", h64_byte.Sum(nil)); p != target {
			t.Errorf("New64: '%s': %s (want %s)", elem.s, p, target)
		}
		if n := h64_byte.Size(); n != 8 {
			t.Errorf("New64: Size %d (want 8)", n)
		}

		if v := Sum64([]byte(elem.s)); v != elem.h64_1 {
			t.Errorf("Sum64: '%s': 0x%x (want 0x%x)", elem.s, v, elem.h64_1)
		}

		var h128 Hash128 = New128()
		h128.Write([]byte(elem.s))
		if v1, v2 := h128.Sum128(); v1 != elem.h64_1 || v2 != elem.h64_2 {
			t.Errorf("New128: '%s': 0x%x-0x%x (want 0x%x-0x%x)", elem.s, v1, v2, elem.h64_1, elem.h64_2)
		}

		var h128_byte Hash128 = New128()
		h128_byte.Write([]byte(elem.s))
		target = fmt.Sprintf("%016x%016x", elem.h64_1, elem.h64_2)
		if p := fmt.Sprintf("%x", h128_byte.Sum(nil)); p != target {
			t.Errorf("New128: '%s': %s (want %s)", elem.s, p, target)
		}
		if n := h128_byte.Size(); n != 16 {
			t.Errorf("New128: Size %d (want 16)", n)
		}

		if v1, v2 := Sum128([]byte(elem.s)); v1 != elem.h64_1 || v2 != elem.h64_2 {
			t.Errorf("Sum128: '%s': 0x%x-0x%x (want 0x%x-0x%x)", elem.s, v1, v2, elem.h64_1, elem.h64_2)
		}
	}
}

func TestQuickSum32(t *testing.T) {
	f := func(data []byte) bool {
		goh1 := Sum32(data)
		goh2 := StringSum32(string(data))
		cpph1 := goh1
		if isLittleEndian {
			cpph1 = testdata.SeedSum32(0, data)
		}
		return goh1 == goh2 && goh1 == cpph1
	}
	if err := quick.Check(f, nil); err != nil {
		t.Error(err)
	}
}

func TestQuickSeedSum32(t *testing.T) {
	f := func(seed uint32, data []byte) bool {
		goh1 := SeedSum32(seed, data)
		goh2 := SeedStringSum32(seed, string(data))
		goh3 := func() uint32 { h := SeedNew32(seed); h.Write(data); return binary.BigEndian.Uint32(h.Sum(nil)) }()
		cpph1 := goh1
		if isLittleEndian {
			cpph1 = testdata.SeedSum32(seed, data)
		}
		return goh1 == goh2 && goh1 == goh3 && goh1 == cpph1
	}
	if err := quick.Check(f, nil); err != nil {
		t.Error(err)
	}
}

func TestQuickSum64(t *testing.T) {
	f := func(data []byte) bool {
		goh1 := Sum64(data)
		goh2 := StringSum64(string(data))
		cpph1 := goh1
		if isLittleEndian {
			cpph1 = testdata.SeedSum64(0, data)
		}
		return goh1 == goh2 && goh1 == cpph1
	}
	if err := quick.Check(f, nil); err != nil {
		t.Error(err)
	}
}

func TestQuickSeedSum64(t *testing.T) {
	f := func(seed uint32, data []byte) bool {
		goh1 := SeedSum64(uint64(seed), data)
		goh2 := SeedStringSum64(uint64(seed), string(data))
		goh3 := func() uint64 { h := SeedNew64(uint64(seed)); h.Write(data); return binary.BigEndian.Uint64(h.Sum(nil)) }()
		cpph1 := goh1
		if isLittleEndian {
			cpph1 = testdata.SeedSum64(seed, data)
		}
		return goh1 == goh2 && goh1 == goh3 && goh1 == cpph1
	}
	if err := quick.Check(f, nil); err != nil {
		t.Error(err)
	}
}

func TestQuickSum128(t *testing.T) {
	f := func(data []byte) bool {
		goh1, goh2 := Sum128(data)
		goh3, goh4 := StringSum128(string(data))
		cpph1, cpph2 := goh1, goh2
		if isLittleEndian {
			cpph1, cpph2 = testdata.SeedSum128(0, data)
		}
		return goh1 == goh3 && goh2 == goh4 && goh1 == cpph1 && goh2 == cpph2
	}
	if err := quick.Check(f, nil); err != nil {
		t.Error(err)
	}
}

func TestQuickSeedSum128(t *testing.T) {
	f := func(seed uint32, data []byte) bool {
		goh1, goh2 := SeedSum128(uint64(seed), uint64(seed), data)
		goh3, goh4 := SeedStringSum128(uint64(seed), uint64(seed), string(data))
		goh5, goh6 := func() (uint64, uint64) {
			h := SeedNew128(uint64(seed), uint64(seed))
			h.Write(data)
			sum := h.Sum(nil)
			return binary.BigEndian.Uint64(sum), binary.BigEndian.Uint64(sum[8:])
		}()
		cpph1, cpph2 := goh1, goh2
		if isLittleEndian {
			cpph1, cpph2 = testdata.SeedSum128(seed, data)
		}
		return goh1 == goh3 && goh2 == goh4 &&
			goh1 == goh5 && goh2 == goh6 &&
			goh1 == cpph1 && goh2 == cpph2
	}
	if err := quick.Check(f, nil); err != nil {
		t.Error(err)
	}
}

// go1.14 showed that doing *(*uint32)(unsafe.Pointer(&data[i*4])) was unsafe
// due to alignment issues; this test ensures that we will always catch that.
func TestUnaligned(t *testing.T) {
	in1 := []byte("abcdefghijklmnopqrstuvwxyz")
	in2 := []byte("_abcdefghijklmnopqrstuvwxyz")

	{
		sum1 := Sum32(in1)
		sum2 := Sum32(in2[1:])
		if sum1 != sum2 {
			t.Errorf("%s: got sum1 %v sum2 %v unexpectedly not equal", "Sum32", sum1, sum2)
		}
	}

	{
		sum1 := Sum64(in1)
		sum2 := Sum64(in2[1:])
		if sum1 != sum2 {
			t.Errorf("%s: got sum1 %v sum2 %v unexpectedly not equal", "Sum64", sum1, sum2)
		}
	}

	{
		sum1l, sum1r := Sum128(in1)
		sum2l, sum2r := Sum128(in2[1:])
		if sum1l != sum2l {
			t.Errorf("%s: got sum1l %v sum2l %v unexpectedly not equal", "Sum128 left", sum1l, sum2l)
		}
		if sum1r != sum2r {
			t.Errorf("%s: got sum1r %v sum2r %v unexpectedly not equal", "Sum128 right", sum1r, sum2r)
		}
	}

	{
		sum1 := func() uint32 { n := New32(); n.Write(in1); return n.Sum32() }()
		sum2 := func() uint32 { n := New32(); n.Write(in2[1:]); return n.Sum32() }()
		if sum1 != sum2 {
			t.Errorf("%s: got sum1 %v sum2 %v unexpectedly not equal", "New32", sum1, sum2)
		}
	}

	{
		sum1 := func() uint64 { n := New64(); n.Write(in1); return n.Sum64() }()
		sum2 := func() uint64 { n := New64(); n.Write(in2[1:]); return n.Sum64() }()
		if sum1 != sum2 {
			t.Errorf("%s: got sum1 %v sum2 %v unexpectedly not equal", "New64", sum1, sum2)
		}
	}
}

// TestBoundaries forces every block/tail path to be exercised for Sum32,
// Sum64, and Sum128: the block loop, the single trailing block, and every
// tail length, across several loop iterations.
func TestBoundaries(t *testing.T) {
	const maxCheck = 100
	var data [maxCheck]byte
	for i := 0; !t.Failed() && i < 20; i++ {
		// Check all zeros the first iteration.
		for size := 0; size <= maxCheck; size++ {
			test := data[:size]
			g32h1 := Sum32(test)
			g32h1s := SeedSum32(0, test)
			c32h1 := g32h1
			if isLittleEndian {
				c32h1 = testdata.SeedSum32(0, test)
			}
			if g32h1 != c32h1 {
				t.Errorf("size #%d: in: %x, g32h1 (%d) != c32h1 (%d); attempt #%d", size, test, g32h1, c32h1, i)
			}
			if g32h1s != c32h1 {
				t.Errorf("size #%d: in: %x, gh32h1s (%d) != c32h1 (%d); attempt #%d", size, test, g32h1s, c32h1, i)
			}
			g64h1 := Sum64(test)
			g64h1s := SeedSum64(0, test)
			c64h1 := g64h1
			if isLittleEndian {
				c64h1 = testdata.SeedSum64(0, test)
			}
			if g64h1 != c64h1 {
				t.Errorf("size #%d: in: %x, g64h1 (%d) != c64h1 (%d); attempt #%d", size, test, g64h1, c64h1, i)
			}
			if g64h1s != c64h1 {
				t.Errorf("size #%d: in: %x, g64h1s (%d) != c64h1 (%d); attempt #%d", size, test, g64h1s, c64h1, i)
			}
			g128h1, g128h2 := Sum128(test)
			g128h1s, g128h2s := SeedSum128(0, 0, test)
			c128h1, c128h2 := g128h1, g128h2
			if isLittleEndian {
				c128h1, c128h2 = testdata.SeedSum128(0, test)
			}
			if g128h1 != c128h1 {
				t.Errorf("size #%d: in: %x, g128h1 (%d) != c128h1 (%d); attempt #%d", size, test, g128h1, c128h1, i)
			}
			if g128h2 != c128h2 {
				t.Errorf("size #%d: in: %x, g128h2 (%d) != c128h2 (%d); attempt #%d", size, test, g128h2, c128h2, i)
			}
			if g128h1s != c128h1 {
				t.Errorf("size #%d: in: %x, g128h1s (%d) != c128h1 (%d); attempt #%d", size, test, g128h1s, c128h1, i)
			}
			if g128h2s != c128h2 {
				t.Errorf("size #%d: in: %x, g128h2s (%d) != c128h2 (%d); attempt #%d", size, test, g128h2s, c128h2, i)
			}
		}
		// Randomize the data for all subsequent tests.
		io.ReadFull(rand.Reader, data[:])
	}
}

// TestClone forks each streaming hash while it holds a partial block, then
// checks that both forks match fresh hashes and that neither sees the
// other's writes.
func TestClone(t *testing.T) {
	prefix := []byte("0123456789abcdefghijk") // 21 bytes: 5 byte tail for 128, 1 for 32.
	sufA, sufB := []byte("AAAAAAA"), []byte("BBBBBBBBBBBBBBBBBBBBBBB")
	full := func(h hash.Hash, parts ...[]byte) []byte {
		for _, p := range parts {
			h.Write(p)
		}
		return h.Sum(nil)
	}
	for name, mk := range map[string]func() hash.Hash{
		"32":  func() hash.Hash { return SeedNew32(7) },
		"64":  func() hash.Hash { return SeedNew64(7) },
		"128": func() hash.Hash { return SeedNew128(7, 9) },
	} {
		h := mk()
		h.Write(prefix)
		c, err := h.(hash.Cloner).Clone()
		if err != nil {
			t.Fatalf("%s: clone: %v", name, err)
		}
		h.Write(sufA)
		c.Write(sufB)
		if got, want := h.Sum(nil), full(mk(), prefix, sufA); string(got) != string(want) {
			t.Errorf("%s: original after clone: got %x want %x", name, got, want)
		}
		if got, want := c.Sum(nil), full(mk(), prefix, sufB); string(got) != string(want) {
			t.Errorf("%s: clone: got %x want %x", name, got, want)
		}
		// A clone of a clone, and a clone after Reset, must also stand alone.
		cc, _ := c.Clone()
		cc.Reset()
		cc.Write(sufA)
		if got, want := cc.Sum(nil), full(mk(), sufA); string(got) != string(want) {
			t.Errorf("%s: reset clone: got %x want %x", name, got, want)
		}
		if got, want := c.Sum(nil), full(mk(), prefix, sufB); string(got) != string(want) {
			t.Errorf("%s: clone after cloning it: got %x want %x", name, got, want)
		}
	}
	// The 64 and 128 bit clones keep their wider interfaces.
	c128, _ := New128().(hash.Cloner).Clone()
	if _, ok := c128.(Hash128); !ok {
		t.Error("128 bit clone is not a Hash128")
	}
	c64, _ := New64().(hash.Cloner).Clone()
	if _, ok := c64.(hash.Hash64); !ok {
		t.Error("64 bit clone is not a hash.Hash64")
	}
}

func TestIncremental(t *testing.T) {
	for _, elem := range data {
		h32 := New32()
		h64 := New64()
		h128 := New128()
		for i, j, k := 0, 0, len(elem.s); i < k; i = j {
			j = 2*i + 3
			if j > k {
				j = k
			}
			s := elem.s[i:j]
			h32.Write([]byte(s))
			h64.Write([]byte(s))
			h128.Write([]byte(s))
		}
		if v := h32.Sum32(); v != elem.h32 {
			t.Errorf("'%s': 0x%x (want 0x%x)", elem.s, v, elem.h32)
		}
		if v := h64.Sum64(); v != elem.h64_1 {
			t.Errorf("New64: '%s': 0x%x (want 0x%x)", elem.s, v, elem.h64_1)
		}
		if v1, v2 := h128.Sum128(); v1 != elem.h64_1 || v2 != elem.h64_2 {
			t.Errorf("'%s': 0x%x-0x%x (want 0x%x-0x%x)", elem.s, v1, v2, elem.h64_1, elem.h64_2)
		}
	}
}

// TestNoescape checks that the sums leave your input on the stack, and that
// a hasher you create and use in one function stays on the stack. Only a
// caller in another package sees the sums' allocations, so this file is
// package murmur3_test.
func TestNoescape(t *testing.T) {
	// Each func declares its own buf: a buf captured from outside would
	// move to the heap once, before AllocsPerRun counts. A string converted
	// from more than 32 bytes allocates regardless, so b stays at 32.
	for _, test := range []struct {
		name string
		fn   func(n int)
	}{
		{"Sum32", func(n int) { var b [32]byte; Sum32(b[:n]) }},
		{"SeedSum32", func(n int) { var b [32]byte; SeedSum32(1, b[:n]) }},
		{"StringSum32", func(n int) { var b [32]byte; StringSum32(string(b[:n])) }},
		{"SeedStringSum32", func(n int) { var b [32]byte; SeedStringSum32(1, string(b[:n])) }},
		{"Sum64", func(n int) { var b [32]byte; Sum64(b[:n]) }},
		{"SeedSum64", func(n int) { var b [32]byte; SeedSum64(1, b[:n]) }},
		{"StringSum64", func(n int) { var b [32]byte; StringSum64(string(b[:n])) }},
		{"SeedStringSum64", func(n int) { var b [32]byte; SeedStringSum64(1, string(b[:n])) }},
		{"Sum128", func(n int) { var b [32]byte; Sum128(b[:n]) }},
		{"SeedSum128", func(n int) { var b [32]byte; SeedSum128(1, 2, b[:n]) }},
		{"StringSum128", func(n int) { var b [32]byte; StringSum128(string(b[:n])) }},
		{"SeedStringSum128", func(n int) { var b [32]byte; SeedStringSum128(1, 2, string(b[:n])) }},

		// Two writes, so the second joins the first one's pending bytes.
		{"New32", func(n int) { var b [32]byte; h := New32(); h.Write(b[:n]); h.Write(b[:n]); h.Sum32() }},
		{"New64", func(n int) { var b [32]byte; h := New64(); h.Write(b[:n]); h.Write(b[:n]); h.Sum64() }},
		{"New128", func(n int) { var b [32]byte; h := New128(); h.Write(b[:n]); h.Write(b[:n]); h.Sum128() }},
	} {
		for _, n := range []int{0, 3, 4, 15, 16, 17, 32} {
			if allocs := testing.AllocsPerRun(10, func() { test.fn(n) }); allocs != 0 {
				t.Errorf("%s, %d bytes: got %v allocs per run, want 0", test.name, n, allocs)
			}
		}
	}
}

// Our lengths force 1) the function base itself (no loop/tail), 2) remainders
// and 3) the loop itself.

func Benchmark32Branches(b *testing.B) {
	for length := 0; length <= 4; length++ {
		b.Run(strconv.Itoa(length), func(b *testing.B) {
			buf := make([]byte, length)
			b.SetBytes(int64(length))
			for b.Loop() {
				Sum32(buf)
			}
		})
	}
}

func BenchmarkPartial32Branches(b *testing.B) {
	for length := 0; length <= 4; length++ {
		b.Run(strconv.Itoa(length), func(b *testing.B) {
			buf := make([]byte, length)
			b.SetBytes(int64(length))
			for range b.N {
				hasher := New32()
				hasher.Write(buf)
				hasher.Sum32()
			}
		})
	}
}

func Benchmark128Branches(b *testing.B) {
	for length := 0; length <= 16; length++ {
		b.Run(strconv.Itoa(length), func(b *testing.B) {
			buf := make([]byte, length)
			b.SetBytes(int64(length))
			for b.Loop() {
				Sum128(buf)
			}
		})
	}
}

// Sizes below pick up where branches left off to demonstrate speed at larger
// slice sizes.

func Benchmark32Sizes(b *testing.B) {
	buf := make([]byte, 8192)
	for length := 32; length <= cap(buf); length *= 2 {
		b.Run(strconv.Itoa(length), func(b *testing.B) {
			buf = buf[:length]
			b.SetBytes(int64(length))
			for b.Loop() {
				Sum32(buf)
			}
		})
	}
}

func Benchmark64Sizes(b *testing.B) {
	buf := make([]byte, 8192)
	for length := 32; length <= cap(buf); length *= 2 {
		b.Run(strconv.Itoa(length), func(b *testing.B) {
			buf = buf[:length]
			b.SetBytes(int64(length))
			for b.Loop() {
				Sum64(buf)
			}
		})
	}
}

func Benchmark128Sizes(b *testing.B) {
	buf := make([]byte, 8192)
	for length := 32; length <= cap(buf); length *= 2 {
		b.Run(strconv.Itoa(length), func(b *testing.B) {
			buf = buf[:length]
			b.SetBytes(int64(length))
			for b.Loop() {
				Sum128(buf)
			}
		})
	}
}

// Fixed length benchmarks let the branch predictor learn every branch in
// the tail. Real key streams do not, so these draw a fresh length in [0, 64)
// from xorshift on every call; the generator itself is a few cycles.

func BenchmarkRandomLengths32(b *testing.B) {
	buf := make([]byte, 64)
	x := uint64(88172645463325252)
	for b.Loop() {
		x ^= x << 13
		x ^= x >> 7
		x ^= x << 17
		Sum32(buf[:x&63])
	}
}

func BenchmarkRandomLengths128(b *testing.B) {
	buf := make([]byte, 64)
	x := uint64(88172645463325252)
	for b.Loop() {
		x ^= x << 13
		x ^= x >> 7
		x ^= x << 17
		Sum128(buf[:x&63])
	}
}
