# Changelog

## [v1.16.0](https://github.com/rabbitmq/amqp091-go/tree/v1.16.0) (2026-10-19)

[Full Changelog](https://github.com/rabbitmq/amqp091-go/compare/v1.15.0...v1.16.0)

**Implemented enhancements:**

- Add support for basic cancel ok response [\#405](https://github.com/rabbitmq/amqp091-go/pull/405) ([Zerpet](https://github.com/Zerpet))

**Fixed bugs:**

- Start recovery watcher only after a successful handshake [\#409](https://github.com/rabbitmq/amqp091-go/pull/409) ([suchitd](https://github.com/suchitd))
- Reject out-of-range heartbeat in ParseURI [\#407](https://github.com/rabbitmq/amqp091-go/pull/407) ([suchitd](https://github.com/suchitd))
- Reject heartbeat frames sent on a non-zero channel [\#402](https://github.com/rabbitmq/amqp091-go/pull/402) ([suchitd](https://github.com/suchitd))

**Closed issues:**

- DialConfig leaks a watchConnection goroutine when the AMQP handshake fails with Recovery enabled [\#408](https://github.com/rabbitmq/amqp091-go/issues/408)
- panic: unexpected frame type [\#400](https://github.com/rabbitmq/amqp091-go/issues/400)
- v1.13.0: openComplete\(\) zeroes caller-owned SASL credentials, breaking Config reuse across dials [\#394](https://github.com/rabbitmq/amqp091-go/issues/394)
- Dial returns 403 "no access to this vhost" when the broker refuses connection.open with 530 NOT\_ALLOWED \(e.g. user connection limit reached\) [\#392](https://github.com/rabbitmq/amqp091-go/issues/392)
- Question mark in password breaks connection string parsing [\#305](https://github.com/rabbitmq/amqp091-go/issues/305)

**Merged pull requests:**

- Fix golangci-lint v2.15.0 errcheck failures [\#411](https://github.com/rabbitmq/amqp091-go/pull/411) ([suchitd](https://github.com/suchitd))
- chore\(deps\): bump github/codeql-action from 4.38.2 to 4.38.3 in the github-actions group [\#410](https://github.com/rabbitmq/amqp091-go/pull/410) ([dependabot[bot]](https://github.com/apps/dependabot))
- chore\(deps\): bump github/codeql-action from 4.38.1 to 4.38.2 in the github-actions group [\#401](https://github.com/rabbitmq/amqp091-go/pull/401) ([dependabot[bot]](https://github.com/apps/dependabot))
- Add Fuzzy tests for reader [\#399](https://github.com/rabbitmq/amqp091-go/pull/399) ([Zerpet](https://github.com/Zerpet))
- chore\(deps\): bump github/codeql-action from 4.38.0 to 4.38.1 in the github-actions group [\#398](https://github.com/rabbitmq/amqp091-go/pull/398) ([dependabot[bot]](https://github.com/apps/dependabot))
- Reader hardening [\#397](https://github.com/rabbitmq/amqp091-go/pull/397) ([Zerpet](https://github.com/Zerpet))
- docs: document URI credential percent-encoding requirement \(\#305\) [\#396](https://github.com/rabbitmq/amqp091-go/pull/396) ([cipherprofessor](https://github.com/cipherprofessor))
- chore: remove redundant legacy +build tag from fuzz.go [\#395](https://github.com/rabbitmq/amqp091-go/pull/395) ([cipherprofessor](https://github.com/cipherprofessor))
- Surface the broker's connection.close reason from Dial instead of a hardcoded 403 [\#393](https://github.com/rabbitmq/amqp091-go/pull/393) ([mohammadkshn](https://github.com/mohammadkshn))
- chore\(deps\): bump github/codeql-action from 4.37.9 to 4.38.0 in the github-actions group [\#391](https://github.com/rabbitmq/amqp091-go/pull/391) ([dependabot[bot]](https://github.com/apps/dependabot))

## [v1.15.0](https://github.com/rabbitmq/amqp091-go/tree/v1.15.0) (2026-09-15)

[Full Changelog](https://github.com/rabbitmq/amqp091-go/compare/v1.14.0...v1.15.0)

**Fixed bugs:**

- fix: preserve caller-provided SASL credentials across Reconnect\(\) [\#389](https://github.com/rabbitmq/amqp091-go/pull/389) ([suchitd](https://github.com/suchitd))
- fix: clone SASL authentication before zeroing credentials post-handshake [\#388](https://github.com/rabbitmq/amqp091-go/pull/388) ([suchitd](https://github.com/suchitd))

**Closed issues:**

- v1.13.0 \(\#350\) zeroes caller-provided PlainAuth.Password, breaking auth on any reconnect that reuses the Config [\#387](https://github.com/rabbitmq/amqp091-go/issues/387)

**Merged pull requests:**

- chore\(deps\): bump github/codeql-action from 4.37.8 to 4.37.9 in the github-actions group [\#390](https://github.com/rabbitmq/amqp091-go/pull/390) ([dependabot[bot]](https://github.com/apps/dependabot))
- chore\(deps\): bump github/codeql-action from 4.37.7 to 4.37.8 in the github-actions group [\#386](https://github.com/rabbitmq/amqp091-go/pull/386) ([dependabot[bot]](https://github.com/apps/dependabot))
- chore\(deps\): bump github/codeql-action from 4.37.6 to 4.37.7 in the github-actions group [\#385](https://github.com/rabbitmq/amqp091-go/pull/385) ([dependabot[bot]](https://github.com/apps/dependabot))

## [v1.14.0](https://github.com/rabbitmq/amqp091-go/tree/v1.14.0) (2026-08-18)

[Full Changelog](https://github.com/rabbitmq/amqp091-go/compare/v1.13.0...v1.14.0)

**Implemented enhancements:**

- refactor: extract shared close prologue into beginClose\(\) [\#376](https://github.com/rabbitmq/amqp091-go/pull/376) ([suchitd](https://github.com/suchitd))

**Fixed bugs:**

- Retry consumer recovery instead of cancelling on a failed re-subscribe [\#380](https://github.com/rabbitmq/amqp091-go/pull/380) ([lukebakken](https://github.com/lukebakken))
- Fix auto-recovery correctness gaps [\#379](https://github.com/rabbitmq/amqp091-go/pull/379) ([suchitd](https://github.com/suchitd))
- Enforce frame size in pre-negotiation state [\#377](https://github.com/rabbitmq/amqp091-go/pull/377) ([Zerpet](https://github.com/Zerpet))
- test: retry cleanup connection after clearing memory alarm [\#375](https://github.com/rabbitmq/amqp091-go/pull/375) ([suchitd](https://github.com/suchitd))
- fix: eliminate flakiness in TestTLSHandshake [\#373](https://github.com/rabbitmq/amqp091-go/pull/373) ([suchitd](https://github.com/suchitd))
- fix: close goroutine leaks from Close\(\)/Reconnect\(\) races [\#372](https://github.com/rabbitmq/amqp091-go/pull/372) ([suchitd](https://github.com/suchitd))

**Merged pull requests:**

- chore\(deps\): reduce github-actions dependabot updates to weekly [\#384](https://github.com/rabbitmq/amqp091-go/pull/384) ([suchitd](https://github.com/suchitd))
- chore\(deps\): bump github/codeql-action from 4.37.5 to 4.37.6 in the github-actions group [\#383](https://github.com/rabbitmq/amqp091-go/pull/383) ([dependabot[bot]](https://github.com/apps/dependabot))
- docs: update CLAUDE.md with lifecycle/log files and updated recovery details [\#382](https://github.com/rabbitmq/amqp091-go/pull/382) ([suchitd](https://github.com/suchitd))
- chore\(deps\): bump github/codeql-action from 4.37.4 to 4.37.5 in the github-actions group [\#381](https://github.com/rabbitmq/amqp091-go/pull/381) ([dependabot[bot]](https://github.com/apps/dependabot))
- chore\(deps\): bump github/codeql-action from 4.37.3 to 4.37.4 in the github-actions group [\#378](https://github.com/rabbitmq/amqp091-go/pull/378) ([dependabot[bot]](https://github.com/apps/dependabot))
- chore\(deps\): bump github/codeql-action from 4 to 4.37.3 in the github-actions group [\#374](https://github.com/rabbitmq/amqp091-go/pull/374) ([dependabot[bot]](https://github.com/apps/dependabot))

## [v1.13.0](https://github.com/rabbitmq/amqp091-go/tree/v1.13.0) (2026-07-21)

[Full Changelog](https://github.com/rabbitmq/amqp091-go/compare/v1.12.0...v1.13.0)

**Implemented enhancements:**

- feat: skip-and-continue topology recovery with per-entity error surfacing [\#365](https://github.com/rabbitmq/amqp091-go/pull/365) ([suchitd](https://github.com/suchitd))
- Make TopologyRecoveryAllEnabled the default topology recovery mode [\#362](https://github.com/rabbitmq/amqp091-go/pull/362) ([suchitd](https://github.com/suchitd))
- feature: implement automatic topology recovery [\#357](https://github.com/rabbitmq/amqp091-go/pull/357) ([suchitd](https://github.com/suchitd))

**Fixed bugs:**

- Evict auto-delete queues and exchanges from topology store to prevent stale resurrection during recovery [\#368](https://github.com/rabbitmq/amqp091-go/issues/368)
- Data race in Connection.shutdown between buffered listener send goroutine and close\(listener\) [\#360](https://github.com/rabbitmq/amqp091-go/issues/360)
- fix: reject frames exceeding negotiated frame\_max before allocation [\#369](https://github.com/rabbitmq/amqp091-go/pull/369) ([suchitd](https://github.com/suchitd))
- fix: prevent recursive channel recovery during connection reconnection [\#367](https://github.com/rabbitmq/amqp091-go/pull/367) ([suchitd](https://github.com/suchitd))
- fix: eliminate multiple data races in Channel and Connection operations [\#366](https://github.com/rabbitmq/amqp091-go/pull/366) ([suchitd](https://github.com/suchitd))
- fix: forget auto-delete topology on last consumer/binding removal [\#363](https://github.com/rabbitmq/amqp091-go/pull/363) ([suchitd](https://github.com/suchitd))
- fix: explicitly enforce TLS 1.2 minimum version in tlsConfigFromURI [\#355](https://github.com/rabbitmq/amqp091-go/pull/355) ([suchitd](https://github.com/suchitd))
- fix: return error when shortstr exceeds 255 bytes [\#354](https://github.com/rabbitmq/amqp091-go/pull/354) ([suchitd](https://github.com/suchitd))
- fix: enforce AMQP minimum frame size during negotiation [\#353](https://github.com/rabbitmq/amqp091-go/pull/353) ([suchitd](https://github.com/suchitd))
- fix: URL-encode TLS file paths in URI.String\(\) query string [\#352](https://github.com/rabbitmq/amqp091-go/pull/352) ([suchitd](https://github.com/suchitd))
- Reject negative prefetch values in Qos [\#351](https://github.com/rabbitmq/amqp091-go/pull/351) ([suchitd](https://github.com/suchitd))
- fix: redact and zero out plaintext SASL credentials after handshake [\#350](https://github.com/rabbitmq/amqp091-go/pull/350) ([suchitd](https://github.com/suchitd))
- Avoid notifications blocking reader. [\#349](https://github.com/rabbitmq/amqp091-go/pull/349) ([MirahImage](https://github.com/MirahImage))
- Return error when longstring too long. [\#347](https://github.com/rabbitmq/amqp091-go/pull/347) ([MirahImage](https://github.com/MirahImage))
- Cap body pre-allocation to FrameMax. [\#346](https://github.com/rabbitmq/amqp091-go/pull/346) ([MirahImage](https://github.com/MirahImage))
- Safely handle negative x- field length. [\#344](https://github.com/rabbitmq/amqp091-go/pull/344) ([MirahImage](https://github.com/MirahImage))

**Merged pull requests:**

- chore\(deps\): bump actions/setup-go from 6 to 7 in the github-actions group [\#370](https://github.com/rabbitmq/amqp091-go/pull/370) ([dependabot[bot]](https://github.com/apps/dependabot))
- docs: update CLAUDE.md to document automatic recovery and new notify methods [\#359](https://github.com/rabbitmq/amqp091-go/pull/359) ([suchitd](https://github.com/suchitd))
- chore\(deps\): bump actions/cache from 5 to 6 in the github-actions group [\#358](https://github.com/rabbitmq/amqp091-go/pull/358) ([dependabot[bot]](https://github.com/apps/dependabot))
- chore\(deps\): bump actions/checkout from 6 to 7 in the github-actions group [\#356](https://github.com/rabbitmq/amqp091-go/pull/356) ([dependabot[bot]](https://github.com/apps/dependabot))

## [v1.12.0](https://github.com/rabbitmq/amqp091-go/tree/v1.12.0) (2026-06-16)

[Full Changelog](https://github.com/rabbitmq/amqp091-go/compare/v1.11.0...v1.12.0)

**Implemented enhancements:**

- Feature: implement automatic connection and channel recovery with state change notifications [\#339](https://github.com/rabbitmq/amqp091-go/pull/339) ([suchitd](https://github.com/suchitd))
- Add integration test for publish with immediate flag [\#338](https://github.com/rabbitmq/amqp091-go/pull/338) ([suchitd](https://github.com/suchitd))
- Add integration tests for QueueUnbind and QueuePurge [\#337](https://github.com/rabbitmq/amqp091-go/pull/337) ([suchitd](https://github.com/suchitd))
- Add integration test for exchange-to-exchange binding and unbinding [\#336](https://github.com/rabbitmq/amqp091-go/pull/336) ([suchitd](https://github.com/suchitd))

**Fixed bugs:**

- Fix Client example to work with RabbitMQ 4.3 [\#341](https://github.com/rabbitmq/amqp091-go/pull/341) ([suchitd](https://github.com/suchitd))
- Update CONTRIBUTING.md and .gitignore files [\#335](https://github.com/rabbitmq/amqp091-go/pull/335) ([suchitd](https://github.com/suchitd))
- Fix inconsistencies in the Makefile [\#334](https://github.com/rabbitmq/amqp091-go/pull/334) ([suchitd](https://github.com/suchitd))
- Fix integration tests for RabbitMQ 4.3 [\#331](https://github.com/rabbitmq/amqp091-go/pull/331) ([suchitd](https://github.com/suchitd))

**Closed issues:**

- PublishWithContext does not respect context cancellation [\#329](https://github.com/rabbitmq/amqp091-go/issues/329)

**Merged pull requests:**

- doc: remove auto-reconnect from non-goals in README [\#343](https://github.com/rabbitmq/amqp091-go/pull/343) ([suchitd](https://github.com/suchitd))
- Add CLAUDE.md to repo [\#342](https://github.com/rabbitmq/amqp091-go/pull/342) ([Zerpet](https://github.com/Zerpet))
- Bump CI windows workflow RabbitMQ and Erlang versions [\#333](https://github.com/rabbitmq/amqp091-go/pull/333) ([suchitd](https://github.com/suchitd))
- Add pull request template [\#332](https://github.com/rabbitmq/amqp091-go/pull/332) ([suchitd](https://github.com/suchitd))

## [v1.11.0](https://github.com/rabbitmq/amqp091-go/tree/v1.11.0) (2026-04-21)

[Full Changelog](https://github.com/rabbitmq/amqp091-go/compare/v1.10.0...v1.11.0)

**Implemented enhancements:**

- add better debug information on DialConfig [\#245](https://github.com/rabbitmq/amqp091-go/issues/245)

**Fixed bugs:**

- Channel error when acking via go-routines [\#296](https://github.com/rabbitmq/amqp091-go/issues/296)

**Closed issues:**

- PR \#318 exposes a pre-existing race in `Connection.Close()`. [\#327](https://github.com/rabbitmq/amqp091-go/issues/327)
- Entire header frame isn't always read [\#309](https://github.com/rabbitmq/amqp091-go/issues/309)
- Incomplete support of 0-9-1 field type values [\#302](https://github.com/rabbitmq/amqp091-go/issues/302)
- Redelivered Flag Not Exposed [\#301](https://github.com/rabbitmq/amqp091-go/issues/301)
- consume input basicConsumeOk but response queueBindOk [\#291](https://github.com/rabbitmq/amqp091-go/issues/291)
- Channel is closed after Channel.ExchangeDeclarePassive fails [\#290](https://github.com/rabbitmq/amqp091-go/issues/290)
- Incomplete example in \(\*Channel\).QueueBind documentation [\#279](https://github.com/rabbitmq/amqp091-go/issues/279)
- QueueDeclarePassive does not report queue type mismatch [\#273](https://github.com/rabbitmq/amqp091-go/issues/273)
- Release 1.10.0 [\#261](https://github.com/rabbitmq/amqp091-go/issues/261)
- Update minimum Go version to 1.18 [\#146](https://github.com/rabbitmq/amqp091-go/issues/146)

**Merged pull requests:**

-  fix: respect context cancellation on publishing with context operations [\#330](https://github.com/rabbitmq/amqp091-go/pull/330) ([NawafSwe](https://github.com/NawafSwe))
- Eliminate race condition in Connection.Close\(\) and related methods [\#328](https://github.com/rabbitmq/amqp091-go/pull/328) ([Zerpet](https://github.com/Zerpet))
- Bump the github-actions group with 4 updates [\#326](https://github.com/rabbitmq/amqp091-go/pull/326) ([dependabot[bot]](https://github.com/apps/dependabot))
- Bump github/codeql-action from 3 to 4 [\#321](https://github.com/rabbitmq/amqp091-go/pull/321) ([dependabot[bot]](https://github.com/apps/dependabot))
- Fix incomplete routing diagram in QueueBind doc comment [\#320](https://github.com/rabbitmq/amqp091-go/pull/320) ([Copilot](https://github.com/apps/copilot-swe-agent))
- Use RabbitMQ 4 in Makefile [\#319](https://github.com/rabbitmq/amqp091-go/pull/319) ([Zerpet](https://github.com/Zerpet))
- refactor: simplify with atomic types [\#318](https://github.com/rabbitmq/amqp091-go/pull/318) ([alexandear](https://github.com/alexandear))
- Add support for unsigned type values [\#317](https://github.com/rabbitmq/amqp091-go/pull/317) ([Zerpet](https://github.com/Zerpet))
- fix: modernize lint issues [\#315](https://github.com/rabbitmq/amqp091-go/pull/315) ([alexandear](https://github.com/alexandear))
- Fix `parseHeaderFrame` to consume entire frame payload [\#314](https://github.com/rabbitmq/amqp091-go/pull/314) ([lukebakken](https://github.com/lukebakken))
- docs: update link to RabbitMQ tutorials [\#313](https://github.com/rabbitmq/amqp091-go/pull/313) ([alexandear](https://github.com/alexandear))
- fix: typos in comments and tests [\#312](https://github.com/rabbitmq/amqp091-go/pull/312) ([alexandear](https://github.com/alexandear))
- feat: add MIME types constants for  content types [\#308](https://github.com/rabbitmq/amqp091-go/pull/308) ([YlanzinhoY](https://github.com/YlanzinhoY))
- Fix linter error after migrating config to v2 [\#306](https://github.com/rabbitmq/amqp091-go/pull/306) ([Zerpet](https://github.com/Zerpet))
- Investigate GH-296 [\#297](https://github.com/rabbitmq/amqp091-go/pull/297) ([lukebakken](https://github.com/lukebakken))
- Return existing error instead of creating new for the same purpose [\#295](https://github.com/rabbitmq/amqp091-go/pull/295) ([pingvincible](https://github.com/pingvincible))
- Add warning about concurrency with Channels [\#294](https://github.com/rabbitmq/amqp091-go/pull/294) ([Zerpet](https://github.com/Zerpet))
- Expose delivery not initialised error [\#293](https://github.com/rabbitmq/amqp091-go/pull/293) ([Zerpet](https://github.com/Zerpet))
- fix: unify receiver methods to avoid conflicts between value and pointer types [\#292](https://github.com/rabbitmq/amqp091-go/pull/292) ([Raisul191491](https://github.com/Raisul191491))
- Fixing simple errors [\#280](https://github.com/rabbitmq/amqp091-go/pull/280) ([korolev-d-l](https://github.com/korolev-d-l))
- Add test that demonstrates the issue [\#274](https://github.com/rabbitmq/amqp091-go/pull/274) ([lukebakken](https://github.com/lukebakken))
- chore: doc typo [\#269](https://github.com/rabbitmq/amqp091-go/pull/269) ([AndrewWinterman](https://github.com/AndrewWinterman))
- Small fixes and refactors [\#266](https://github.com/rabbitmq/amqp091-go/pull/266) ([peczenyj](https://github.com/peczenyj))
- add methods Temporary and Recoverable to amqp.Error [\#265](https://github.com/rabbitmq/amqp091-go/pull/265) ([peczenyj](https://github.com/peczenyj))

## [v1.10.0](https://github.com/rabbitmq/amqp091-go/tree/v1.10.0) (2024-05-08)

[Full Changelog](https://github.com/rabbitmq/amqp091-go/compare/v1.9.0...v1.10.0)

**Implemented enhancements:**

- Undeprecate non-context publish functions [\#259](https://github.com/rabbitmq/amqp091-go/pull/259) ([Zerpet](https://github.com/Zerpet))
- Update Go directive [\#257](https://github.com/rabbitmq/amqp091-go/pull/257) ([Zerpet](https://github.com/Zerpet))

**Fixed bugs:**

- republishing on reconnect bug in the example [\#249](https://github.com/rabbitmq/amqp091-go/issues/249)
- Channel Notify Close not receive event when connection is closed by RMQ server. [\#241](https://github.com/rabbitmq/amqp091-go/issues/241)
- Inconsistent documentation [\#231](https://github.com/rabbitmq/amqp091-go/issues/231)
- Data race in the client example [\#72](https://github.com/rabbitmq/amqp091-go/issues/72)
- Fix string function of URI [\#258](https://github.com/rabbitmq/amqp091-go/pull/258) ([Zerpet](https://github.com/Zerpet))

**Closed issues:**

- Documentation needed \(`PublishWithContext` does not use context\) [\#195](https://github.com/rabbitmq/amqp091-go/issues/195)
- concurrent dispatch data race [\#226](https://github.com/rabbitmq/amqp091-go/issues/226)

**Merged pull requests:**

- Fix data race in example [\#260](https://github.com/rabbitmq/amqp091-go/pull/260) ([Zerpet](https://github.com/Zerpet))
- Address CodeQL warning [\#252](https://github.com/rabbitmq/amqp091-go/pull/252) ([lukebakken](https://github.com/lukebakken))
- Add support for additional AMQP URI query parameters [\#251](https://github.com/rabbitmq/amqp091-go/pull/251) ([vilius-g](https://github.com/vilius-g))
- Example fix [\#250](https://github.com/rabbitmq/amqp091-go/pull/250) ([Boris-Plato](https://github.com/Boris-Plato))
- Increasing the code coverage [\#248](https://github.com/rabbitmq/amqp091-go/pull/248) ([edercarloscosta](https://github.com/edercarloscosta))
- Use correct mutex to guard confirms.published [\#240](https://github.com/rabbitmq/amqp091-go/pull/240) ([hjr265](https://github.com/hjr265))
- Documenting Publishing.Expiration usage [\#232](https://github.com/rabbitmq/amqp091-go/pull/232) ([niksteff](https://github.com/niksteff))
- fix comment typo in example\_client\_test.go [\#228](https://github.com/rabbitmq/amqp091-go/pull/228) ([wisaTong](https://github.com/wisaTong))
- Bump go.uber.org/goleak from 1.2.1 to 1.3.0 [\#227](https://github.com/rabbitmq/amqp091-go/pull/227) ([dependabot[bot]](https://github.com/apps/dependabot))

## [v1.9.0](https://github.com/rabbitmq/amqp091-go/tree/v1.9.0) (2023-10-02)

[Full Changelog](https://github.com/rabbitmq/amqp091-go/compare/v1.8.1...v1.9.0)

**Implemented enhancements:**

- Use of buffered delivery channels when prefetch\_count is not null [\#200](https://github.com/rabbitmq/amqp091-go/issues/200)

**Fixed bugs:**

- connection block when write connection reset by peer [\#222](https://github.com/rabbitmq/amqp091-go/issues/222)
- Test failure on 32bit architectures [\#202](https://github.com/rabbitmq/amqp091-go/issues/202)

**Closed issues:**

- Add a constant to set consumer timeout as queue argument [\#201](https://github.com/rabbitmq/amqp091-go/issues/201)
- Add a constant for CQ version [\#199](https://github.com/rabbitmq/amqp091-go/issues/199)
- Examples may need to be updated after \#140 [\#153](https://github.com/rabbitmq/amqp091-go/issues/153)

**Merged pull requests:**

- Update spec091.go [\#224](https://github.com/rabbitmq/amqp091-go/pull/224) ([pinkfish](https://github.com/pinkfish))
- Closes 222 [\#223](https://github.com/rabbitmq/amqp091-go/pull/223) ([yywing](https://github.com/yywing))
- Update write.go [\#221](https://github.com/rabbitmq/amqp091-go/pull/221) ([pinkfish](https://github.com/pinkfish))
- Bump versions [\#219](https://github.com/rabbitmq/amqp091-go/pull/219) ([lukebakken](https://github.com/lukebakken))
- remove extra word 'accept' from ExchangeDeclare description [\#217](https://github.com/rabbitmq/amqp091-go/pull/217) ([a-sabzian](https://github.com/a-sabzian))
- Misc Windows CI updates [\#216](https://github.com/rabbitmq/amqp091-go/pull/216) ([lukebakken](https://github.com/lukebakken))
- Stop using deprecated Publish function [\#207](https://github.com/rabbitmq/amqp091-go/pull/207) ([Zerpet](https://github.com/Zerpet))
- Constant for consumer timeout queue argument [\#206](https://github.com/rabbitmq/amqp091-go/pull/206) ([Zerpet](https://github.com/Zerpet))
- Add a constant for CQ v2 queue argument [\#205](https://github.com/rabbitmq/amqp091-go/pull/205) ([Zerpet](https://github.com/Zerpet))
- Fix example for 32-bit compatibility [\#204](https://github.com/rabbitmq/amqp091-go/pull/204) ([Zerpet](https://github.com/Zerpet))
- Fix to increase timeout milliseconds since it's too tight [\#203](https://github.com/rabbitmq/amqp091-go/pull/203) ([t2y](https://github.com/t2y))
- Add Channel.ConsumeWithContext to be able to cancel delivering [\#192](https://github.com/rabbitmq/amqp091-go/pull/192) ([t2y](https://github.com/t2y))

## [v1.8.1](https://github.com/rabbitmq/amqp091-go/tree/v1.8.1) (2023-05-04)

[Full Changelog](https://github.com/rabbitmq/amqp091-go/compare/v1.8.0...v1.8.1)

**Fixed bugs:**

- Fixed incorrect version reported in client properties [52ce2efd03c53dcf77d5496977da46840e9abd24](https://github.com/rabbitmq/amqp091-go/commit/52ce2efd03c53dcf77d5496977da46840e9abd24)

**Merged pull requests:**

- Fix Example Client not reconnecting [\#186](https://github.com/rabbitmq/amqp091-go/pull/186) ([frankfil](https://github.com/frankfil))

## [v1.8.0](https://github.com/rabbitmq/amqp091-go/tree/v1.8.0) (2023-03-21)

[Full Changelog](https://github.com/rabbitmq/amqp091-go/compare/v1.7.0...v1.8.0)

**Closed issues:**

- memory leak  [\#179](https://github.com/rabbitmq/amqp091-go/issues/179)
-  the publishWithContext interface will not return when it times out [\#178](https://github.com/rabbitmq/amqp091-go/issues/178)

**Merged pull requests:**

- Fix race condition on confirms [\#183](https://github.com/rabbitmq/amqp091-go/pull/183) ([calloway-jacob](https://github.com/calloway-jacob))
- Add a CloseDeadline function to Connection [\#181](https://github.com/rabbitmq/amqp091-go/pull/181) ([Zerpet](https://github.com/Zerpet))
- Fix memory leaks [\#180](https://github.com/rabbitmq/amqp091-go/pull/180) ([GXKe](https://github.com/GXKe))
- Bump go.uber.org/goleak from 1.2.0 to 1.2.1 [\#177](https://github.com/rabbitmq/amqp091-go/pull/177) ([dependabot[bot]](https://github.com/apps/dependabot))

## [v1.7.0](https://github.com/rabbitmq/amqp091-go/tree/v1.7.0) (2023-02-09)

[Full Changelog](https://github.com/rabbitmq/amqp091-go/compare/v1.6.1...v1.7.0)

**Closed issues:**

- \#31 resurfacing \(?\) [\#170](https://github.com/rabbitmq/amqp091-go/issues/170)
- Deprecate QueueInspect [\#167](https://github.com/rabbitmq/amqp091-go/issues/167)
- v1.6.0 causing rabbit connection errors [\#160](https://github.com/rabbitmq/amqp091-go/issues/160)

**Merged pull requests:**

- Set channels and allocator to nil in shutdown [\#172](https://github.com/rabbitmq/amqp091-go/pull/172) ([lukebakken](https://github.com/lukebakken))
- Fix racing in Open [\#171](https://github.com/rabbitmq/amqp091-go/pull/171) ([Zerpet](https://github.com/Zerpet))
- adding go 1.20 to tests [\#169](https://github.com/rabbitmq/amqp091-go/pull/169) ([halilylm](https://github.com/halilylm))
- Deprecate the QueueInspect function [\#168](https://github.com/rabbitmq/amqp091-go/pull/168) ([lukebakken](https://github.com/lukebakken))
- Check if channel is nil before updating it [\#150](https://github.com/rabbitmq/amqp091-go/pull/150) ([julienschmidt](https://github.com/julienschmidt))

## [v1.6.1](https://github.com/rabbitmq/amqp091-go/tree/v1.6.1) (2023-02-01)

[Full Changelog](https://github.com/rabbitmq/amqp091-go/compare/v1.6.1-rc.2...v1.6.1)

**Merged pull requests:**

- Update Makefile targets related to RabbitMQ [\#163](https://github.com/rabbitmq/amqp091-go/pull/163) ([Zerpet](https://github.com/Zerpet))

## [v1.6.1-rc.2](https://github.com/rabbitmq/amqp091-go/tree/v1.6.1-rc.2) (2023-01-31)

[Full Changelog](https://github.com/rabbitmq/amqp091-go/compare/v1.6.1-rc.1...v1.6.1-rc.2)

**Merged pull requests:**

- Do not overly protect writes [\#162](https://github.com/rabbitmq/amqp091-go/pull/162) ([lukebakken](https://github.com/lukebakken))

## [v1.6.1-rc.1](https://github.com/rabbitmq/amqp091-go/tree/v1.6.1-rc.1) (2023-01-31)

[Full Changelog](https://github.com/rabbitmq/amqp091-go/compare/v1.6.0...v1.6.1-rc.1)

**Closed issues:**

- Calling Channel\(\) on an empty connection panics [\#148](https://github.com/rabbitmq/amqp091-go/issues/148)

**Merged pull requests:**

- Ensure flush happens and correctly lock connection for a series of unflushed writes [\#161](https://github.com/rabbitmq/amqp091-go/pull/161) ([lukebakken](https://github.com/lukebakken))

## [v1.6.0](https://github.com/rabbitmq/amqp091-go/tree/v1.6.0) (2023-01-20)

[Full Changelog](https://github.com/rabbitmq/amqp091-go/compare/v1.5.0...v1.6.0)

**Implemented enhancements:**

- Add constants for Queue arguments [\#145](https://github.com/rabbitmq/amqp091-go/pull/145) ([Zerpet](https://github.com/Zerpet))

**Closed issues:**

- README not up to date [\#154](https://github.com/rabbitmq/amqp091-go/issues/154)
- Allow re-using default connection config \(custom properties\) [\#152](https://github.com/rabbitmq/amqp091-go/issues/152)
- Rename package name to amqp in V2 [\#151](https://github.com/rabbitmq/amqp091-go/issues/151)
- Helper types to declare quorum queues [\#144](https://github.com/rabbitmq/amqp091-go/issues/144)
- Inefficient use of buffers reduces potential throughput for basicPublish with small messages. [\#141](https://github.com/rabbitmq/amqp091-go/issues/141)
- bug, close cause panic [\#130](https://github.com/rabbitmq/amqp091-go/issues/130)
- Publishing Headers are unable to store Table with slice values [\#125](https://github.com/rabbitmq/amqp091-go/issues/125)
- Example client can deadlock in Close due to unconsumed confirmations [\#122](https://github.com/rabbitmq/amqp091-go/issues/122)
- SAC not working properly [\#106](https://github.com/rabbitmq/amqp091-go/issues/106)

**Merged pull requests:**

- Add automatic CHANGELOG.md generation [\#158](https://github.com/rabbitmq/amqp091-go/pull/158) ([lukebakken](https://github.com/lukebakken))
- Supply library-defined props with NewConnectionProperties [\#157](https://github.com/rabbitmq/amqp091-go/pull/157) ([slagiewka](https://github.com/slagiewka))
- Fix linter warnings [\#156](https://github.com/rabbitmq/amqp091-go/pull/156) ([Zerpet](https://github.com/Zerpet))
- Remove outdated information from README [\#155](https://github.com/rabbitmq/amqp091-go/pull/155) ([scriptcoded](https://github.com/scriptcoded))
- Add example producer using DeferredConfirm [\#149](https://github.com/rabbitmq/amqp091-go/pull/149) ([Zerpet](https://github.com/Zerpet))
- Ensure code is formatted [\#147](https://github.com/rabbitmq/amqp091-go/pull/147) ([lukebakken](https://github.com/lukebakken))
- Fix inefficient use of buffers that reduces the potential throughput of basicPublish [\#142](https://github.com/rabbitmq/amqp091-go/pull/142) ([fadams](https://github.com/fadams))
- Do not embed context in DeferredConfirmation [\#140](https://github.com/rabbitmq/amqp091-go/pull/140) ([tie](https://github.com/tie))
- Add constant for default exchange [\#139](https://github.com/rabbitmq/amqp091-go/pull/139) ([marlongerson](https://github.com/marlongerson))
- Fix indentation and remove unnecessary instructions [\#138](https://github.com/rabbitmq/amqp091-go/pull/138) ([alraujo](https://github.com/alraujo))
- Remove unnecessary instruction [\#135](https://github.com/rabbitmq/amqp091-go/pull/135) ([alraujo](https://github.com/alraujo))
- Fix example client to avoid deadlock in Close [\#123](https://github.com/rabbitmq/amqp091-go/pull/123) ([Zerpet](https://github.com/Zerpet))
- Bump go.uber.org/goleak from 1.1.12 to 1.2.0 [\#116](https://github.com/rabbitmq/amqp091-go/pull/116) ([dependabot[bot]](https://github.com/apps/dependabot))

## [v1.5.0](https://github.com/rabbitmq/amqp091-go/tree/v1.5.0) (2022-09-07)

[Full Changelog](https://github.com/rabbitmq/amqp091-go/compare/v1.4.0...v1.5.0)

**Implemented enhancements:**

- Provide a friendly way to set connection name [\#105](https://github.com/rabbitmq/amqp091-go/issues/105)

**Closed issues:**

- Support connection.update-secret  [\#107](https://github.com/rabbitmq/amqp091-go/issues/107)
- Example Client: Implementation of a Consumer with reconnection support [\#40](https://github.com/rabbitmq/amqp091-go/issues/40)

**Merged pull requests:**

- use PublishWithContext instead of Publish [\#115](https://github.com/rabbitmq/amqp091-go/pull/115) ([Gsantomaggio](https://github.com/Gsantomaggio))
- Add support for connection.update-secret [\#114](https://github.com/rabbitmq/amqp091-go/pull/114) ([Zerpet](https://github.com/Zerpet))
- Remove warning on RabbitMQ tutorials in go [\#113](https://github.com/rabbitmq/amqp091-go/pull/113) ([ChunyiLyu](https://github.com/ChunyiLyu))
- Update AMQP Spec [\#110](https://github.com/rabbitmq/amqp091-go/pull/110) ([Zerpet](https://github.com/Zerpet))
- Add an example of reliable consumer [\#109](https://github.com/rabbitmq/amqp091-go/pull/109) ([Zerpet](https://github.com/Zerpet))
- Add convenience function to set connection name [\#108](https://github.com/rabbitmq/amqp091-go/pull/108) ([Zerpet](https://github.com/Zerpet))

## [v1.4.0](https://github.com/rabbitmq/amqp091-go/tree/v1.4.0) (2022-07-19)

[Full Changelog](https://github.com/rabbitmq/amqp091-go/compare/v1.3.4...v1.4.0)

**Closed issues:**

- target machine actively refused connection [\#99](https://github.com/rabbitmq/amqp091-go/issues/99)
- 504 channel/connection is not open error occurred in multiple connection with same rabbitmq service [\#97](https://github.com/rabbitmq/amqp091-go/issues/97)
- Add possible cancel of DeferredConfirmation [\#92](https://github.com/rabbitmq/amqp091-go/issues/92)
- Documentation  [\#89](https://github.com/rabbitmq/amqp091-go/issues/89)
- Channel Close gets stuck after closing a connection \(via management UI\) [\#88](https://github.com/rabbitmq/amqp091-go/issues/88)
- this library has same issue [\#83](https://github.com/rabbitmq/amqp091-go/issues/83)
- Provide a logging interface [\#81](https://github.com/rabbitmq/amqp091-go/issues/81)
- 1.4.0 release checklist [\#77](https://github.com/rabbitmq/amqp091-go/issues/77)
- Data race in the client example [\#72](https://github.com/rabbitmq/amqp091-go/issues/72)
- reader go routine hangs and leaks when Connection.Close\(\) is called multiple times [\#69](https://github.com/rabbitmq/amqp091-go/issues/69)
- Support auto-reconnect and cluster [\#65](https://github.com/rabbitmq/amqp091-go/issues/65)
- Connection/Channel Deadlock [\#32](https://github.com/rabbitmq/amqp091-go/issues/32)
- Closing connection and/or channel hangs NotifyPublish is used [\#21](https://github.com/rabbitmq/amqp091-go/issues/21)
- Consumer channel isn't closed in the event of unexpected disconnection [\#18](https://github.com/rabbitmq/amqp091-go/issues/18)

**Merged pull requests:**

- fix race condition with context close and confirm at the same time on DeferredConfirmation. [\#101](https://github.com/rabbitmq/amqp091-go/pull/101) ([sapk](https://github.com/sapk))
- Add build TLS config from URI [\#98](https://github.com/rabbitmq/amqp091-go/pull/98) ([reddec](https://github.com/reddec))
- Use context for Publish methods [\#96](https://github.com/rabbitmq/amqp091-go/pull/96) ([sapk](https://github.com/sapk))
- Added function to get the remote peer's IP address \(conn.RemoteAddr\(\)\) [\#95](https://github.com/rabbitmq/amqp091-go/pull/95) ([rabb1t](https://github.com/rabb1t))
- Update connection documentation [\#90](https://github.com/rabbitmq/amqp091-go/pull/90) ([Zerpet](https://github.com/Zerpet))
- Revert test to demonstrate actual bug [\#87](https://github.com/rabbitmq/amqp091-go/pull/87) ([lukebakken](https://github.com/lukebakken))
- Minor improvements to examples [\#86](https://github.com/rabbitmq/amqp091-go/pull/86) ([lukebakken](https://github.com/lukebakken))
- Do not skip flaky test in CI [\#85](https://github.com/rabbitmq/amqp091-go/pull/85) ([lukebakken](https://github.com/lukebakken))
- Add logging [\#84](https://github.com/rabbitmq/amqp091-go/pull/84) ([lukebakken](https://github.com/lukebakken))
- Add a win32 build [\#82](https://github.com/rabbitmq/amqp091-go/pull/82) ([lukebakken](https://github.com/lukebakken))
- channel: return nothing instead of always a nil-error in receive methods [\#80](https://github.com/rabbitmq/amqp091-go/pull/80) ([fho](https://github.com/fho))
- update the contributing & readme files, improve makefile [\#79](https://github.com/rabbitmq/amqp091-go/pull/79) ([fho](https://github.com/fho))
- Fix lint errors [\#78](https://github.com/rabbitmq/amqp091-go/pull/78) ([lukebakken](https://github.com/lukebakken))
- ci: run golangci-lint [\#76](https://github.com/rabbitmq/amqp091-go/pull/76) ([fho](https://github.com/fho))
- ci: run test via make & remove travis CI config [\#75](https://github.com/rabbitmq/amqp091-go/pull/75) ([fho](https://github.com/fho))
- ci: run tests with race detector [\#74](https://github.com/rabbitmq/amqp091-go/pull/74) ([fho](https://github.com/fho))
- Detect go routine leaks in integration testcases [\#73](https://github.com/rabbitmq/amqp091-go/pull/73) ([fho](https://github.com/fho))
- connection: fix: reader go-routine is leaked on connection close [\#70](https://github.com/rabbitmq/amqp091-go/pull/70) ([fho](https://github.com/fho))
- adding best practises for NotifyPublish for issue\_21 scenario [\#68](https://github.com/rabbitmq/amqp091-go/pull/68) ([DanielePalaia](https://github.com/DanielePalaia))
- Update Go version [\#67](https://github.com/rabbitmq/amqp091-go/pull/67) ([Zerpet](https://github.com/Zerpet))
- Regenerate certs with SHA256 to fix test with Go 1.18+ [\#66](https://github.com/rabbitmq/amqp091-go/pull/66) ([anthonyfok](https://github.com/anthonyfok))

## [v1.3.4](https://github.com/rabbitmq/amqp091-go/tree/v1.3.4) (2022-04-01)

[Full Changelog](https://github.com/rabbitmq/amqp091-go/compare/v1.3.3...v1.3.4)

**Merged pull requests:**

- bump version to 1.3.4 [\#63](https://github.com/rabbitmq/amqp091-go/pull/63) ([DanielePalaia](https://github.com/DanielePalaia))
- updating doc [\#62](https://github.com/rabbitmq/amqp091-go/pull/62) ([DanielePalaia](https://github.com/DanielePalaia))

## [v1.3.3](https://github.com/rabbitmq/amqp091-go/tree/v1.3.3) (2022-04-01)

[Full Changelog](https://github.com/rabbitmq/amqp091-go/compare/v1.3.2...v1.3.3)

**Closed issues:**

- Add Client Version [\#49](https://github.com/rabbitmq/amqp091-go/issues/49)
- OpenTelemetry Propagation [\#22](https://github.com/rabbitmq/amqp091-go/issues/22)

**Merged pull requests:**

- bump buildVersion for release [\#61](https://github.com/rabbitmq/amqp091-go/pull/61) ([DanielePalaia](https://github.com/DanielePalaia))
- adding documentation for notifyClose best pratices [\#60](https://github.com/rabbitmq/amqp091-go/pull/60) ([DanielePalaia](https://github.com/DanielePalaia))
- adding documentation on NotifyClose of connection and channel to enfo… [\#59](https://github.com/rabbitmq/amqp091-go/pull/59) ([DanielePalaia](https://github.com/DanielePalaia))

## [v1.3.2](https://github.com/rabbitmq/amqp091-go/tree/v1.3.2) (2022-03-28)

[Full Changelog](https://github.com/rabbitmq/amqp091-go/compare/v1.3.1...v1.3.2)

**Closed issues:**

- Potential race condition in Connection module [\#31](https://github.com/rabbitmq/amqp091-go/issues/31)

**Merged pull requests:**

- bump versioning to 1.3.2 [\#58](https://github.com/rabbitmq/amqp091-go/pull/58) ([DanielePalaia](https://github.com/DanielePalaia))

## [v1.3.1](https://github.com/rabbitmq/amqp091-go/tree/v1.3.1) (2022-03-25)

[Full Changelog](https://github.com/rabbitmq/amqp091-go/compare/v1.3.0...v1.3.1)

**Closed issues:**

- Possible deadlock on DeferredConfirmation.Wait\(\) [\#46](https://github.com/rabbitmq/amqp091-go/issues/46)
- Call to Delivery.Ack blocks indefinitely in case of disconnection [\#19](https://github.com/rabbitmq/amqp091-go/issues/19)
- Unexpacted behavor of channel.IsClosed\(\) [\#14](https://github.com/rabbitmq/amqp091-go/issues/14)
- A possible dead lock in connection close notification Go channel [\#11](https://github.com/rabbitmq/amqp091-go/issues/11)

**Merged pull requests:**

- These ones were the ones testing Open scenarios. The issue is that Op… [\#57](https://github.com/rabbitmq/amqp091-go/pull/57) ([DanielePalaia](https://github.com/DanielePalaia))
- changing defaultVersion to buildVersion and create a simple change\_ve… [\#54](https://github.com/rabbitmq/amqp091-go/pull/54) ([DanielePalaia](https://github.com/DanielePalaia))
- adding integration test for issue 11 [\#50](https://github.com/rabbitmq/amqp091-go/pull/50) ([DanielePalaia](https://github.com/DanielePalaia))
- Remove the old link product [\#48](https://github.com/rabbitmq/amqp091-go/pull/48) ([Gsantomaggio](https://github.com/Gsantomaggio))
- Fix deadlock on DeferredConfirmations [\#47](https://github.com/rabbitmq/amqp091-go/pull/47) ([SpencerTorres](https://github.com/SpencerTorres))
- Example client: Rename Stream\(\) to Consume\(\)  to avoid confusion with RabbitMQ streams [\#39](https://github.com/rabbitmq/amqp091-go/pull/39) ([andygrunwald](https://github.com/andygrunwald))
- Example client: Rename `name` to `queueName` to make the usage clear and explicit [\#38](https://github.com/rabbitmq/amqp091-go/pull/38) ([andygrunwald](https://github.com/andygrunwald))
- Client example: Renamed concept "Session" to "Client" [\#37](https://github.com/rabbitmq/amqp091-go/pull/37) ([andygrunwald](https://github.com/andygrunwald))
- delete unuseful code [\#36](https://github.com/rabbitmq/amqp091-go/pull/36) ([liutaot](https://github.com/liutaot))
- Client Example: Fix closing order [\#35](https://github.com/rabbitmq/amqp091-go/pull/35) ([andygrunwald](https://github.com/andygrunwald))
- Client example: Use instance logger instead of global logger [\#34](https://github.com/rabbitmq/amqp091-go/pull/34) ([andygrunwald](https://github.com/andygrunwald))

## [v1.3.0](https://github.com/rabbitmq/amqp091-go/tree/v1.3.0) (2022-01-13)

[Full Changelog](https://github.com/rabbitmq/amqp091-go/compare/v1.2.0...v1.3.0)

**Closed issues:**

- documentation of changes triggering version updates [\#29](https://github.com/rabbitmq/amqp091-go/issues/29)
- Persistent messages folder [\#27](https://github.com/rabbitmq/amqp091-go/issues/27)

**Merged pull requests:**

- Expose a method to enable out-of-order Publisher Confirms [\#33](https://github.com/rabbitmq/amqp091-go/pull/33) ([benmoss](https://github.com/benmoss))
- Fix Signed 8-bit headers being treated as unsigned [\#26](https://github.com/rabbitmq/amqp091-go/pull/26) ([alex-goodisman](https://github.com/alex-goodisman))

## [v1.2.0](https://github.com/rabbitmq/amqp091-go/tree/v1.2.0) (2021-11-17)

[Full Changelog](https://github.com/rabbitmq/amqp091-go/compare/v1.1.0...v1.2.0)

**Closed issues:**

- No access to this vhost [\#24](https://github.com/rabbitmq/amqp091-go/issues/24)
- copyright issue? [\#12](https://github.com/rabbitmq/amqp091-go/issues/12)
- A possible dead lock when publishing message with confirmation  [\#10](https://github.com/rabbitmq/amqp091-go/issues/10)
- Semver release [\#7](https://github.com/rabbitmq/amqp091-go/issues/7)

**Merged pull requests:**

- Fix deadlock between publishing and receiving confirms [\#25](https://github.com/rabbitmq/amqp091-go/pull/25) ([benmoss](https://github.com/benmoss))
- Add GetNextPublishSeqNo for channel in confirm mode [\#23](https://github.com/rabbitmq/amqp091-go/pull/23) ([kamal-github](https://github.com/kamal-github))
- Added support for cert-only login without user and password [\#20](https://github.com/rabbitmq/amqp091-go/pull/20) ([mihaitodor](https://github.com/mihaitodor))

## [v1.1.0](https://github.com/rabbitmq/amqp091-go/tree/v1.1.0) (2021-09-21)

[Full Changelog](https://github.com/rabbitmq/amqp091-go/compare/ebd83429aa8cb06fa569473f623e87675f96d3a9...v1.1.0)

**Closed issues:**

- AMQPLAIN authentication does not work [\#15](https://github.com/rabbitmq/amqp091-go/issues/15)

**Merged pull requests:**

-  Fix AMQPLAIN authentication mechanism [\#16](https://github.com/rabbitmq/amqp091-go/pull/16) ([hodbn](https://github.com/hodbn))
- connection: clarify documented behavior of NotifyClose [\#13](https://github.com/rabbitmq/amqp091-go/pull/13) ([pabigot](https://github.com/pabigot))
- Add a link to pkg.go.dev API docs [\#9](https://github.com/rabbitmq/amqp091-go/pull/9) ([benmoss](https://github.com/benmoss))
- add test go version 1.16.x and 1.17.x [\#8](https://github.com/rabbitmq/amqp091-go/pull/8) ([k4n4ry](https://github.com/k4n4ry))
- fix typos [\#6](https://github.com/rabbitmq/amqp091-go/pull/6) ([h44z](https://github.com/h44z))
- Heartbeat interval should be timeout/2 [\#5](https://github.com/rabbitmq/amqp091-go/pull/5) ([ifo20](https://github.com/ifo20))
- Exporting Channel State [\#4](https://github.com/rabbitmq/amqp091-go/pull/4) ([eibrunorodrigues](https://github.com/eibrunorodrigues))
- Add codeql analysis [\#3](https://github.com/rabbitmq/amqp091-go/pull/3) ([MirahImage](https://github.com/MirahImage))
- Add PR github action. [\#2](https://github.com/rabbitmq/amqp091-go/pull/2) ([MirahImage](https://github.com/MirahImage))
- Update Copyright Statement [\#1](https://github.com/rabbitmq/amqp091-go/pull/1) ([rlewis24](https://github.com/rlewis24))



\* *This Changelog was automatically generated by [github_changelog_generator](https://github.com/github-changelog-generator/github-changelog-generator)*
