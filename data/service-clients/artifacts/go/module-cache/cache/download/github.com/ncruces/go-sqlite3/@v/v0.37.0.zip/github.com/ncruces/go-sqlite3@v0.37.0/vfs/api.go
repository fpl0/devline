// Package vfs wraps the C SQLite VFS API.
package vfs

import (
	"io"

	"github.com/ncruces/go-sqlite3/internal/sqlite3_wrap"
)

// A VFS defines the interface between the SQLite core and the underlying operating system.
//
// Use [SystemError], sqlite3.ErrorCode, or sqlite3.ExtendedErrorCode
// to return specific error codes to SQLite.
//
// https://sqlite.org/c3ref/vfs.html
type VFS interface {
	Open(name string, flags OpenFlag) (File, OpenFlag, error)
	Delete(name string, syncDir bool) error
	Access(name string, flags AccessFlag) (bool, error)
	FullPathname(name string) (string, error)
}

// VFSFilename extends VFS with the ability to use Filename
// objects for opening files.
//
// https://sqlite.org/c3ref/filename.html
type VFSFilename interface {
	VFS
	OpenFilename(name *Filename, flags OpenFlag) (File, OpenFlag, error)
}

// A File represents an open file in the OS interface layer.
//
// Use [SystemError], sqlite3.ErrorCode, or sqlite3.ExtendedErrorCode
// to return specific error codes to SQLite.
// In particular, sqlite3.BUSY is needed to correctly implement lock methods.
//
// https://sqlite.org/c3ref/io_methods.html
type File interface {
	io.Closer
	io.ReaderAt
	io.WriterAt
	Truncate(size int64) error
	Sync(flags SyncFlag) error
	Size() (int64, error)
	Lock(lock LockLevel) error
	Unlock(lock LockLevel) error
	CheckReservedLock() (bool, error)
	SectorSize() int
	DeviceCharacteristics() DeviceCharacteristic
}

// FileUnwrap should be implemented by a File
// that wraps another File implementation.
type FileUnwrap interface {
	File
	Unwrap() File
}

// FileLockState extends File to implement the
// SQLITE_FCNTL_LOCKSTATE file control opcode.
//
// https://sqlite.org/c3ref/c_fcntl_begin_atomic_write.html#sqlitefcntllockstate
type FileLockState interface {
	File
	LockState() LockLevel
}

// FilePersistWAL extends File to implement the
// SQLITE_FCNTL_PERSIST_WAL file control opcode.
//
// https://sqlite.org/c3ref/c_fcntl_begin_atomic_write.html#sqlitefcntlpersistwal
type FilePersistWAL interface {
	File
	PersistWAL() bool
	SetPersistWAL(bool)
}

// FilePowersafeOverwrite extends File to implement the
// SQLITE_FCNTL_POWERSAFE_OVERWRITE file control opcode.
//
// https://sqlite.org/c3ref/c_fcntl_begin_atomic_write.html#sqlitefcntlpowersafeoverwrite
type FilePowersafeOverwrite interface {
	File
	PowersafeOverwrite() bool
	SetPowersafeOverwrite(bool)
}

// FileChunkSize extends File to implement the
// SQLITE_FCNTL_CHUNK_SIZE file control opcode.
//
// https://sqlite.org/c3ref/c_fcntl_begin_atomic_write.html#sqlitefcntlchunksize
type FileChunkSize interface {
	File
	ChunkSize(size int)
}

// FileSizeHint extends File to implement the
// SQLITE_FCNTL_SIZE_HINT file control opcode.
//
// https://sqlite.org/c3ref/c_fcntl_begin_atomic_write.html#sqlitefcntlsizehint
type FileSizeHint interface {
	File
	SizeHint(size int64) error
}

// FileHasMoved extends File to implement the
// SQLITE_FCNTL_HAS_MOVED file control opcode.
//
// https://sqlite.org/c3ref/c_fcntl_begin_atomic_write.html#sqlitefcntlhasmoved
type FileHasMoved interface {
	File
	HasMoved() (bool, error)
}

// FileOverwrite extends File to implement the
// SQLITE_FCNTL_OVERWRITE file control opcode.
//
// https://sqlite.org/c3ref/c_fcntl_begin_atomic_write.html#sqlitefcntloverwrite
type FileOverwrite interface {
	File
	Overwrite() error
}

// FileSync extends File to implement the
// SQLITE_FCNTL_SYNC file control opcode.
//
// https://sqlite.org/c3ref/c_fcntl_begin_atomic_write.html#sqlitefcntlsync
type FileSync interface {
	File
	SyncSuper(super string) error
}

// FileCommitPhaseTwo extends File to implement the
// SQLITE_FCNTL_COMMIT_PHASETWO file control opcode.
//
// https://sqlite.org/c3ref/c_fcntl_begin_atomic_write.html#sqlitefcntlcommitphasetwo
type FileCommitPhaseTwo interface {
	File
	CommitPhaseTwo() error
}

// FileBatchAtomicWrite extends File to implement the
// SQLITE_FCNTL_BEGIN_ATOMIC_WRITE, SQLITE_FCNTL_COMMIT_ATOMIC_WRITE
// and SQLITE_FCNTL_ROLLBACK_ATOMIC_WRITE file control opcodes.
//
// https://sqlite.org/c3ref/c_fcntl_begin_atomic_write.html#sqlitefcntlbeginatomicwrite
type FileBatchAtomicWrite interface {
	File
	BeginAtomicWrite() error
	CommitAtomicWrite() error
	RollbackAtomicWrite() error
}

// FileCheckpoint extends File to implement the
// SQLITE_FCNTL_CKPT_START and SQLITE_FCNTL_CKPT_DONE
// file control opcodes.
//
// https://sqlite.org/c3ref/c_fcntl_begin_atomic_write.html#sqlitefcntlckptstart
type FileCheckpoint interface {
	File
	CheckpointStart()
	CheckpointDone()
}

// FilePragma extends File to implement the
// SQLITE_FCNTL_PRAGMA file control opcode.
//
// https://sqlite.org/c3ref/c_fcntl_begin_atomic_write.html#sqlitefcntlpragma
type FilePragma interface {
	File
	Pragma(name, value string) (string, error)
}

// FileBusyHandler extends File to implement the
// SQLITE_FCNTL_BUSYHANDLER file control opcode.
//
// https://sqlite.org/c3ref/c_fcntl_begin_atomic_write.html#sqlitefcntlbusyhandler
type FileBusyHandler interface {
	File
	BusyHandler(func() bool)
}

// FileSharedMemory extends File to possibly implement
// shared-memory for the WAL-index.
// The same shared-memory instance must be returned
// for the entire life of the file.
// It's OK for SharedMemory to return nil.
type FileSharedMemory interface {
	File
	SharedMemory() SharedMemory
}

// SharedMemory is a shared-memory WAL-index implementation.
// Use [NewSharedMemory] to create a shared-memory.
type SharedMemory interface {
	shmMap(*sqlite3_wrap.Wrapper, int32, int32, bool) (ptr_t, error)
	shmLock(int32, int32, _ShmFlag) error
	shmUnmap(bool)
	shmBarrier()
	io.Closer

	// IOLock provides blocking locks shared by all connections to a database.
	// SQLite guarantees that concurrent reads and writes to a database
	// are disjoint, so they can't tear each other.
	// A VFS that modifies whole sectors may break this guarantee:
	// a partial sector write rewrites bytes that a concurrent
	// partial sector read may be reading.
	// Such a VFS must hold a SHARED lock around partial sector reads,
	// and EXCLUSIVE around partial sector writes; NONE releases it.
	// Calls for the same sector must use the same id (e.g., the sector offset).
	// This does nothing unless the WAL-index is in use,
	// since the WAL-index is required for reader-writer concurrency.
	IOLock(lock LockLevel, id int64) error
}

type blockingSharedMemory interface {
	SharedMemory
	shmEnableBlocking(block bool)
}

// FileMemoryMapper extends File to possibly implement
// memory mapped files.
// The same memory mapper instance must be returned
// for the entire life of the file.
// It's OK for MemoryMapper to return nil.
type FileMemoryMapper interface {
	File
	MemoryMapper() MemoryMapper
}

// MemoryMapper is a file mapper implementation.
// Use [NewMemoryMapper] to create a mapper.
type MemoryMapper interface {
	mmapSize(*sqlite3_wrap.Wrapper, ptr_t)
	fetch(*sqlite3_wrap.Wrapper, int64, int32, ptr_t) error
	io.Closer
}

// FileControl makes it easy to forward all fileControl methods,
// which we want to do for the checksum VFS.
// However, this is not a safe default, and other VFSes
// should explicitly wrap the methods they want to wrap.
type fileControl interface {
	File
	fileControl(*sqlite3_wrap.Wrapper, _FcntlOpcode, ptr_t) _ErrorCode
}

type filePDB interface {
	File
	SetDB(any)
}
