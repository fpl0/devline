module github.com/aws/aws-sdk-go-v2

require github.com/aws/smithy-go v1.28.8

go 1.24
