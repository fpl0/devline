/*
 * Copyright (c) 2023-2026 Maveniverse Org.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v2.0
 * which accompanies this distribution, and is available at
 * https://www.eclipse.org/legal/epl-v20.html
 */
package eu.maveniverse.domtrip;

import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * Represents an XML element with attributes and children, preserving original
 * formatting including attribute spacing, quote styles, and element structure.
 *
 * <p>The Element class is the core building block for XML documents, representing
 * XML elements with their attributes, child nodes, and namespace information.
 * It maintains lossless formatting preservation during round-trip parsing and
 * serialization operations.</p>
 *
 * <h3>Capabilities:</h3>
 * <ul>
 *   <li><strong>Attribute Management</strong> - Preserves attribute order, quote styles, and whitespace</li>
 *   <li><strong>Namespace Support</strong> - XML namespace handling with prefix resolution</li>
 *   <li><strong>Child Navigation</strong> - Methods for finding and manipulating child elements</li>
 *   <li><strong>Self-Closing Support</strong> - Handles self-closing tags</li>
 *   <li><strong>Formatting Preservation</strong> - Maintains original tag formatting and whitespace</li>
 * </ul>
 *
 * <h3>Usage Examples:</h3>
 * <pre>{@code
 * // Create elements using factory methods
 * Element root = Element.of("root").attribute("id", "main");
 * Element textElement = Element.text("child", "Hello World");
 * Element selfClosing = Element.selfClosing("br");
 *
 * // Add child elements
 * root.addNode(textElement);
 * root.addNode(Element.text("version", "1.0.0"));
 *
 * // Navigate children
 * Optional<Element> found = root.child("child");
 * Stream<Element> children = root.children("item");
 *
 * // Namespace handling
 * QName soapEnvelope = QName.of("http://schemas.xmlsoap.org/soap/envelope/", "Envelope", "soap");
 * Element nsElement = Element.of(soapEnvelope);
 *
 * // Complex elements with fluent API
 * Element dependency = Element.of("dependency")
 *     .attribute("scope", "test");
 * dependency.addNode(Element.text("groupId", "junit"));
 * dependency.addNode(Element.text("artifactId", "junit"));
 * }</pre>
 *
 * <h3>Attribute Handling:</h3>
 * <p>Elements maintain attributes using {@link Attribute} objects that preserve
 * the original quote style, whitespace, and raw values. The {@code setAttribute}
 * methods automatically preserve existing formatting when updating attributes:</p>
 * <pre>{@code
 * // Setting new attributes uses default formatting
 * element.setAttribute("class", "important");           // Uses default double quotes
 * element.setAttribute("style", "color: red", '\'');    // Uses single quotes
 *
 * // Updating existing attributes preserves original formatting
 * element.setAttribute("class", "updated");             // Preserves original quotes/whitespace
 * String value = element.attribute("class");         // Returns "updated"
 *
 * // For advanced formatting control, use attribute objects directly
 * element.attributeObject("class").value("manual");
 * }</pre>
 *
 * @implNote This class is not thread-safe. It uses mutable state with no synchronization.
 *
 * @see ContainerNode
 * @see Attribute
 * @see NamespaceContext
 */
public class Element extends ContainerNode {

    /** The XML namespace attribute name for default namespace declarations. */
    static final String XMLNS = "xmlns";

    /** The XML namespace attribute prefix for prefixed namespace declarations. */
    static final String XMLNS_PREFIX = "xmlns:";

    private String name;
    private Map<String, Attribute> attributes;
    private String openTagWhitespace; // Whitespace within the opening tag
    private String closeTagWhitespace; // Whitespace within the closing tag
    private String innerPrecedingWhitespace; // Whitespace immediately before the closing tag
    private boolean selfClosing;

    // Source-backed original tag storage — avoids substring allocation during parsing.
    // When tagSource is non-null and indices are >= 0, the original tag text is a slice
    // of the source XML. The materialized String fields are lazily populated on first access.
    private String tagSource; // Reference to source XML string (shared for open + close tags)
    private int openTagStart = -1; // Start index into tagSource (-1 = not source-backed)
    private int openTagEnd = -1;
    private int closeTagStart = -1;
    private int closeTagEnd = -1;
    private String originalOpenTag; // Materialized string (from public API or lazily from source)
    private String originalCloseTag;

    /**
     * Create a new Element with the given tag name.
     *
     * <p>The element is initialized with an empty, order-preserving attribute map,
     * default (empty) whitespace/formatting fields, and is not self-closing.</p>
     *
     * @param name the element's tag name; leading/trailing whitespace is trimmed
     * @throws DomTripException if {@code name} is null or blank
     */
    public Element(String name) throws DomTripException {
        super();
        if (name == null || name.trim().isEmpty()) {
            throw new DomTripException("Element name cannot be null or empty");
        }
        this.name = name.trim();
        this.attributes = new LinkedHashMap<>(); // Preserve attribute order
        this.openTagWhitespace = "";
        this.closeTagWhitespace = "";
        this.innerPrecedingWhitespace = "";
        this.selfClosing = false;
    }

    /**
     * Creates a deep copy of the given element.
     *
     * The new element contains deep-copied attribute objects and deep-copied child nodes,
     * preserves whitespace, self-closing flag, and original-tag source/index metadata
     * (or materialized original tag strings) from the source element.
     * The clone does not copy the parent reference or the modified state.
     *
     * @param original the element to copy from
     */
    private Element(Element original) {
        super(); // Initialize ContainerNode with empty nodes list
        this.name = original.name;

        // Deep copy attributes to avoid sharing Attribute objects
        this.attributes = new LinkedHashMap<>();
        for (Map.Entry<String, Attribute> entry : original.attributes.entrySet()) {
            this.attributes.put(entry.getKey(), entry.getValue().copy());
        }

        this.openTagWhitespace = original.openTagWhitespace;
        this.closeTagWhitespace = original.closeTagWhitespace;
        this.innerPrecedingWhitespace = original.innerPrecedingWhitespace;
        this.selfClosing = original.selfClosing;
        // Materialize original tags to avoid pinning the entire source buffer
        this.originalOpenTag = original.originalOpenTag();
        this.originalCloseTag = original.originalCloseTag();
        this.tagSource = null;
        this.openTagStart = -1;
        this.openTagEnd = -1;
        this.closeTagStart = -1;
        this.closeTagEnd = -1;

        // Copy inherited Node properties
        this.precedingWhitespace = original.precedingWhitespace;

        // Deep copy children directly to avoid addNode() side effects
        for (Node child : original.children().collect(Collectors.toList())) {
            Node copiedChild = child.copy();
            copiedChild.parent(this); // Set parent directly
            this.children.add(copiedChild); // Add directly to list
        }

        // Note: parent is intentionally not copied - clone has no parent
        // Note: modified flag is not copied - clone starts as unmodified
    }

    /**
     * Returns the node type for this element.
     *
     * @return {@link NodeType#ELEMENT}
     */
    @Override
    public NodeType type() {
        return NodeType.ELEMENT;
    }

    /**
     * Gets the name (tag name) of this element.
     *
     * <p>For namespaced elements, this returns the full qualified name
     * including the prefix (e.g., "soap:Envelope"). Use {@link #localName()}
     * to get just the local part.</p>
     *
     * @return the element name
     * @see #localName()
     * @see #prefix()
     */
    public String name() {
        return name;
    }

    /**
     * Sets the element name.
     *
     * @param name the new element name
     * @return this element for method chaining
     */
    public Element name(String name) {
        this.name = name;
        markModified();
        return this;
    }

    // Attribute management

    /**
     * Gets the value of the specified attribute.
     *
     * @param name the attribute name
     * @return the attribute value, or null if the attribute doesn't exist
     */
    public String attribute(String name) {
        Attribute attr = attributes.get(name);
        return attr != null ? attr.value() : null;
    }

    /**
     * Sets an attribute value, preserving existing formatting when the attribute already exists.
     *
     * <p>When setting an attribute that already exists, this method preserves the original
     * quote style, whitespace, and other formatting properties. For new attributes, it uses
     * default formatting (double quotes, single space preceding whitespace).</p>
     *
     * <h3>Examples:</h3>
     * <pre>{@code
     * // Original: <element attr1='existing' />
     * element.attribute("attr1", "updated");
     * // Result:   <element attr1='updated' />  (preserves single quotes)
     *
     * element.attribute("attr2", "new");
     * // Result:   <element attr1='updated' attr2="new" />  (uses default double quotes)
     * }</pre>
     *
     * @param name the attribute name
     * @param value the attribute value
     * @return this element for method chaining
     * @see #attribute(String, String, QuoteStyle)
     * @see #attributeObject(String)
     */
    public Element attribute(String name, String value) {
        Attribute existingAttr = attributes.get(name);
        if (existingAttr != null) {
            // Preserve existing formatting by updating the existing attribute
            existingAttr.value(value);
        } else {
            // Create new attribute with default formatting
            attributes.put(name, new Attribute(name, value));
        }
        markModified();
        return this;
    }

    /**
     * Sets an attribute value with a specific quote style.
     *
     * <p>When setting an attribute that already exists, this method preserves the original
     * preceding whitespace but uses the specified quote style. For new attributes, it uses
     * the specified quote style with default whitespace (single space).</p>
     *
     * @param name the attribute name
     * @param value the attribute value
     * @param quoteStyle the quote style to use (SINGLE or DOUBLE)
     * @return this element for method chaining
     * @see #attribute(String, String)
     */
    public Element attribute(String name, String value, QuoteStyle quoteStyle) {
        Attribute existingAttr = attributes.get(name);
        if (existingAttr != null) {
            // Preserve existing whitespace but update quote style and value
            existingAttr.value(value);
            existingAttr.quoteStyle(quoteStyle);
        } else {
            // Create new attribute with specified quote style
            attributes.put(name, new Attribute(name, value, quoteStyle, " "));
        }
        markModified();
        return this;
    }

    /**
     * Sets attribute without marking as modified (for use during parsing)
     */
    void attributeInternal(String name, String value, char quoteChar, String precedingWhitespace, String rawValue)
            throws DomTripException {
        attributes.put(name, new Attribute(name, value, quoteChar, precedingWhitespace, rawValue));
        // Don't call markModified() here
    }

    /**
     * Removes the specified attribute from this element.
     *
     * @param name the name of the attribute to remove
     */
    public void removeAttribute(String name) {
        if (attributes.remove(name) != null) {
            markModified();
        }
    }

    /**
     * Gets all attributes as a map of names to values.
     *
     * @return a map containing all attribute names and their values
     */
    public Map<String, String> attributes() {
        Map<String, String> result = new LinkedHashMap<>();
        for (Map.Entry<String, Attribute> entry : attributes.entrySet()) {
            result.put(entry.getKey(), entry.getValue().value());
        }
        return result;
    }

    /**
     * Gets all attribute objects with their formatting information.
     *
     * @return a map of attribute names to Attribute objects
     */
    public Map<String, Attribute> attributeObjects() {
        return new LinkedHashMap<>(attributes);
    }

    /**
     * Checks if this element has the specified attribute.
     *
     * @param name the attribute name to check
     * @return true if the attribute exists, false otherwise
     */
    public boolean hasAttribute(String name) {
        return attributes.containsKey(name);
    }

    /**
     * Gets the Attribute object for the specified attribute name.
     *
     * @param name the attribute name
     * @return the Attribute object, or null if the attribute doesn't exist
     */
    public Attribute attributeObject(String name) {
        return attributes.get(name);
    }

    /**
     * Sets an attribute using an Attribute object.
     *
     * @param name the attribute name
     * @param attribute the Attribute object to set
     * @return this element for method chaining
     */
    public Element attributeObject(String name, Attribute attribute) {
        if (name != null && attribute != null) {
            attributes.put(name, attribute);
            markModified();
        }
        return this;
    }

    // Attribute formatting management

    /**
     * Sets the preceding whitespace for the specified attribute.
     *
     * @param attributeName the name of the attribute
     * @param whitespace the whitespace to set before the attribute
     * @return this element for method chaining
     */
    public Element attributeWhitespace(String attributeName, String whitespace) {
        Attribute attr = attributes.get(attributeName);
        if (attr != null) {
            attr.precedingWhitespace(whitespace);
        }
        return this;
    }

    /**
     * Gets the preceding whitespace for the specified attribute.
     *
     * @param attributeName the name of the attribute
     * @return the preceding whitespace, or a single space if not set
     */
    public String attributeWhitespace(String attributeName) {
        Attribute attr = attributes.get(attributeName);
        return attr != null ? attr.precedingWhitespace() : " ";
    }

    /**
     * Sets the quote character for the specified attribute.
     *
     * @param attributeName the name of the attribute
     * @param quoteStyle the quote style to use (SINGLE or DOUBLE)
     * @return this element for method chaining
     */
    public Element attributeQuote(String attributeName, QuoteStyle quoteStyle) {
        Attribute attr = attributes.get(attributeName);
        if (attr != null) {
            attr.quoteStyle(quoteStyle);
        }
        return this;
    }

    /**
     * Gets the quote style for the specified attribute.
     *
     * @param attributeName the name of the attribute
     * @return the quote style, or DOUBLE if not set
     */
    public QuoteStyle attributeQuote(String attributeName) {
        Attribute attr = attributes.get(attributeName);
        return attr != null ? attr.quoteStyle() : QuoteStyle.DOUBLE;
    }

    // Tag formatting
    /**
     * {@inheritDoc}
     *
     * @return this element for method chaining
     */
    @Override
    public Element parent(ContainerNode parent) {
        this.parent = parent;
        return this;
    }

    /**
     * {@inheritDoc}
     *
     * @return this element for method chaining
     */
    @Override
    public Element precedingWhitespace(String whitespace) {
        this.precedingWhitespace = whitespace != null ? whitespace : "";
        markModified();
        return this;
    }

    /**
     * Gets the whitespace within the opening tag (before the closing &gt;).
     *
     * @return the whitespace within the opening tag
     */
    public String openTagWhitespace() {
        return openTagWhitespace;
    }

    /**
     * Sets the whitespace within the opening tag (before the closing &gt;).
     *
     * @param whitespace the whitespace to set
     * @return this element for method chaining
     */
    public Element openTagWhitespace(String whitespace) {
        this.openTagWhitespace = whitespace != null ? whitespace : "";
        markModified();
        return this;
    }

    /**
     * Sets open tag whitespace without marking as modified (for use during parsing)
     */
    void openTagWhitespaceInternal(String whitespace) {
        this.openTagWhitespace = whitespace != null ? whitespace : "";
    }

    /**
     * Gets the whitespace within the closing tag (before the element name).
     *
     * @return the whitespace within the closing tag
     */
    public String closeTagWhitespace() {
        return closeTagWhitespace;
    }

    /**
     * Sets the whitespace within the closing tag (before the element name).
     *
     * @param whitespace the whitespace to set
     * @return this element for method chaining
     */
    public Element closeTagWhitespace(String whitespace) {
        this.closeTagWhitespace = whitespace != null ? whitespace : "";
        markModified();
        return this;
    }

    /**
     * Sets close tag whitespace without marking as modified (for use during parsing)
     */
    void closeTagWhitespaceInternal(String whitespace) {
        this.closeTagWhitespace = whitespace != null ? whitespace : "";
    }

    /**
     * Gets the whitespace immediately before the closing tag.
     *
     * <p>This field is used for elements that contain only whitespace content
     * (no child elements). It represents the whitespace that appears just
     * before the closing tag, typically used for proper indentation.</p>
     *
     * <h3>Example:</h3>
     * <pre>{@code
     * // XML: <parent>\n    \n</parent>
     * String whitespace = element.innerPrecedingWhitespace(); // "\n"
     * }</pre>
     *
     * @return the inner preceding whitespace, or empty string if none
     * @see #precedingWhitespace()
     */
    public String innerPrecedingWhitespace() {
        return innerPrecedingWhitespace;
    }

    /**
     * Sets the whitespace immediately before the closing tag.
     *
     * <p>Use this method to control the whitespace that appears immediately
     * before the closing tag in elements that contain only whitespace content.
     * This is typically used for proper indentation of the closing tag.</p>
     *
     * <h3>Example:</h3>
     * <pre>{@code
     * element.innerPrecedingWhitespace("\n");
     * // Results in: <element>content\n</element> (whitespace before closing tag)
     * }</pre>
     *
     * @param whitespace the whitespace to set (null is treated as empty string)
     * @return this element for method chaining
     * @see #innerPrecedingWhitespace()
     */
    public Element innerPrecedingWhitespace(String whitespace) {
        this.innerPrecedingWhitespace = whitespace != null ? whitespace : "";
        markModified();
        return this;
    }

    /**
     * Sets inner preceding whitespace without marking as modified (for use during parsing)
     */
    void innerPrecedingWhitespaceInternal(String whitespace) {
        this.innerPrecedingWhitespace = whitespace != null ? whitespace : "";
    }

    /**
     * Checks if this element is self-closing.
     *
     * @return true if the element is self-closing, false otherwise
     */
    public boolean selfClosing() {
        return selfClosing;
    }

    /**
     * Sets whether this element should be self-closing.
     *
     * @param selfClosing true to make the element self-closing, false otherwise
     * @return this element for method chaining
     */
    public Element selfClosing(boolean selfClosing) {
        this.selfClosing = selfClosing;
        markModified();
        return this;
    }

    /**
     * Sets self-closing flag without marking as modified (for internal use)
     */
    void selfClosingInternal(boolean selfClosing) {
        this.selfClosing = selfClosing;
    }

    // Original tag preservation

    /**
     * Provide the original open tag exactly as it appeared in the source, or an empty string if none is available.
     *
     * If the element was parsed from a source buffer and the original open-tag slice is available,
     * the tag is materialized from that source on first access.
     *
     * @return the original opening tag string, or empty string if not available
     */
    public String originalOpenTag() {
        if (originalOpenTag == null) {
            if (openTagStart >= 0) {
                originalOpenTag = tagSource.substring(openTagStart, openTagEnd);
            } else {
                return "";
            }
        }
        return originalOpenTag;
    }

    /**
     * Set the materialized original open tag and disable source-backed tag slicing.
     *
     * @param originalOpenTag the original opening tag; null is treated as an empty string
     * @return this element for method chaining
     */
    public Element originalOpenTag(String originalOpenTag) {
        this.originalOpenTag = originalOpenTag != null ? originalOpenTag : "";
        this.openTagStart = -1; // No longer source-backed
        return this;
    }

    /**
     * Record a source-backed slice for the element's original open tag for lazy materialization; intended for parser-only use.
     *
     * @param source the full source string containing the tag
     * @param start  the inclusive start index of the open-tag slice within {@code source}
     * @param end    the exclusive end index of the open-tag slice within {@code source}
     */
    void originalOpenTagInternal(String source, int start, int end) {
        this.tagSource = source;
        this.openTagStart = start;
        this.openTagEnd = end;
        this.originalOpenTag = null; // Lazily materialized
    }

    /**
     * Gets the original closing tag as it appeared in the source XML.
     *
     * @return the original closing tag string, or empty string if not available
     */
    public String originalCloseTag() {
        if (originalCloseTag == null) {
            if (closeTagStart >= 0) {
                originalCloseTag = tagSource.substring(closeTagStart, closeTagEnd);
            } else {
                return "";
            }
        }
        return originalCloseTag;
    }

    /**
     * Set the materialized original closing tag and disable source-backed close-tag slicing.
     *
     * If `originalCloseTag` is null, an empty string is stored. Calling this method clears any
     * source-backed close-tag indices so future preserved serialization will use the provided string.
     *
     * @param originalCloseTag the original closing tag string (null is stored as an empty string)
     * @return this element for method chaining
     */
    public Element originalCloseTag(String originalCloseTag) {
        this.originalCloseTag = originalCloseTag != null ? originalCloseTag : "";
        this.closeTagStart = -1; // No longer source-backed
        return this;
    }

    /**
     * Register a source-backed slice that represents the element's original closing tag (for parsing use only).
     *
     * The actual tag string is not allocated now; it will be lazily materialized from {@code source} using the
     * provided indices when needed.
     *
     * @param source the shared source string containing the closing tag
     * @param start  the inclusive start index of the closing-tag slice in {@code source}
     * @param end    the exclusive end index of the closing-tag slice in {@code source}
     */
    void originalCloseTagInternal(String source, int start, int end) {
        this.tagSource = source; // Same source reference as open tag
        this.closeTagStart = start;
        this.closeTagEnd = end;
        this.originalCloseTag = null; // Lazily materialized
    }

    /**
     * Serialize this element into XML and append the result to the supplied StringBuilder.
     *
     * If the element has not been modified and an original open tag is available, the original
     * tag formatting is preserved; otherwise the element is serialized from scratch using the
     * element's current state.
     *
     * @param sb the StringBuilder to append the XML representation to
     */
    @Override
    public void toXml(StringBuilder sb) {
        if (!isModified() && hasOriginalOpenTag()) {
            toXmlPreserved(sb);
        } else {
            toXmlFromScratch(sb);
        }
    }

    /**
     * Determine whether an original open tag is available.
     *
     * @return `true` if a source-backed or materialized original open tag is available, `false` otherwise.
     */
    private boolean hasOriginalOpenTag() {
        return openTagStart >= 0 || (originalOpenTag != null && !originalOpenTag.isEmpty());
    }

    /**
     * Determine whether a preserved original close tag exists for this element.
     *
     * @return `true` if a source-backed close-tag slice is present or a materialized close-tag string is non-empty, `false` otherwise.
     */
    private boolean hasOriginalCloseTag() {
        return closeTagStart >= 0 || (originalCloseTag != null && !originalCloseTag.isEmpty());
    }

    /**
     * Appends the element's preserved original open tag to the provided StringBuilder, using the source-backed slice when available.
     *
     * @param sb the StringBuilder to append to
     */
    private void appendOriginalOpenTag(StringBuilder sb) {
        if (originalOpenTag == null && openTagStart >= 0) {
            sb.append(tagSource, openTagStart, openTagEnd);
        } else {
            sb.append(originalOpenTag());
        }
    }

    /**
     * Appends the element's preserved original close tag to the provided StringBuilder.
     *
     * If a source-backed slice of the original close tag is available, that slice is appended;
     * otherwise the materialized original close tag string is appended.
     *
     * @param sb the StringBuilder to append the close tag to
     */
    private void appendOriginalCloseTag(StringBuilder sb) {
        if (originalCloseTag == null && closeTagStart >= 0) {
            sb.append(tagSource, closeTagStart, closeTagEnd);
        } else {
            sb.append(originalCloseTag());
        }
    }

    /**
     * Serialize this element into the given StringBuilder using preserved original tags and formatting.
     *
     * @param sb the StringBuilder to append the serialized element to
     */
    private void toXmlPreserved(StringBuilder sb) {
        sb.append(precedingWhitespace);

        if (selfClosing) {
            appendOriginalOpenTag(sb);
            return;
        }

        appendOriginalOpenTag(sb);

        appendChildrenAndCloseTag(sb);
    }

    /**
     * Serializes by building the tag from scratch.
     */
    private void toXmlFromScratch(StringBuilder sb) {
        sb.append(precedingWhitespace);
        sb.append("<").append(name);

        // Add attributes
        for (Attribute attr : attributes.values()) {
            attr.toXml(sb, !isModified());
        }

        if (selfClosing) {
            sb.append(openTagWhitespace).append("/>");
        } else {
            sb.append(openTagWhitespace).append(">");
            appendChildren(sb);
            sb.append(innerPrecedingWhitespace);
            sb.append("</").append(closeTagWhitespace).append(name).append(">");
        }
    }

    /**
     * Append this element's children, then its inner preceding whitespace, and finally the closing tag to the provided StringBuilder,
     * using the preserved original close-tag text when available.
     *
     * @param sb the StringBuilder to append XML content to
     */
    private void appendChildrenAndCloseTag(StringBuilder sb) {
        appendChildren(sb);
        sb.append(innerPrecedingWhitespace);

        if (hasOriginalCloseTag()) {
            appendOriginalCloseTag(sb);
        } else {
            sb.append("</").append(name).append(">");
        }
    }

    /**
     * Appends all children XML to the builder.
     */
    private void appendChildren(StringBuilder sb) {
        for (Node child : children) {
            child.toXml(sb);
        }
    }

    /**
     * Gets the text content of this element (concatenates all text children)
     */
    @Override
    public String textContent() {
        StringBuilder sb = new StringBuilder();
        for (Node child : children) {
            if (child instanceof Text) {
                sb.append(((Text) child).content());
            }
        }
        return sb.toString();
    }

    /**
     * Gets the text content of this element, returning a default value if the text content is null or empty.
     *
     * <p>This is a convenience method for getting text content with a fallback value.</p>
     *
     * <h4>Example:</h4>
     * <pre>{@code
     * Element scope = dependency.child("scope").orElse(null);
     * String scopeValue = scope != null ? scope.textContentOr("compile") : "compile";
     * // Or more simply:
     * String scopeValue = dependency.child("scope")
     *     .map(e -> e.textContentOr("compile"))
     *     .orElse("compile");
     * }</pre>
     *
     * @param defaultValue the default value to return if text content is null or empty
     * @return the text content or default value
     * @since 0.3.0
     */
    public String textContentOr(String defaultValue) {
        String text = textContent();
        return (text != null && !text.isEmpty()) ? text : defaultValue;
    }

    /**
     * Sets the text content, replacing all existing text children.
     *
     * <p><strong>Note:</strong> This method replaces all text children and does not
     * preserve existing whitespace patterns. For whitespace-preserving updates,
     * use {@link #textPreservingWhitespace(String)} instead.</p>
     *
     * @param content the new text content
     * @return this element for method chaining
     * @see #textPreservingWhitespace(String)
     * @see #textContent()
     */
    public Element textContent(String content) {
        // Remove all existing text children
        children.removeIf(Text.class::isInstance);

        // Add new text content if not empty
        if (content != null && !content.isEmpty()) {
            Text textNode = new Text(content);
            addChild(textNode);
        }

        markModified();
        return this;
    }

    /**
     * Sets the text content while preserving existing whitespace patterns.
     *
     * <p>This method attempts to preserve the whitespace structure of the existing
     * text content when updating to new content. If the element has existing text
     * with leading/trailing whitespace, the same pattern will be applied to the
     * new content.</p>
     *
     * <h3>Examples:</h3>
     * <pre>{@code
     * // Original: <item>   old value   </item>
     * element.textPreservingWhitespace("new value");
     * // Result:   <item>   new value   </item>
     *
     * // Original: <item>old value</item>
     * element.textPreservingWhitespace("new value");
     * // Result:   <item>new value</item>
     * }</pre>
     *
     * @param content the new text content
     * @return this element for method chaining
     * @see #textContent(String)
     * @see #textContent()
     * @see #textContentTrimmed()
     */
    public Element textPreservingWhitespace(String content) {
        if (content == null) {
            content = "";
        }

        // Find existing text node to preserve its whitespace pattern
        Text existingText = getFirstTextChild();

        if (existingText != null) {
            // Use the Text node's whitespace-preserving method
            existingText.contentPreservingWhitespace(content);
        } else {
            // No existing text, just set normally
            textContent(content);
        }
        return this;
    }

    /**
     * Gets the text content with leading and trailing whitespace removed.
     *
     * <p>This is a convenience method that returns the trimmed text content
     * without modifying the original content. Useful for getting clean content
     * for processing while preserving the original formatting.</p>
     *
     * @return the text content with leading and trailing whitespace removed
     * @see #textContent()
     * @see #textPreservingWhitespace(String)
     */
    public String textContentTrimmed() {
        String content = textContent();
        return content != null ? content.trim() : "";
    }

    /**
     * Gets the text content with leading and trailing whitespace removed if non-empty
     * and non-null, otherwise returns the default value.
     *
     * <p>This is a convenience method that returns the trimmed text content
     * without modifying the original content. Useful for getting clean content
     * for processing while preserving the original formatting.</p>
     *
     * @return the text content with leading and trailing whitespace removed or default value
     * @see #textContentOr(String)
     * @since 0.3.1
     */
    public String textContentTrimmedOr(String defaultValue) {
        String content = textContent();
        return content == null || content.trim().isEmpty() ? defaultValue : content.trim();
    }

    /**
     * Gets the first Text child node, if any.
     *
     * @return the first Text child, or null if none exists
     */
    private Text getFirstTextChild() {
        for (Node child : children) {
            if (child instanceof Text) {
                return (Text) child;
            }
        }
        return null;
    }

    // Namespace-aware methods

    /**
     * Gets the local name part of this element (without namespace prefix).
     */
    public String localName() {
        String[] parts = NamespaceResolver.splitQualifiedName(name);
        return parts[1];
    }

    /**
     * Gets the namespace prefix of this element.
     * Returns null if the element has no prefix.
     */
    public String prefix() {
        String[] parts = NamespaceResolver.splitQualifiedName(name);
        return parts[0];
    }

    /**
     * Gets the qualified name of this element (prefix:localName or just localName).
     */
    public String qualifiedName() {
        return name;
    }

    /**
     * Gets the namespace URI of this element.
     * Returns null if the element is not in any namespace.
     */
    public String namespaceURI() {
        String prefix = prefix();
        return NamespaceResolver.resolveNamespaceURI(this, prefix);
    }

    /**
     * Checks if this element is in the specified namespace.
     */
    public boolean inNamespace(String namespaceURI) {
        String elementNamespaceURI = namespaceURI();
        return namespaceURI != null && namespaceURI.equals(elementNamespaceURI);
    }

    /**
     * Gets the namespace context for this element.
     * Includes all namespace declarations from this element and its ancestors.
     */
    public NamespaceContext namespaceContext() {
        return NamespaceResolver.buildNamespaceContext(this);
    }

    /**
     * Sets a namespace declaration attribute (xmlns or xmlns:prefix).
     *
     * @param prefix the namespace prefix, or null/empty for default namespace
     * @param namespaceURI the namespace URI
     * @return this element for method chaining
     */
    public Element namespaceDeclaration(String prefix, String namespaceURI) {
        if (prefix == null || prefix.isEmpty()) {
            attribute(XMLNS, namespaceURI);
        } else {
            attribute(XMLNS_PREFIX + prefix, namespaceURI);
        }
        return this;
    }

    /**
     * Gets a namespace declaration for the given prefix.
     * Returns null if no declaration is found on this element.
     */
    public String namespaceDeclaration(String prefix) {
        if (prefix == null || prefix.isEmpty()) {
            return attribute(XMLNS);
        } else {
            return attribute(XMLNS_PREFIX + prefix);
        }
    }

    /**
     * Removes a namespace declaration.
     */
    public void removeNamespaceDeclaration(String prefix) {
        if (prefix == null || prefix.isEmpty()) {
            removeAttribute(XMLNS);
        } else {
            removeAttribute(XMLNS_PREFIX + prefix);
        }
    }

    /**
     * Returns a stream of all descendant elements (depth-first traversal).
     */
    public Stream<Element> descendants() {
        return children.stream()
                .filter(Element.class::isInstance)
                .map(Element.class::cast)
                .flatMap(element -> Stream.concat(Stream.of(element), element.descendants()));
    }

    // Enhanced navigation methods with QName support

    /**
     * Finds the first child element with the given QName.
     *
     * @param qname the QName to match
     * @return an Optional containing the first matching child element, or empty if none found
     */
    public Optional<Element> childElement(QName qname) {
        if (qname == null) {
            return Optional.empty();
        }
        return children.stream()
                .filter(Element.class::isInstance)
                .map(Element.class::cast)
                .filter(element -> qname.matches(element.namespaceURI(), element.localName()))
                .findFirst();
    }

    /**
     * Finds the first child element with the given name.
     *
     * @param name the element name to match
     * @return an Optional containing the first matching child element, or empty if none found
     */
    public Optional<Element> childElement(String name) {
        return children.stream()
                .filter(Element.class::isInstance)
                .map(Element.class::cast)
                .filter(element -> name.equals(element.name()))
                .findFirst();
    }

    /**
     * Gets the text content of an optional child element with the given name.
     *
     * <p>This is a convenience method that combines child element lookup and text content extraction
     * with a default value, making it useful for reading optional configuration values. If the child
     * element exists but has no text content (empty element), the default value is returned.</p>
     *
     * <h4>Example:</h4>
     * <pre>{@code
     * Element dependency = ...;
     * // Get scope with default value "compile"
     * String scope = dependency.childTextOr("scope", "compile");
     *
     * // Get optional classifier (returns null if not present)
     * String classifier = dependency.childTextOr("classifier", null);
     * }</pre>
     *
     * @param childName the name of the child element
     * @param defaultValue the default value to return if child is not found or has no text content
     * @return the text content of the child or default value
     * @since 0.3.0
     */
    public String childTextOr(String childName, String defaultValue) {
        return childElement(childName).map(e -> e.textContentOr(defaultValue)).orElse(defaultValue);
    }

    /**
     * Gets the text content of a child element, or returns null if not found.
     *
     * <p>This is a convenience method that provides a simple way to get child
     * element text content with null fallback instead of handling Optional.</p>
     *
     * @param childName the child element name
     * @return the text content of the child element, or null if not found
     * @see #childElement(String)
     * @see #childTextOr(String, String)
     * @see #childTextTrimmed(String)
     */
    public String childText(String childName) {
        return childElement(childName).map(Element::textContent).orElse(null);
    }

    /**
     * Gets the trimmed text content of a child element, or returns null if not found.
     *
     * <p>This is a convenience method that provides a simple way to get trimmed child
     * element text content with null fallback instead of handling Optional.</p>
     *
     * @param childName the child element name
     * @return the trimmed text content of the child element, or null if not found
     * @see #childElement(String)
     * @see #childTextOr(String, String)
     * @see #childText(String)
     * @see #textContentTrimmed()
     */
    public String childTextTrimmed(String childName) {
        return childElement(childName).map(Element::textContentTrimmed).orElse(null);
    }

    /**
     * Gets the text content of a required child element with the given name.
     *
     * <p>This method is useful when a child element is mandatory and you want to fail fast
     * with a clear error message if it's missing.</p>
     *
     * <h4>Example:</h4>
     * <pre>{@code
     * Element dependency = ...;
     * // Get required groupId (throws if missing)
     * String groupId = dependency.childTextRequired("groupId");
     * }</pre>
     *
     * @param childName the name of the child element
     * @return the text content of the child
     * @throws DomTripException if the child element is not found
     * @since 0.3.0
     */
    public String childTextRequired(String childName) {
        return childElement(childName)
                .map(Element::textContent)
                .orElseThrow(() -> new DomTripException(
                        "Required child element '" + childName + "' not found in element '" + name + "'"));
    }

    /**
     * Finds all child elements with the given QName.
     *
     * @param qname the QName to match
     * @return a Stream of matching child elements
     */
    public Stream<Element> childElements(QName qname) {
        if (qname == null) {
            return Stream.empty();
        }
        return children.stream()
                .filter(Element.class::isInstance)
                .map(Element.class::cast)
                .filter(element -> qname.matches(element.namespaceURI(), element.localName()));
    }

    /**
     * Finds all child elements with the given name.
     *
     * @param name the element name to match
     * @return a Stream of matching child elements
     */
    public Stream<Element> childElements(String name) {
        return children.stream()
                .filter(Element.class::isInstance)
                .map(Element.class::cast)
                .filter(element -> name.equals(element.name()));
    }

    /**
     * Finds all child elements.
     *
     * @return a Stream of all child elements
     */
    public Stream<Element> childElements() {
        return children.stream().filter(Element.class::isInstance).map(Element.class::cast);
    }

    /**
     * Finds the first descendant element with the given QName.
     *
     * @param qname the QName to match
     * @return an Optional containing the first matching descendant element, or empty if none found
     */
    public Optional<Element> descendant(QName qname) {
        if (qname == null) {
            return Optional.empty();
        }
        return descendants()
                .filter(element -> qname.matches(element.namespaceURI(), element.localName()))
                .findFirst();
    }

    /**
     * Finds the first descendant element with the given name.
     *
     * @param name the element name to match
     * @return an Optional containing the first matching descendant element, or empty if none found
     */
    public Optional<Element> descendant(String name) {
        Objects.requireNonNull(name);
        return descendants().filter(element -> name.equals(element.name())).findFirst();
    }

    /**
     * Finds all descendant elements with the given QName.
     *
     * @param qname the QName to match
     * @return a Stream of matching descendant elements
     */
    public Stream<Element> descendants(QName qname) {
        if (qname == null) {
            return Stream.empty();
        }
        return descendants().filter(element -> qname.matches(element.namespaceURI(), element.localName()));
    }

    /**
     * Finds all descendant elements with the given name (convenience method).
     *
     * @param name the element name to match
     * @return a Stream of matching descendant elements
     */
    public Stream<Element> descendants(String name) {
        return descendants().filter(element -> name.equals(element.name()));
    }

    /**
     * Finds the first text child node.
     *
     * @return an Optional containing the first text child, or empty if none found
     */
    public Optional<Text> textChild() {
        return children.stream()
                .filter(Text.class::isInstance)
                .map(Text.class::cast)
                .findFirst();
    }

    /**
     * Creates a fluent query builder for finding elements.
     *
     * @return a new ElementQuery for fluent element searching
     */
    public ElementQuery query() {
        return new ElementQuery(this);
    }

    /**
     * Evaluates a mini-XPath expression against this element and returns all matching elements.
     *
     * <p>This is a convenience method that compiles and evaluates the expression in one step.
     * For repeated evaluation of the same expression, use {@link XPathExpression#compile(String)}
     * to compile once and reuse.</p>
     *
     * <h3>Examples:</h3>
     * <pre>{@code
     * List<Element> deps = root.select("dependencies/dependency");
     * List<Element> allDeps = root.select("//dependency");
     * List<Element> testDeps = root.select("//dependency[@scope='test']");
     * }</pre>
     *
     * @param expression the mini-XPath expression
     * @return a list of matching elements, never null
     * @throws DomTripException if the expression is invalid
     * @see XPathExpression
     * @since 1.3.0
     */
    public List<Element> select(String expression) {
        return XPathExpression.compile(expression).select(this);
    }

    /**
     * Evaluates a mini-XPath expression against this element and returns the first match.
     *
     * <p>This is a convenience method that compiles and evaluates the expression in one step.
     * For repeated evaluation of the same expression, use {@link XPathExpression#compile(String)}
     * to compile once and reuse.</p>
     *
     * <h3>Examples:</h3>
     * <pre>{@code
     * Optional<Element> dep = root.selectFirst("//dependency[groupId='junit']");
     * Optional<Element> ver = root.selectFirst("project/version");
     * }</pre>
     *
     * @param expression the mini-XPath expression
     * @return an Optional containing the first matching element, or empty if none found
     * @throws DomTripException if the expression is invalid
     * @see XPathExpression
     * @since 1.3.0
     */
    public Optional<Element> selectFirst(String expression) {
        return XPathExpression.compile(expression).selectFirst(this);
    }

    /**
     * Accepts a visitor for depth-first tree traversal.
     *
     * <p>Calls {@link DomTripVisitor#enterElement(Element)} before visiting children
     * and {@link DomTripVisitor#exitElement(Element)} after. If {@code enterElement}
     * returns {@link DomTripVisitor.Action#SKIP}, children are not visited but
     * {@code exitElement} is still called. If any visit method returns
     * {@link DomTripVisitor.Action#STOP}, traversal aborts immediately.</p>
     *
     * @param visitor the visitor to accept
     * @return the action indicating how traversal should proceed
     * @throws IllegalArgumentException if visitor is null
     * @see DomTripVisitor
     * @since 1.3.0
     */
    @Override
    public DomTripVisitor.Action accept(DomTripVisitor visitor) {
        if (visitor == null) {
            throw new IllegalArgumentException("Visitor cannot be null");
        }
        DomTripVisitor.Action action = visitor.enterElement(this);
        if (action == DomTripVisitor.Action.STOP) {
            return DomTripVisitor.Action.STOP;
        }
        if (action != DomTripVisitor.Action.SKIP) {
            // Use snapshot to tolerate structural mutations during traversal
            for (Node child : new java.util.ArrayList<>(children)) {
                if (child.accept(visitor) == DomTripVisitor.Action.STOP) {
                    return DomTripVisitor.Action.STOP;
                }
            }
        }
        visitor.exitElement(this);
        return DomTripVisitor.Action.CONTINUE;
    }

    /**
     * Creates a lambda-friendly tree walker starting from this element.
     *
     * <p>This provides a fluent API alternative to implementing
     * {@link DomTripVisitor} directly:</p>
     * <pre>{@code
     * element.walk()
     *     .onEnter(e -> {
     *         if ("secret".equals(e.localName())) {
     *             e.textContent("***");
     *             return Action.SKIP;
     *         }
     *         return Action.CONTINUE;
     *     })
     *     .onExit(e -> { /* cleanup *&#47; })
     *     .onText(t -> { /* process text *&#47; })
     *     .execute();
     * }</pre>
     *
     * @return a new TreeWalker for fluent traversal configuration
     * @see TreeWalker
     * @since 1.3.0
     */
    public TreeWalker walk() {
        return new TreeWalker(this);
    }

    // Path-based navigation methods

    /**
     * Finds an element by following a path of element names from this element.
     *
     * <p>Example: {@code element.path("dependencies", "dependency")} will find
     * the first dependency element under this element's dependencies child.</p>
     *
     * @param path the path of element names to follow
     * @return an Optional containing the element at the end of the path, or empty if not found
     */
    public Optional<Element> path(String... path) {
        if (path == null || path.length == 0) {
            return Optional.of(this);
        }

        return Arrays.stream(path)
                .reduce(
                        Optional.of(this),
                        (current, elementName) -> current.flatMap(el -> el.childElement(elementName)),
                        (a, b) -> b);
    }

    /**
     * Finds an element by following a path of QNames from this element.
     *
     * @param path the path of QNames to follow
     * @return an Optional containing the element at the end of the path, or empty if not found
     */
    public Optional<Element> path(QName... path) {
        if (path == null || path.length == 0) {
            return Optional.of(this);
        }

        return Arrays.stream(path)
                .reduce(
                        Optional.of(this),
                        (current, qname) -> current.flatMap(el -> el.childElement(qname)),
                        (a, b) -> b);
    }

    /**
     * Checks if a namespace is already declared in the element hierarchy.
     *
     * @param element the element to check from
     * @param qname the QName to check for namespace declaration
     * @return true if the namespace is already declared
     */
    private static boolean isNamespaceDeclared(Element element, QName qname) {
        if (!qname.hasNamespace()) {
            return true; // No namespace needed
        }

        Element current = element;
        while (current != null) {
            // Check if this element declares the namespace
            String declaredURI = NamespaceResolver.resolveNamespaceURI(current, qname.prefix());
            if (qname.namespaceURI().equals(declaredURI)) {
                return true;
            }

            // Move up to parent element
            Node parent = current.parent();
            current = (parent instanceof Element) ? (Element) parent : null;
        }

        return false; // Namespace not found in hierarchy
    }

    /**
     * {@inheritDoc}
     * @since 1.1.0
     */
    @Override
    public Element copy() {
        return new Element(this);
    }

    /**
     * Creates a deep copy of this element.
     *
     * @return a new element that is a copy of this element
     * @deprecated Use {@link #copy()} instead.
     */
    @Deprecated
    @SuppressWarnings({"java:S2975", "java:S1133", "java:S1182"})
    @Override
    public Element clone() {
        return copy();
    }

    @Override
    public String toString() {
        return "Element{name='" + name + "', attributes=" + attributes.size() + ", children=" + children.size() + "}";
    }

    // Factory methods for common element patterns

    /**
     * Creates a simple element.
     *
     * @param name the element name
     * @return a new Element
     */
    public static Element of(String name) throws DomTripException {
        return new Element(name);
    }

    /**
     * Creates an element from a QName.
     *
     * @param qname the QName for the element
     * @return a new Element with namespace configuration
     * @throws DomTripException if qname is null
     */
    public static Element of(QName qname) throws DomTripException {
        if (qname == null) {
            throw new DomTripException("QName cannot be null");
        }

        Element element = new Element(qname.qualifiedName());

        // Add namespace declaration if needed
        if (qname.hasNamespace()) {
            if (qname.hasPrefix()) {
                element.namespaceDeclaration(qname.prefix(), qname.namespaceURI());
            } else {
                element.namespaceDeclaration(null, qname.namespaceURI());
            }
        }

        return element;
    }

    /**
     * Creates a simple text element.
     *
     * <p>Creates an element with the specified name and text content.
     * This is a convenience method for creating elements that contain only text.</p>
     *
     * @param name the element name
     * @param content the text content to add
     * @return a new Element with text content
     */
    public static Element text(String name, String content) throws DomTripException {
        Element element = new Element(name);
        if (content != null && !content.isEmpty()) {
            element.addChild(new Text(content));
        }
        return element;
    }

    /**
     * Creates a self-closing element.
     *
     * <p>Creates an element that will be serialized as a self-closing tag
     * (e.g., {@code <br/>} instead of {@code <br></br>}).</p>
     *
     * @param name the element name
     * @return a new self-closing Element
     */
    public static Element selfClosing(String name) throws DomTripException {
        return new Element(name).selfClosing(true);
    }

    /**
     * Creates an element with attributes.
     *
     * <p>Creates an element with the specified name and adds all the
     * provided attributes.</p>
     *
     * @param name the element name
     * @param attributes a map of attribute names to values
     * @return a new Element with attributes
     */
    public static Element withAttributes(String name, Map<String, String> attributes) throws DomTripException {
        Element element = new Element(name);
        if (attributes != null) {
            for (Map.Entry<String, String> entry : attributes.entrySet()) {
                element.attribute(entry.getKey(), entry.getValue());
            }
        }
        return element;
    }

    /**
     * Creates an element with text content and attributes.
     *
     * <p>Creates an element with the specified name, adds all the provided
     * attributes, and includes the specified text content.</p>
     *
     * @param name the element name
     * @param content the text content to add
     * @param attributes a map of attribute names to values
     * @return a new Element with text content and attributes
     */
    public static Element withTextAndAttributes(String name, String content, Map<String, String> attributes)
            throws DomTripException {
        Element element = withAttributes(name, attributes);
        if (content != null && !content.isEmpty()) {
            element.addChild(new Text(content));
        }
        return element;
    }

    /**
     * Creates a CDATA element.
     *
     * <p>Creates an element with the specified name and adds a CDATA section
     * containing the provided content. CDATA sections preserve content exactly
     * without XML entity escaping.</p>
     *
     * @param name the element name
     * @param content the CDATA content to add
     * @return a new Element with CDATA content
     */
    public static Element cdata(String name, String content) throws DomTripException {
        Element element = new Element(name);
        if (content != null) {
            element.addChild(new Text(content, true));
        }
        return element;
    }

    // Namespace factory methods

    /**
     * Creates an element from a QName with text content.
     *
     * @param qname the QName for the element
     * @param content the text content to add
     * @return a new Element with namespace configuration and text content
     * @throws DomTripException if qname is null
     */
    public static Element text(QName qname, String content) throws DomTripException {
        Element element = of(qname);
        if (content != null && !content.isEmpty()) {
            element.addChild(new Text(content));
        }
        return element;
    }

    // Factory methods for other node types (for convenience)

    /**
     * Creates a comment node.
     *
     * <p>Creates a Comment node with the specified content. This is a convenience
     * method equivalent to {@link Comment#of(String)}.</p>
     *
     * @param content the comment content
     * @return a new Comment node
     * @see Comment#of(String)
     */
    public static Comment comment(String content) {
        return Comment.of(content);
    }

    /**
     * Creates a processing instruction.
     *
     * <p>Creates a ProcessingInstruction node with the specified target and data.
     * This is a convenience method equivalent to {@link ProcessingInstruction#of(String, String)}.</p>
     *
     * @param target the processing instruction target
     * @param data the processing instruction data
     * @return a new ProcessingInstruction node
     * @see ProcessingInstruction#of(String, String)
     */
    public static ProcessingInstruction processingInstruction(String target, String data) {
        return ProcessingInstruction.of(target, data);
    }
}
