/*
 * Copyright (c) 2023-2026 Maveniverse Org.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v2.0
 * which accompanies this distribution, and is available at
 * https://www.eclipse.org/legal/epl-v20.html
 */
package eu.maveniverse.domtrip;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * A lossless XML parser that preserves all formatting information including
 * whitespace, comments, attribute quote styles, and entity encoding.
 *
 * <p>The Parser class is responsible for converting XML text into DomTrip's
 * internal node tree representation. Unlike traditional XML parsers that
 * normalize content and lose formatting information, this parser meticulously
 * preserves every aspect of the original XML formatting to enable perfect
 * round-trip processing.</p>
 *
 * <h3>Parsing Features:</h3>
 * <ul>
 *   <li><strong>Whitespace Preservation</strong> - Maintains all whitespace exactly as written</li>
 *   <li><strong>Automatic Whitespace Normalization</strong> - Never creates Text nodes with only whitespace</li>
 *   <li><strong>Attribute Formatting</strong> - Preserves quote styles, order, and spacing</li>
 *   <li><strong>Comment Preservation</strong> - Keeps all XML comments in their original positions</li>
 *   <li><strong>Entity Preservation</strong> - Maintains entity references in their original form</li>
 *   <li><strong>Processing Instructions</strong> - Preserves PIs including XML declarations</li>
 *   <li><strong>CDATA Sections</strong> - Maintains CDATA boundaries and content</li>
 * </ul>
 *
 * <h3>Parsing Process:</h3>
 * <p>The parser uses a stack-based approach to build the XML tree:</p>
 * <ol>
 *   <li>Tokenizes the input XML character by character</li>
 *   <li>Identifies XML constructs (elements, comments, text, etc.)</li>
 *   <li>Preserves original formatting information for each construct</li>
 *   <li>Automatically normalizes whitespace-only content to element properties</li>
 *   <li>Builds a complete node tree with parent-child relationships</li>
 *   <li>Maintains modification flags for selective formatting preservation</li>
 * </ol>
 *
 * <h3>Whitespace Normalization:</h3>
 * <p>The parser automatically normalizes whitespace during parsing to ensure a clean tree structure:</p>
 * <ul>
 *   <li><strong>No Whitespace-Only Text Nodes</strong> - Whitespace between elements is captured in element properties</li>
 *   <li><strong>Mixed Content Preservation</strong> - Text nodes with actual content preserve their whitespace</li>
 *   <li><strong>Lossless Round-Trip</strong> - All whitespace is preserved for perfect XML reconstruction</li>
 *   <li><strong>Element Properties</strong> - Whitespace stored in precedingWhitespace, innerPrecedingWhitespace, etc.</li>
 * </ul>
 *
 * <h3>Error Handling:</h3>
 * <p>The parser provides detailed error information for malformed XML:</p>
 * <ul>
 *   <li>Precise error positions within the source text</li>
 *   <li>Descriptive error messages for common XML problems</li>
 *   <li>Context information to help locate and fix issues</li>
 * </ul>
 *
 * <h3>Usage:</h3>
 * <pre>{@code
 * Parser parser = new Parser();
 * try {
 *     // Parse from String
 *     Document document = parser.parse(xmlString);
 *
 *     // Parse from InputStream with encoding detection
 *     Document document2 = parser.parse(inputStream);
 *
 *     // Parse from InputStream with fallback encoding
 *     Document document3 = parser.parse(inputStream, "UTF-8");
 *
 *     // Use the parsed document
 * } catch (DomTripException e) {
 *     // Handle parsing errors
 *     System.err.println("Parse error at position " + e.position() + ": " + e.getMessage());
 * }
 * }</pre>
 *
 * @implNote This class is not thread-safe. It uses instance fields to track parse state.
 * A single instance may be reused for sequential parses but must not be shared across threads.
 *
 * @see Document
 * @see Element
 * @see DomTripException
 * @see Serializer
 */
public class Parser {

    private String xml;
    private int position;
    private int length;

    /** Prefix for XML declarations. */
    private static final String XML_DECL_PREFIX = "<?xml";

    // Pattern for parsing XML declaration attributes
    private static final Pattern XML_DECLARATION_PATTERN = Pattern.compile(
            "\\s*<\\?xml\\s+version\\s*=\\s*[\"']([^\"']+)[\"'](?:\\s+encoding\\s*=\\s*[\"']([^\"']+)[\"'])?(?:\\s+standalone\\s*=\\s*[\"']([^\"']+)[\"'])?\\s*\\?>");

    /**
     * Creates a new Parser instance with default settings.
     *
     * <p>No initialization is needed here because the parser state (xml, position, length)
     * is initialized at the start of each {@link #parse(String)} call.</p>
     */
    public Parser() {
        // Parser state is initialized in parse() method
    }

    /**
     * Parses XML from an InputStream with automatic encoding detection.
     *
     * <p>This method automatically detects the character encoding by:</p>
     * <ol>
     *   <li>Checking for a Byte Order Mark (BOM)</li>
     *   <li>Reading the XML declaration to extract the encoding attribute</li>
     *   <li>Falling back to UTF-8 if no encoding is specified</li>
     * </ol>
     *
     * <p>The resulting Document will have its encoding property set to the detected
     * or declared encoding.</p>
     *
     * @param inputStream the InputStream containing XML data
     * @return a Document containing the parsed XML with preserved formatting
     * @throws DomTripException if the XML is malformed, cannot be parsed, or I/O errors occur
     */
    public Document parse(InputStream inputStream) throws DomTripException {
        return parse(inputStream, StandardCharsets.UTF_8);
    }

    /**
     * Parses XML from an InputStream with encoding detection and fallback.
     *
     * <p>This method attempts to detect the character encoding by:</p>
     * <ol>
     *   <li>Checking for a Byte Order Mark (BOM)</li>
     *   <li>Reading the XML declaration to extract the encoding attribute</li>
     *   <li>Using the provided default encoding if detection fails</li>
     * </ol>
     *
     * <p>The resulting Document will have its encoding property set to the detected,
     * declared, or default encoding.</p>
     *
     * @param inputStream the InputStream containing XML data
     * @param defaultEncoding the encoding name to use if detection fails
     * @return a Document containing the parsed XML with preserved formatting
     * @throws DomTripException if the XML is malformed, cannot be parsed, or I/O errors occur
     */
    public Document parse(InputStream inputStream, String defaultEncoding) throws DomTripException {
        if (defaultEncoding == null || defaultEncoding.trim().isEmpty()) {
            return parse(inputStream, StandardCharsets.UTF_8);
        }
        try {
            Charset charset = Charset.forName(defaultEncoding);
            return parse(inputStream, charset);
        } catch (Exception e) {
            throw new DomTripException("Invalid encoding name: " + defaultEncoding, e);
        }
    }

    /**
     * Parses XML from an InputStream with encoding detection and fallback.
     *
     * <p>This method attempts to detect the character encoding by:</p>
     * <ol>
     *   <li>Checking for a Byte Order Mark (BOM)</li>
     *   <li>Reading the XML declaration to extract the encoding attribute</li>
     *   <li>Using the provided default charset if detection fails</li>
     * </ol>
     *
     * <p>The resulting Document will have its encoding property set to the detected,
     * declared, or default encoding.</p>
     *
     * @param inputStream the InputStream containing XML data
     * @param defaultCharset the charset to use if detection fails
     * @return a Document containing the parsed XML with preserved formatting
     * @throws DomTripException if the XML is malformed, cannot be parsed, or I/O errors occur
     */
    public Document parse(InputStream inputStream, Charset defaultCharset) throws DomTripException {
        if (inputStream == null) {
            throw new DomTripException("InputStream cannot be null");
        }
        if (defaultCharset == null) {
            defaultCharset = StandardCharsets.UTF_8;
        }

        try {
            // Read the entire stream into a byte array for encoding detection
            byte[] xmlBytes = readAllBytes(inputStream);
            if (xmlBytes.length == 0) {
                throw new DomTripException("InputStream is empty");
            }

            // Detect encoding
            Charset detectedCharset = detectEncoding(xmlBytes, defaultCharset);

            // Convert bytes to string using detected encoding
            String xmlString = new String(xmlBytes, detectedCharset);

            // Strip BOM character (U+FEFF) if present at the beginning of the string.
            // The BOM is encoding-level metadata that has already been used for charset detection.
            // It should not appear in the parsed XML content.
            boolean hasBom = !xmlString.isEmpty() && xmlString.charAt(0) == '\uFEFF';
            if (hasBom) {
                xmlString = xmlString.substring(1);
            }

            // Parse the XML string
            Document document = parse(xmlString);
            document.bom(hasBom);

            // Parse XML declaration attributes and update document properties
            updateDocumentFromXmlDeclaration(document, xmlString);

            // Update document encoding based on byte-level detection.
            // This must happen AFTER updateDocumentFromXmlDeclaration, because the detected
            // encoding (from BOM or byte patterns) takes precedence over the declared encoding
            // in the XML declaration (which may be inaccurate).
            document.encodingInternal(detectedCharset.name());

            return document;

        } catch (IOException e) {
            throw new DomTripException("Failed to read from InputStream: " + e.getMessage(), e);
        } catch (Exception e) {
            if (e instanceof DomTripException) {
                throw e;
            }
            throw new DomTripException("Failed to parse XML from InputStream: " + e.getMessage(), e);
        }
    }

    /**
     * Parses an XML string into a lossless XML document tree.
     *
     * <p>This method performs complete XML parsing while preserving all formatting
     * information including whitespace, comments, attribute styles, and entity encoding.
     * The resulting Document can be used for lossless round-trip editing.</p>
     *
     * @param xml the XML string to parse
     * @return a Document containing the parsed XML with preserved formatting
     * @throws DomTripException if the XML is malformed or cannot be parsed
     */
    public Document parse(String xml) throws DomTripException {
        if (xml == null || xml.trim().isEmpty()) {
            throw new DomTripException("XML content cannot be null or empty");
        }

        this.xml = xml;
        this.position = 0;
        this.length = xml.length();

        Document document = new Document();
        Deque<Node> nodeStack = new ArrayDeque<>();
        nodeStack.push(document);

        StringBuilder precedingWhitespace = new StringBuilder();
        StringBuilder pendingWhitespace = new StringBuilder();

        while (position < length) {
            if (xml.charAt(position) == '<') {
                flushPrecedingText(precedingWhitespace, pendingWhitespace, nodeStack);
                parseTagStart(document, nodeStack, pendingWhitespace);
            } else {
                // Collect text content and whitespace in bulk using substring
                int textStart = position;
                position++;
                while (position < length && xml.charAt(position) != '<') {
                    position++;
                }
                precedingWhitespace.append(xml, textStart, position);
            }
        }

        // Handle any remaining whitespace/text
        flushRemainingContent(document, precedingWhitespace, pendingWhitespace);

        checkUnclosedElements(nodeStack);
        setDocumentRoot(document);

        return document;
    }

    /**
     * Attaches accumulated raw text that appears before the next '<' to the parse tree or to pending whitespace.
     *
     * If the accumulated text is whitespace only, it is appended to {@code pendingWhitespace}.
     * Otherwise a Text node is created (preserving both decoded and raw text) and added as a child of the current container node from {@code nodeStack};
     * any {@code pendingWhitespace} is applied to that Text node before attachment.
     *
     * @param precedingWhitespace buffer holding raw characters read up to the next '<'
     * @param pendingWhitespace buffer of whitespace that should be applied to the next node if the preceding content is whitespace-only or when attaching a new node
     * @param nodeStack stack of nodes with the current container on top (document is at the bottom)
     */
    private void flushPrecedingText(
            StringBuilder precedingWhitespace, StringBuilder pendingWhitespace, Deque<Node> nodeStack) {
        if (precedingWhitespace.length() == 0) {
            return;
        }

        // Fast path: check if raw text is whitespace-only before unescaping.
        // Between elements, whitespace never contains entities, so this avoids
        // both the unescape and the whitespace-check on decoded text.
        if (isWhitespaceOnlyBuf(precedingWhitespace)) {
            pendingWhitespace.append(precedingWhitespace);
            precedingWhitespace.setLength(0);
            return;
        }

        String rawText = precedingWhitespace.toString();
        String decodedText = Text.unescapeTextContent(rawText);

        Text textNode = new Text(decodedText, rawText);
        applyPendingWhitespace(textNode, pendingWhitespace);
        ContainerNode current = (ContainerNode) nodeStack.peek();
        current.addChildInternal(textNode);
        precedingWhitespace.setLength(0);
    }

    /**
     * Determines whether the provided StringBuilder contains only XML whitespace characters
     * (space, tab, carriage return, line feed) as defined by the XML 1.0 specification.
     *
     * @param sb the StringBuilder to inspect
     * @return {@code true} if every character in {@code sb} is XML whitespace, {@code false} otherwise
     */
    private static boolean isWhitespaceOnlyBuf(StringBuilder sb) {
        for (int i = 0, len = sb.length(); i < len; i++) {
            if (!isXmlWhitespace(sb.charAt(i))) {
                return false;
            }
        }
        return true;
    }

    /**
     * Checks whether a character is XML whitespace per the XML 1.0 specification:
     * S ::= (#x20 | #x9 | #xD | #xA)+
     */
    private static boolean isXmlWhitespace(char c) {
        return c == ' ' || c == '\t' || c == '\r' || c == '\n';
    }

    /**
     * Parses the content starting at a '<' character and dispatches to the appropriate handler.
     */
    private void parseTagStart(Document document, Deque<Node> nodeStack, StringBuilder pendingWhitespace)
            throws DomTripException {
        if (position + 1 >= length) {
            throw new DomTripException("Unexpected end of XML: truncated '<' character", position, xml);
        }

        char nextChar = xml.charAt(position + 1);

        if (nextChar == '!') {
            parseDeclarationOrSpecial(document, nodeStack, pendingWhitespace);
        } else if (nextChar == '?') {
            parseProcessingInstructionTag(document, nodeStack, pendingWhitespace);
        } else if (nextChar == '/') {
            parseClosingTagWithWhitespace(nodeStack, pendingWhitespace);
        } else {
            parseOpeningTagAndPush(nodeStack, pendingWhitespace);
        }
    }

    /**
     * Parses a declaration or special XML construct beginning with "<!" (comment, CDATA section,
     * DOCTYPE, or other declaration) and attaches the resulting node or metadata to the document tree.
     *
     * @param document the Document being built and updated (may receive a DOCTYPE or xml-declaration data)
     * @param nodeStack the current node stack; parsed comment/CDATA nodes are added to the container at the stack top
     * @param pendingWhitespace buffer of whitespace that should be applied as preceding whitespace to the
     *                         parsed node or, for DOCTYPE, recorded as doctype preceding whitespace;
     *                         this buffer may be consumed/cleared by the method
     * @throws DomTripException if the declaration/special construct is truncated or otherwise malformed
     */
    private void parseDeclarationOrSpecial(Document document, Deque<Node> nodeStack, StringBuilder pendingWhitespace)
            throws DomTripException {
        // position is at '<', position+1 is '!'
        if (position + 3 < length && xml.charAt(position + 2) == '-' && xml.charAt(position + 3) == '-') {
            Comment comment = parseComment();
            applyPendingWhitespace(comment, pendingWhitespace);
            ((ContainerNode) nodeStack.peek()).addChildInternal(comment);
        } else if (position + 8 < length && xml.charAt(position + 2) == '[' && xml.startsWith("<![CDATA[", position)) {
            Text cdata = parseCData();
            applyPendingWhitespace(cdata, pendingWhitespace);
            ((ContainerNode) nodeStack.peek()).addChildInternal(cdata);
        } else if (position + 9 < length && xml.charAt(position + 2) == 'D' && xml.startsWith("<!DOCTYPE", position)) {
            String doctype = parseDoctype();
            document.doctypeInternal(doctype);
            if (pendingWhitespace.length() > 0) {
                document.doctypePrecedingWhitespace(pendingWhitespace.toString());
                pendingWhitespace.setLength(0);
            }
        } else {
            skipDeclaration();
        }
    }

    /**
     * Parses a processing instruction and either records it as the document's XML declaration
     * (when it contains a `version` attribute) or attaches it as a ProcessingInstruction node
     * to the current container.
     *
     * @param document the Document being constructed; used to store an XML declaration when present
     * @param nodeStack the stack of open nodes whose peek is the current container for added nodes
     * @param pendingWhitespace accumulated whitespace to attach to the created ProcessingInstruction node
     * @throws DomTripException if the processing instruction is unterminated or otherwise malformed
     */
    private void parseProcessingInstructionTag(
            Document document, Deque<Node> nodeStack, StringBuilder pendingWhitespace) throws DomTripException {
        String pi = parseProcessingInstruction();
        if (pi.startsWith(XML_DECL_PREFIX + " ") && pi.contains("version=")) {
            document.xmlDeclarationInternal(pi);
            updateDocumentFromXmlDeclaration(document, pi);
        } else {
            ProcessingInstruction piNode = new ProcessingInstruction(pi);
            applyPendingWhitespace(piNode, pendingWhitespace);
            ((ContainerNode) nodeStack.peek()).addChildInternal(piNode);
        }
    }

    /**
     * Handles a closing tag, applying pending whitespace as inner whitespace to the current element.
     */
    private void parseClosingTagWithWhitespace(Deque<Node> nodeStack, StringBuilder pendingWhitespace) {
        if (!nodeStack.isEmpty() && nodeStack.peek() instanceof Element) {
            Element currentElement = (Element) nodeStack.peek();
            if (pendingWhitespace.length() > 0) {
                currentElement.innerPrecedingWhitespaceInternal(pendingWhitespace.toString());
                pendingWhitespace.setLength(0);
            }
        }
        parseClosingTag(nodeStack);
    }

    /**
     * Parses an opening tag, applies pending whitespace, and pushes onto the stack if non-self-closing.
     */
    private void parseOpeningTagAndPush(Deque<Node> nodeStack, StringBuilder pendingWhitespace)
            throws DomTripException {
        Element element = parseOpeningTag();
        applyPendingWhitespace(element, pendingWhitespace);
        ((ContainerNode) nodeStack.peek()).addChildInternal(element);
        if (!element.selfClosing()) {
            nodeStack.push(element);
        }
    }

    /**
     * Applies any accumulated pending whitespace as preceding whitespace on a node.
     */
    private void applyPendingWhitespace(Node node, StringBuilder pendingWhitespace) {
        if (pendingWhitespace.length() > 0) {
            node.precedingWhitespaceInternal(pendingWhitespace.toString());
            pendingWhitespace.setLength(0);
        }
    }

    /**
     * Flushes any remaining text/whitespace at the end of parsing into the document.
     */
    private void flushRemainingContent(
            Document document, StringBuilder precedingWhitespace, StringBuilder pendingWhitespace) {
        if (precedingWhitespace.length() > 0) {
            String rawText = precedingWhitespace.toString();
            String decodedText = Text.unescapeTextContent(rawText);

            if (isWhitespaceOnly(decodedText)) {
                pendingWhitespace.append(decodedText);
            } else {
                Text textNode = new Text(decodedText, rawText);
                if (pendingWhitespace.length() > 0) {
                    textNode.precedingWhitespaceInternal(pendingWhitespace.toString());
                    pendingWhitespace.setLength(0);
                }
                document.addChildInternal(textNode);
            }
        }

        if (pendingWhitespace.length() > 0) {
            Text trailingWhitespace = new Text(pendingWhitespace.toString());
            document.addChildInternal(trailingWhitespace);
        }
    }

    private void checkUnclosedElements(Deque<Node> nodeStack) {
        if (nodeStack.size() > 1) {
            Node unclosed = nodeStack.peek();
            if (unclosed instanceof Element) {
                throw new DomTripException("Unclosed element '<" + ((Element) unclosed).name() + ">'");
            }
        }
    }

    private void setDocumentRoot(Document document) {
        for (Node child : document.children) {
            if (child instanceof Element) {
                document.rootInternal((Element) child);
                break;
            }
        }
    }

    /**
     * Parses an XML comment at the current parse position and returns a Comment node.
     *
     * Assumes the parser is positioned at the start of a "<!--" sequence; consumes the full comment
     * including the opening "<!--" and the closing "-->" and advances the parser position past the
     * closing delimiter.
     *
     * @return the Comment whose content is the text between "<!--" and "-->"
     * @throws DomTripException if the comment is not closed before the end of input
     */
    private Comment parseComment() throws DomTripException {
        position += 4; // Skip "<!--"
        int contentStart = position;

        while (position + 2 < length) {
            if (xml.charAt(position) == '-' && xml.charAt(position + 1) == '-' && xml.charAt(position + 2) == '>') {
                String content = xml.substring(contentStart, position);
                position += 3;
                return new Comment(content);
            }
            position++;
        }

        throw new DomTripException("Unclosed comment", position, xml);
    }

    /**
     * Parses a CDATA section and returns it as a Text node marked as CDATA.
     *
     * @return a Text node whose content is the raw CDATA section and that is marked as CDATA
     * @throws DomTripException if the CDATA section is not closed before the end of input
     */
    private Text parseCData() throws DomTripException {
        position += 9; // Skip "<![CDATA["
        int contentStart = position;

        while (position + 2 < length) {
            if (xml.charAt(position) == ']' && xml.charAt(position + 1) == ']' && xml.charAt(position + 2) == '>') {
                String content = xml.substring(contentStart, position);
                position += 3;
                return new Text(content, true);
            }
            position++;
        }

        throw new DomTripException("Unclosed CDATA section", position, xml);
    }

    /**
     * Extracts a processing instruction starting at the current parse position and returns it including the surrounding "<?" and "?>" delimiters.
     *
     * @return the complete processing instruction substring (including leading "<?" and trailing "?>")
     * @throws DomTripException if the processing instruction is not closed before the end of the input
     */
    private String parseProcessingInstruction() throws DomTripException {
        int start = position;
        position += 2; // Skip "<?"

        while (position + 1 < length) {
            if (xml.charAt(position) == '?' && xml.charAt(position + 1) == '>') {
                position += 2;
                return xml.substring(start, position);
            }
            position++;
        }

        throw new DomTripException("Unclosed processing instruction", position, xml);
    }

    /**
     * Parses a DOCTYPE declaration beginning at the current parser position and returns the full declaration text.
     *
     * Advances the parser position to just after the closing '>' of the declaration.
     *
     * @return the DOCTYPE declaration substring including the leading "<!DOCTYPE" and the trailing ">"
     * @throws DomTripException if the DOCTYPE declaration is not closed before the end of input
     */
    private String parseDoctype() throws DomTripException {
        int start = position;
        position += 9; // Skip "<!DOCTYPE"

        int bracketCount = 0;
        boolean inQuotes = false;
        char quoteChar = 0;

        while (position < length) {
            char ch = xml.charAt(position);

            if (!inQuotes) {
                if (ch == '"' || ch == '\'') {
                    inQuotes = true;
                    quoteChar = ch;
                } else if (ch == '[') {
                    bracketCount++;
                } else if (ch == ']') {
                    bracketCount--;
                } else if (ch == '>' && bracketCount == 0) {
                    position++; // Include the closing '>'
                    return xml.substring(start, position);
                }
            } else {
                if (ch == quoteChar) {
                    inQuotes = false;
                }
            }
            position++;
        }

        throw new DomTripException("Unclosed DOCTYPE declaration", position, xml);
    }

    /**
     * Advances the parser position past the next `>` character that terminates a declaration.
     *
     * Stops at and consumes the first `>` found after the current position. If no `>` is found
     * before the end of the input, a `DomTripException` is thrown.
     *
     * @throws DomTripException if the declaration is not terminated before the end of the input
     */
    private void skipDeclaration() throws DomTripException {
        while (position < length && xml.charAt(position) != '>') {
            position++;
        }
        if (position < length) {
            position++; // Skip '>'
        } else {
            throw new DomTripException("Unclosed declaration", position, xml);
        }
    }

    /**
     * Parses an opening element tag at the current parser position.
     *
     * The resulting Element preserves the element name, parsed attributes, the self-closing flag,
     * and the original opening-tag text/whitespace for formatting fidelity.
     *
     * @return the parsed Element for the opening tag
     * @throws DomTripException if the element name is empty or the opening tag is not properly closed
     */
    private Element parseOpeningTag() throws DomTripException {
        int start = position;
        position++; // Skip '<'

        // Parse element name using substring
        int nameStart = position;
        while (position < length
                && !isXmlWhitespace(xml.charAt(position))
                && xml.charAt(position) != '>'
                && xml.charAt(position) != '/') {
            position++;
        }

        if (position == nameStart) {
            throw new DomTripException("Empty element name", position, xml);
        }

        String elementName = xml.substring(nameStart, position);
        Element element = new Element(elementName);

        parseAttributes(element);
        parseSelfClosingAndEnd(element, elementName);

        // Store original tag content as source-backed slice (avoids substring allocation)
        element.originalOpenTagInternal(xml, start, position);
        return element;
    }

    /**
     * Parses all attributes and whitespace within an opening tag.
     * Tracks whitespace positions to avoid StringBuilder allocation per attribute.
     */
    private void parseAttributes(Element element) throws DomTripException {
        int wsStart = position;
        while (position < length
                && xml.charAt(position) != '>'
                && !(xml.charAt(position) == '/' && position + 1 < length && xml.charAt(position + 1) == '>')) {

            if (isXmlWhitespace(xml.charAt(position))) {
                position++;
            } else {
                String attrWs = wsStart < position ? xml.substring(wsStart, position) : "";
                parseAttribute(element, attrWs);
                wsStart = position;
            }
        }

        if (wsStart < position) {
            element.openTagWhitespaceInternal(xml.substring(wsStart, position));
        }
    }

    /**
     * Handles the self-closing flag and closing '>' of an opening tag.
     */
    private void parseSelfClosingAndEnd(Element element, String elementName) throws DomTripException {
        if (position < length && xml.charAt(position) == '/') {
            element.selfClosingInternal(true);
            position++;
        }

        if (position < length && xml.charAt(position) == '>') {
            position++;
        } else {
            throw new DomTripException("Unclosed opening tag '" + elementName + "'", position, xml);
        }
    }

    /**
     * Parse one attribute from the current parser position and add it to the given element.
     *
     * @param element the Element that will receive the parsed attribute
     * @param precedingWhitespace the exact whitespace that immediately preceded this attribute in the open tag;
     *                            when empty a single space is associated with the attribute
     * @throws DomTripException if a quoted attribute value is missing or not terminated with a matching quote
     */
    private void parseAttribute(Element element, String precedingWhitespace) throws DomTripException {
        String name = parseAttributeName();
        skipWhitespace();

        if (position < length && xml.charAt(position) == '=') {
            skipEqualsAndWhitespace();
            parseAttributeValue(element, name, precedingWhitespace);
        }
    }

    /**
     * Parse an attribute name from the current parser position and advance the position to the first character after the name.
     *
     * The method does not skip leading whitespace; it reads characters until it encounters `=` or any whitespace or end of input.
     *
     * @return the attribute name as it appears in the source; may be empty if no name characters were present
     */
    private String parseAttributeName() {
        int nameStart = position;
        while (position < length && xml.charAt(position) != '=' && !isXmlWhitespace(xml.charAt(position))) {
            position++;
        }
        return xml.substring(nameStart, position);
    }

    /**
     * Advances the parser cursor past any consecutive XML whitespace characters.
     *
     * Stops when the cursor reaches the first non-whitespace character or the end of input.
     */
    private void skipWhitespace() {
        while (position < length && isXmlWhitespace(xml.charAt(position))) {
            position++;
        }
    }

    private void skipEqualsAndWhitespace() {
        // Skip '=' and any whitespace after it
        do {
            position++;
        } while (position < length && isXmlWhitespace(xml.charAt(position)));
    }

    /**
     * Parses a quoted attribute value at the current parse position and adds the attribute to the given element.
     *
     * @param element the element to which the parsed attribute will be added
     * @param name the attribute name
     * @param precedingWhitespace whitespace that immediately precedes the attribute value token; when empty a single space is used
     * @throws DomTripException if the attribute value does not start with a quote or if the closing quote is not found before end of input
     */
    private void parseAttributeValue(Element element, String name, String precedingWhitespace) throws DomTripException {
        if (position >= length || (xml.charAt(position) != '"' && xml.charAt(position) != '\'')) {
            throw new DomTripException("Missing attribute value quote", position, xml);
        }

        char quote = xml.charAt(position);
        position++; // Skip opening quote

        // Scan for closing quote using substring instead of char-by-char append
        int valueStart = position;
        while (position < length && xml.charAt(position) != quote) {
            position++;
        }

        if (position >= length) {
            throw new DomTripException("Unclosed attribute value", position, xml);
        }

        String rawValue = xml.substring(valueStart, position);
        position++; // Skip closing quote

        String decodedValue = Text.unescapeTextContent(rawValue);
        String actualWhitespace = precedingWhitespace.isEmpty() ? " " : precedingWhitespace;
        element.attributeInternal(name, decodedValue, quote, actualWhitespace, rawValue);
    }

    /**
     * Parse the closing tag at the current position, validate it against the node stack, finalize the matching Element, and remove it from the stack.
     *
     * @param nodeStack the stack of open nodes; the top Element must match the parsed closing tag and will be popped
     * @return the Element that was closed
     * @throws DomTripException if the closing tag is truncated, does not match the top Element, or appears with no open Element to match
     */
    private Element parseClosingTag(Deque<Node> nodeStack) throws DomTripException {
        int start = position; // Remember start position for original tag capture
        position += 2; // Skip "</"

        // Capture whitespace before the element name
        int wsStart = position;
        while (position < length && isXmlWhitespace(xml.charAt(position))) {
            position++;
        }

        // Parse tag name using substring
        int nameStart = position;
        while (position < length && xml.charAt(position) != '>' && !isXmlWhitespace(xml.charAt(position))) {
            position++;
        }

        String closingName = xml.substring(nameStart, position);

        // Skip any trailing whitespace after the element name (but don't capture it)
        while (position < length && isXmlWhitespace(xml.charAt(position))) {
            position++;
        }

        if (position >= length) {
            throw new DomTripException("Unclosed closing tag '</" + closingName + ">'", position, xml);
        }
        position++; // Skip '>'

        // Pop from stack if names match
        if (!nodeStack.isEmpty() && nodeStack.peek() instanceof Element) {
            Element element = (Element) nodeStack.peek();
            if (element.name().equals(closingName)) {
                // Capture the original close tag as source-backed slice (avoids substring allocation)
                element.originalCloseTagInternal(xml, start, position);

                // Capture the close tag whitespace
                if (wsStart < nameStart) {
                    element.closeTagWhitespaceInternal(xml.substring(wsStart, nameStart));
                }

                nodeStack.pop();
                return element; // Return the closed element
            }
            throw new DomTripException(
                    "Mismatched closing tag: expected '</" + element.name() + ">' but found '</" + closingName + ">'",
                    position,
                    xml);
        }
        throw new DomTripException("Unexpected closing tag '</" + closingName + ">'", position, xml);
    }

    /**
     * Determine whether a string consists only of XML whitespace characters
     * (space, tab, carriage return, line feed) as defined by the XML 1.0 specification.
     *
     * @param content the string to test, may be null
     * @return {@code true} if {@code content} is non-null and every character is XML whitespace, {@code false} otherwise
     */
    private static boolean isWhitespaceOnly(String content) {
        if (content == null) {
            return false;
        }
        for (int i = 0, len = content.length(); i < len; i++) {
            if (!isXmlWhitespace(content.charAt(i))) {
                return false;
            }
        }
        return true;
    }

    /**
     * Reads all bytes from an InputStream.
     */
    private byte[] readAllBytes(InputStream inputStream) throws IOException {
        ByteArrayOutputStream buffer = new ByteArrayOutputStream();
        byte[] data = new byte[8192];
        int bytesRead;

        while ((bytesRead = inputStream.read(data, 0, data.length)) != -1) {
            buffer.write(data, 0, bytesRead);
        }

        return buffer.toByteArray();
    }

    /**
     * Detects the character encoding of XML content from byte array.
     *
     * @param xmlBytes the XML content as bytes
     * @param defaultCharset fallback charset if detection fails
     * @return the detected or default charset
     */
    private Charset detectEncoding(byte[] xmlBytes, Charset defaultCharset) {
        // Check for BOM first
        Charset bomCharset = detectBOM(xmlBytes);
        if (bomCharset != null) {
            return bomCharset;
        }

        // Try to read XML declaration with different encodings
        Charset[] charsetsToTry = {
            StandardCharsets.UTF_8,
            StandardCharsets.UTF_16,
            StandardCharsets.UTF_16BE,
            StandardCharsets.UTF_16LE,
            StandardCharsets.ISO_8859_1,
            defaultCharset
        };

        for (Charset charset : charsetsToTry) {
            if (charset == null) continue;
            try {
                String xmlString = new String(xmlBytes, charset);
                String declaredEncoding = extractEncodingFromXmlDeclaration(xmlString);
                if (declaredEncoding != null) {
                    // Verify the declared encoding is valid
                    try {
                        Charset declaredCharset = Charset.forName(declaredEncoding);
                        return declaredCharset;
                    } catch (Exception e) {
                        // Invalid encoding name, continue with detection
                    }
                }
                // If we can read the XML declaration but no encoding is specified,
                // and we're trying UTF-8, use it
                if (StandardCharsets.UTF_8.equals(charset) && xmlString.trim().startsWith(XML_DECL_PREFIX)) {
                    return charset;
                }
            } catch (Exception e) {
                // Try next encoding
            }
        }

        return defaultCharset;
    }

    /**
     * Detects Byte Order Mark (BOM) and returns corresponding charset.
     */
    private Charset detectBOM(byte[] bytes) {
        Charset charset = detectUtf32BOM(bytes);
        if (charset != null) {
            return charset;
        }
        charset = detectUtf8BOM(bytes);
        if (charset != null) {
            return charset;
        }
        return detectUtf16BOM(bytes);
    }

    private Charset detectUtf8BOM(byte[] bytes) {
        if (bytes.length >= 3 && bytes[0] == (byte) 0xEF && bytes[1] == (byte) 0xBB && bytes[2] == (byte) 0xBF) {
            return StandardCharsets.UTF_8;
        }
        return null;
    }

    private Charset detectUtf16BOM(byte[] bytes) {
        if (bytes.length >= 2) {
            if (bytes[0] == (byte) 0xFE && bytes[1] == (byte) 0xFF) {
                return StandardCharsets.UTF_16BE;
            }
            if (bytes[0] == (byte) 0xFF && bytes[1] == (byte) 0xFE) {
                return StandardCharsets.UTF_16LE;
            }
        }
        return null;
    }

    private Charset detectUtf32BOM(byte[] bytes) {
        if (bytes.length >= 4) {
            if (bytes[0] == 0x00 && bytes[1] == 0x00 && bytes[2] == (byte) 0xFE && bytes[3] == (byte) 0xFF) {
                return Charset.forName("UTF-32BE");
            }
            if (bytes[0] == (byte) 0xFF && bytes[1] == (byte) 0xFE && bytes[2] == 0x00 && bytes[3] == 0x00) {
                return Charset.forName("UTF-32LE");
            }
        }
        return null;
    }

    /**
     * Extracts the encoding attribute from an XML declaration.
     *
     * @param xmlString the XML content as string
     * @return the encoding value from XML declaration, or null if not found
     */
    private String extractEncodingFromXmlDeclaration(String xmlString) {
        // Look for XML declaration at the beginning of the document
        String trimmed = xmlString.trim();
        if (!trimmed.startsWith(XML_DECL_PREFIX)) {
            return null;
        }

        // Find the end of the XML declaration
        int endIndex = trimmed.indexOf("?>");
        if (endIndex == -1) {
            return null;
        }

        String xmlDeclaration = trimmed.substring(0, endIndex + 2);
        Matcher matcher = XML_DECLARATION_PATTERN.matcher(xmlDeclaration);

        if (matcher.matches()) {
            return matcher.group(2); // encoding is the second group
        }

        return null;
    }

    /**
     * Updates Document properties based on parsed XML declaration attributes.
     *
     * @param document the document to update
     * @param xmlString the XML content to parse declaration from
     */
    private void updateDocumentFromXmlDeclaration(Document document, String xmlString) {
        String trimmed = xmlString.trim();
        if (!trimmed.startsWith(XML_DECL_PREFIX)) {
            return;
        }

        // Find the end of the XML declaration
        int endIndex = trimmed.indexOf("?>");
        if (endIndex == -1) {
            return;
        }

        String xmlDeclaration = trimmed.substring(0, endIndex + 2);
        Matcher matcher = XML_DECLARATION_PATTERN.matcher(xmlDeclaration);

        if (matcher.matches()) {
            String version = matcher.group(1);
            String encoding = matcher.group(2);
            String standalone = matcher.group(3);

            if (version != null) {
                document.versionInternal(version);
            }
            if (encoding != null) {
                document.encodingInternal(encoding);
            }
            if (standalone != null) {
                document.standaloneInternal("yes".equalsIgnoreCase(standalone));
            }
        }
    }
}
