/*
 * Copyright (c) 2023-2026 Maveniverse Org.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v2.0
 * which accompanies this distribution, and is available at
 * https://www.eclipse.org/legal/epl-v20.html
 */
package eu.maveniverse.domtrip;

/**
 * Represents an XML attribute with complete formatting preservation including
 * quote styles, whitespace, and entity encoding.
 *
 * <p>The Attribute class encapsulates all information needed to preserve the
 * exact formatting of XML attributes during round-trip processing. It maintains
 * both the decoded attribute value and the original raw value with entities
 * preserved, along with formatting details like quote style and whitespace.</p>
 *
 * <h3>Attribute Properties:</h3>
 * <ul>
 *   <li><strong>Quote Style Preservation</strong> - Maintains single vs double quotes</li>
 *   <li><strong>Whitespace Preservation</strong> - Preserves spacing before attributes</li>
 *   <li><strong>Entity Preservation</strong> - Maintains original entity encoding</li>
 *   <li><strong>Fluent Mutation</strong> - Mutable setters with method chaining, plus immutable-style {@code withX()} methods</li>
 *   <li><strong>Fluent API</strong> - Creation and modification with method chaining</li>
 * </ul>
 *
 * <h3>Usage Examples:</h3>
 * <pre>{@code
 * // Create basic attribute
 * Attribute attr = new Attribute("class", "important");
 *
 * // Create using factory methods
 * Attribute simple = Attribute.of("class", "important");
 * Attribute withQuotes = Attribute.of("id", "main", QuoteStyle.SINGLE);
 * Attribute complete = Attribute.of("data-value", "test & example", QuoteStyle.DOUBLE, "  ");
 *
 * // Create and modify with fluent API
 * Attribute fluent = Attribute.of("class", "initial")
 *     .value("updated")
 *     .quoteStyle(QuoteStyle.SINGLE)
 *     .precedingWhitespace("  ");
 *
 * // Create immutable variations
 * Attribute modified = attr.withValue("critical").withQuoteStyle(QuoteStyle.SINGLE);
 * }</pre>
 *
 * <h3>Attribute Formatting:</h3>
 * <p>Attributes are serialized with the following format:</p>
 * <p>{@code [whitespace][name]=[quote][value][quote]}</p>
 * <p>Example: {@code  class="important"} or {@code id='main'}</p>
 *
 * <h3>Entity Handling:</h3>
 * <p>The class automatically handles XML entity escaping for attribute values:</p>
 * <ul>
 *   <li>{@code &} → {@code &amp;}</li>
 *   <li>{@code <} → {@code &lt;}</li>
 *   <li>{@code >} → {@code &gt;}</li>
 *   <li>{@code "} → {@code &quot;} (when using double quotes)</li>
 *   <li>{@code '} → {@code &apos;} (when using single quotes)</li>
 * </ul>
 *
 * @see Element
 * @see QuoteStyle
 */
public class Attribute {
    private final String name;
    private String value;
    private String rawValue; // Original value with entities preserved
    private QuoteStyle quoteStyle; // Quote character used (' or ")
    private String precedingWhitespace; // Whitespace before the attribute

    public Attribute(String name, String value) {
        this(name, value, QuoteStyle.DOUBLE, " ");
    }

    public Attribute(String name, String value, QuoteStyle quoteStyle, String precedingWhitespace) {
        this.name = validateName(name);
        this.value = value;
        this.rawValue = null;
        this.quoteStyle = quoteStyle != null ? quoteStyle : QuoteStyle.DOUBLE;
        this.precedingWhitespace = precedingWhitespace != null ? precedingWhitespace : " ";
    }

    public Attribute(String name, String value, QuoteStyle quoteStyle, String precedingWhitespace, String rawValue) {
        this.name = validateName(name);
        this.value = value;
        this.rawValue = rawValue;
        this.quoteStyle = quoteStyle != null ? quoteStyle : QuoteStyle.DOUBLE;
        this.precedingWhitespace = precedingWhitespace != null ? precedingWhitespace : " ";
    }

    // Legacy constructor for backward compatibility
    public Attribute(String name, String value, char quoteChar, String precedingWhitespace) throws DomTripException {
        this(name, value, QuoteStyle.fromChar(quoteChar), precedingWhitespace);
    }

    // Legacy constructor for backward compatibility
    public Attribute(String name, String value, char quoteChar, String precedingWhitespace, String rawValue)
            throws DomTripException {
        this(name, value, QuoteStyle.fromChar(quoteChar), precedingWhitespace, rawValue);
    }

    public String name() {
        return name;
    }

    public String value() {
        return normalizeAttributeWhitespace(value);
    }

    public Attribute value(String value) {
        this.value = value;
        this.rawValue = null; // Clear raw value when setting programmatically
        return this;
    }

    public String rawValue() {
        return rawValue;
    }

    public Attribute rawValue(String rawValue) {
        this.rawValue = rawValue;
        return this;
    }

    public QuoteStyle quoteStyle() {
        return quoteStyle;
    }

    public Attribute quoteStyle(QuoteStyle quoteStyle) {
        this.quoteStyle = quoteStyle != null ? quoteStyle : QuoteStyle.DOUBLE;
        return this;
    }

    public String precedingWhitespace() {
        return precedingWhitespace;
    }

    public Attribute precedingWhitespace(String precedingWhitespace) {
        this.precedingWhitespace = precedingWhitespace != null ? precedingWhitespace : " ";
        return this;
    }

    /**
     * Provides the attribute value to use during XML serialization, preferring the original raw text when requested.
     *
     * @param useRaw if true, return the preserved raw attribute text when present; otherwise produce an escaped form
     * @return `rawValue` if `useRaw` is true and a raw value exists, otherwise the escaped form of `value` using the active quote character
     */
    public String getSerializationValue(boolean useRaw) {
        if (useRaw && rawValue != null) {
            return rawValue;
        }
        return escapeAttributeValue(value, quoteStyle.character());
    }

    /**
     * Produce an XML-safe attribute value by escaping '&', '<', '>' and the active quote character.
     *
     * @param value the attribute value to escape; if {@code null} it is treated as empty
     * @param quoteChar the quote character used to delimit the attribute (only this quote is escaped)
     * @return the escaped attribute value; returns the original string unchanged if no escaping was required
     */
    private String escapeAttributeValue(String value, char quoteChar) {
        if (value == null) return "";

        // Fast path: scan for any character that needs escaping
        int firstSpecial = indexOfSpecialChar(value, quoteChar);
        if (firstSpecial < 0) {
            return value; // No escaping needed — common case
        }

        // Single-pass escape from the first special character
        return escapeFrom(value, firstSpecial, quoteChar);
    }

    private static int indexOfSpecialChar(String value, char quoteChar) {
        for (int i = 0, len = value.length(); i < len; i++) {
            char c = value.charAt(i);
            if (c == '&' || c == '<' || c == '>' || c == quoteChar) {
                return i;
            }
        }
        return -1;
    }

    private static String escapeFrom(String value, int from, char quoteChar) {
        int len = value.length();
        StringBuilder sb = new StringBuilder(len + 16);
        if (from > 0) {
            sb.append(value, 0, from);
        }
        for (int i = from; i < len; i++) {
            appendEscaped(sb, value.charAt(i), quoteChar);
        }
        return sb.toString();
    }

    private static void appendEscaped(StringBuilder sb, char c, char quoteChar) {
        if (c == '&') {
            sb.append("&amp;");
        } else if (c == '<') {
            sb.append("&lt;");
        } else if (c == '>') {
            sb.append("&gt;");
        } else if (c == quoteChar) {
            sb.append(quoteChar == '"' ? "&quot;" : "&apos;");
        } else {
            sb.append(c);
        }
    }

    /**
     * Serializes this attribute to XML
     */
    public void toXml(StringBuilder sb, boolean useRaw) {
        sb.append(precedingWhitespace)
                .append(name)
                .append("=")
                .append(quoteStyle.character())
                .append(getSerializationValue(useRaw))
                .append(quoteStyle.character());
    }

    @Override
    public String toString() {
        return "Attribute{name='" + name + "', value='" + value + "', quote=" + quoteStyle.character() + "}";
    }

    private static String validateName(String name) {
        if (name == null) {
            return ""; // Handle null gracefully for backward compatibility
        }
        if (name.trim().isEmpty()) {
            return name; // Allow empty names for backward compatibility
        }
        // Only validate non-empty names
        if (!isValidXmlName(name)) {
            // For backward compatibility, don't throw exception, just return the name
            // In strict mode, this could throw an exception
            return name;
        }
        return name;
    }

    private static boolean isValidXmlName(String name) {
        if (name.isEmpty()) {
            return false;
        }

        char first = name.charAt(0);
        if (!Character.isLetter(first) && first != '_' && first != ':') {
            return false;
        }

        for (int i = 1; i < name.length(); i++) {
            char c = name.charAt(i);
            if (!Character.isLetterOrDigit(c) && c != '-' && c != '.' && c != '_' && c != ':') {
                return false;
            }
        }

        return true;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Attribute attribute = (Attribute) obj;
        return name.equals(attribute.name);
    }

    @Override
    public int hashCode() {
        return name.hashCode();
    }

    /**
     * Creates a new attribute with the specified value, preserving other properties.
     */
    public Attribute withValue(String newValue) {
        return new Attribute(this.name, newValue, this.quoteStyle, this.precedingWhitespace, null);
    }

    /**
     * Creates a new attribute with the specified quote style, preserving other properties.
     */
    public Attribute withQuoteStyle(QuoteStyle newQuoteStyle) {
        return new Attribute(this.name, this.value, newQuoteStyle, this.precedingWhitespace, this.rawValue);
    }

    /**
     * Creates a new attribute with the specified preceding whitespace, preserving other properties.
     */
    public Attribute withPrecedingWhitespace(String newWhitespace) {
        return new Attribute(this.name, this.value, this.quoteStyle, newWhitespace, this.rawValue);
    }

    /**
     * Creates a deep copy of this attribute.
     *
     * @return a new attribute that is a copy of this attribute
     * @since 1.1.0
     */
    public Attribute copy() {
        return new Attribute(this.name, this.value, this.quoteStyle, this.precedingWhitespace, this.rawValue);
    }

    /**
     * Creates a deep copy of this attribute.
     *
     * @return a new attribute that is a copy of this attribute
     * @deprecated Use {@link #copy()} instead.
     */
    @Deprecated
    @SuppressWarnings({"java:S2975", "java:S1133", "java:S1182"})
    public Attribute clone() {
        return copy();
    }

    /**
     * Normalizes attribute whitespace per XML 1.0 §3.3.3.
     *
     * <p>The XML specification requires non-validating parsers to normalize attribute
     * values by replacing tab ({@code #x9}), newline ({@code #xA}), and carriage return
     * ({@code #xD}) characters with space ({@code #x20}). Multiple spaces are NOT collapsed
     * (that only applies to tokenized attribute types with a validating processor).</p>
     *
     * @param value the attribute value to normalize; may be {@code null}
     * @return the value with whitespace characters normalized, or {@code null} if input was {@code null}
     */
    static String normalizeAttributeWhitespace(String value) {
        if (value == null || value.isEmpty()) {
            return value;
        }
        // Fast path: check if any whitespace chars need normalization
        boolean needsNormalization = false;
        for (int i = 0, len = value.length(); i < len; i++) {
            char c = value.charAt(i);
            if (c == '\t' || c == '\n' || c == '\r') {
                needsNormalization = true;
                break;
            }
        }
        if (!needsNormalization) {
            return value;
        }
        return value.replace('\t', ' ').replace('\n', ' ').replace('\r', ' ');
    }

    /**
     * Creates an attribute with the specified name and value.
     *
     * <p>Factory method following modern Java naming conventions.</p>
     *
     * @param name the attribute name
     * @param value the attribute value
     * @return a new Attribute
     */
    public static Attribute of(String name, String value) {
        return new Attribute(name, value);
    }

    /**
     * Creates an attribute with the specified name, value, and quote style.
     *
     * <p>Factory method for creating attributes with specific formatting.</p>
     *
     * @param name the attribute name
     * @param value the attribute value
     * @param quoteStyle the quote style to use
     * @return a new Attribute
     */
    public static Attribute of(String name, String value, QuoteStyle quoteStyle) {
        return new Attribute(name, value, quoteStyle, " ");
    }

    /**
     * Creates an attribute from a QName and value.
     *
     * <p>Creates an attribute using the QName's qualified name as the attribute name.
     * This is useful for creating namespaced attributes.</p>
     *
     * @param qname the QName for the attribute
     * @param value the attribute value
     * @return a new Attribute
     * @throws DomTripException if qname is null
     */
    public static Attribute of(QName qname, String value) throws DomTripException {
        if (qname == null) {
            throw new DomTripException("QName cannot be null");
        }
        return new Attribute(qname.qualifiedName(), value);
    }

    /**
     * Creates an attribute with all formatting options.
     *
     * <p>Factory method for creating attributes with complete control over formatting.</p>
     *
     * @param name the attribute name
     * @param value the attribute value
     * @param quoteStyle the quote style to use
     * @param precedingWhitespace the whitespace before the attribute
     * @return a new Attribute
     */
    public static Attribute of(String name, String value, QuoteStyle quoteStyle, String precedingWhitespace) {
        return new Attribute(name, value, quoteStyle, precedingWhitespace);
    }
}
