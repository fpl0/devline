/*
 * Copyright 2021-Present, Redis Ltd. and Contributors
 * All rights reserved.
 *
 * Licensed under the MIT License.
 *
 * This file contains contributions from third-party contributors
 * licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.lettuce.core;

/**
 * Exception that gets thrown when Redis replies with a {@code READONLY} error response.
 *
 * @author Tobias Nehrlich
 * @since 6.1.6
 */
@SuppressWarnings("serial")
public class RedisReadOnlyException extends RedisCommandExecutionException {

    /**
     * Create a {@code RedisReadOnlyException} with the specified detail message.
     *
     * @param msg the detail message.
     */
    public RedisReadOnlyException(String msg) {
        super(msg);
    }

    /**
     * Create a {@code RedisReadOnlyException} with the specified detail message and nested exception.
     *
     * @param msg the detail message.
     * @param cause the nested exception.
     */
    public RedisReadOnlyException(String msg, Throwable cause) {
        super(msg, cause);
    }

}
