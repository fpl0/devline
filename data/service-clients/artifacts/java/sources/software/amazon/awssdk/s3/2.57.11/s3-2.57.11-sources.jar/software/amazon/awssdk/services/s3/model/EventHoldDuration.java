/*
 * Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"). You may not use this file except in compliance with
 * the License. A copy of the License is located at
 * 
 * http://aws.amazon.com/apache2.0
 * 
 * or in the "license" file accompanying this file. This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
 * CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions
 * and limitations under the License.
 */

package software.amazon.awssdk.services.s3.model;

import java.io.Serializable;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.function.BiConsumer;
import java.util.function.Function;
import software.amazon.awssdk.annotations.Generated;
import software.amazon.awssdk.annotations.Mutable;
import software.amazon.awssdk.annotations.NotThreadSafe;
import software.amazon.awssdk.core.SdkField;
import software.amazon.awssdk.core.SdkPojo;
import software.amazon.awssdk.core.protocol.MarshallLocation;
import software.amazon.awssdk.core.protocol.MarshallingType;
import software.amazon.awssdk.core.traits.LocationTrait;
import software.amazon.awssdk.utils.ToString;
import software.amazon.awssdk.utils.builder.CopyableBuilder;
import software.amazon.awssdk.utils.builder.ToCopyableBuilder;

/**
 * <p>
 * Contains the event hold duration configuration, specified in either days or years.
 * </p>
 */
@Generated("software.amazon.awssdk:codegen")
public final class EventHoldDuration implements SdkPojo, Serializable,
        ToCopyableBuilder<EventHoldDuration.Builder, EventHoldDuration> {
    private static final SdkField<Integer> DAYS_FIELD = SdkField
            .<Integer> builder(MarshallingType.INTEGER)
            .memberName("Days")
            .getter(getter(EventHoldDuration::days))
            .setter(setter(Builder::days))
            .traits(LocationTrait.builder().location(MarshallLocation.PAYLOAD).locationName("Days")
                    .unmarshallLocationName("Days").build()).build();

    private static final SdkField<Integer> YEARS_FIELD = SdkField
            .<Integer> builder(MarshallingType.INTEGER)
            .memberName("Years")
            .getter(getter(EventHoldDuration::years))
            .setter(setter(Builder::years))
            .traits(LocationTrait.builder().location(MarshallLocation.PAYLOAD).locationName("Years")
                    .unmarshallLocationName("Years").build()).build();

    private static final List<SdkField<?>> SDK_FIELDS = Collections.unmodifiableList(Arrays.asList(DAYS_FIELD, YEARS_FIELD));

    private static final Map<String, SdkField<?>> SDK_NAME_TO_FIELD = memberNameToFieldInitializer();

    private static final long serialVersionUID = 1L;

    private final Integer days;

    private final Integer years;

    private EventHoldDuration(BuilderImpl builder) {
        this.days = builder.days;
        this.years = builder.years;
    }

    /**
     * <p>
     * The number of days for the event hold duration. The minimum value is 1 and the maximum value is 36,500.
     * </p>
     * 
     * @return The number of days for the event hold duration. The minimum value is 1 and the maximum value is 36,500.
     */
    public final Integer days() {
        return days;
    }

    /**
     * <p>
     * The number of years for the event hold duration. The minimum value is 1 and the maximum value is 100.
     * </p>
     * 
     * @return The number of years for the event hold duration. The minimum value is 1 and the maximum value is 100.
     */
    public final Integer years() {
        return years;
    }

    @Override
    public Builder toBuilder() {
        return new BuilderImpl(this);
    }

    public static Builder builder() {
        return new BuilderImpl();
    }

    public static Class<? extends Builder> serializableBuilderClass() {
        return BuilderImpl.class;
    }

    @Override
    public final int hashCode() {
        int hashCode = 1;
        hashCode = 31 * hashCode + Objects.hashCode(days());
        hashCode = 31 * hashCode + Objects.hashCode(years());
        return hashCode;
    }

    @Override
    public final boolean equals(Object obj) {
        return equalsBySdkFields(obj);
    }

    @Override
    public final boolean equalsBySdkFields(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (!(obj instanceof EventHoldDuration)) {
            return false;
        }
        EventHoldDuration other = (EventHoldDuration) obj;
        return Objects.equals(days(), other.days()) && Objects.equals(years(), other.years());
    }

    /**
     * Returns a string representation of this object. This is useful for testing and debugging. Sensitive data will be
     * redacted from this string using a placeholder value.
     */
    @Override
    public final String toString() {
        return ToString.builder("EventHoldDuration").add("Days", days()).add("Years", years()).build();
    }

    public final <T> Optional<T> getValueForField(String fieldName, Class<T> clazz) {
        switch (fieldName) {
        case "Days":
            return Optional.ofNullable(clazz.cast(days()));
        case "Years":
            return Optional.ofNullable(clazz.cast(years()));
        default:
            return Optional.empty();
        }
    }

    @Override
    public final List<SdkField<?>> sdkFields() {
        return SDK_FIELDS;
    }

    @Override
    public final Map<String, SdkField<?>> sdkFieldNameToField() {
        return SDK_NAME_TO_FIELD;
    }

    private static Map<String, SdkField<?>> memberNameToFieldInitializer() {
        Map<String, SdkField<?>> map = new HashMap<>();
        map.put("Days", DAYS_FIELD);
        map.put("Years", YEARS_FIELD);
        return Collections.unmodifiableMap(map);
    }

    private static <T> Function<Object, T> getter(Function<EventHoldDuration, T> g) {
        return obj -> g.apply((EventHoldDuration) obj);
    }

    private static <T> BiConsumer<Object, T> setter(BiConsumer<Builder, T> s) {
        return (obj, val) -> s.accept((Builder) obj, val);
    }

    @Mutable
    @NotThreadSafe
    public interface Builder extends SdkPojo, CopyableBuilder<Builder, EventHoldDuration> {
        /**
         * <p>
         * The number of days for the event hold duration. The minimum value is 1 and the maximum value is 36,500.
         * </p>
         * 
         * @param days
         *        The number of days for the event hold duration. The minimum value is 1 and the maximum value is
         *        36,500.
         * @return Returns a reference to this object so that method calls can be chained together.
         */
        Builder days(Integer days);

        /**
         * <p>
         * The number of years for the event hold duration. The minimum value is 1 and the maximum value is 100.
         * </p>
         * 
         * @param years
         *        The number of years for the event hold duration. The minimum value is 1 and the maximum value is 100.
         * @return Returns a reference to this object so that method calls can be chained together.
         */
        Builder years(Integer years);
    }

    static final class BuilderImpl implements Builder {
        private Integer days;

        private Integer years;

        private BuilderImpl() {
        }

        private BuilderImpl(EventHoldDuration model) {
            days(model.days);
            years(model.years);
        }

        public final Integer getDays() {
            return days;
        }

        public final void setDays(Integer days) {
            this.days = days;
        }

        @Override
        public final Builder days(Integer days) {
            this.days = days;
            return this;
        }

        public final Integer getYears() {
            return years;
        }

        public final void setYears(Integer years) {
            this.years = years;
        }

        @Override
        public final Builder years(Integer years) {
            this.years = years;
            return this;
        }

        @Override
        public EventHoldDuration build() {
            return new EventHoldDuration(this);
        }

        @Override
        public List<SdkField<?>> sdkFields() {
            return SDK_FIELDS;
        }

        @Override
        public Map<String, SdkField<?>> sdkFieldNameToField() {
            return SDK_NAME_TO_FIELD;
        }
    }
}
