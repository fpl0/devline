/*
 * Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License").
 * You may not use this file except in compliance with the License.
 * A copy of the License is located at
 *
 *  http://aws.amazon.com/apache2.0
 *
 * or in the "license" file accompanying this file. This file is distributed
 * on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 * express or implied. See the License for the specific language governing
 * permissions and limitations under the License.
 */

package software.amazon.awssdk.core.internal.http.loader;

import software.amazon.awssdk.annotations.SdkInternalApi;

/**
 * Warms every HTTP client on the classpath for CRaC warm-up by invoking each {@link HttpClientWarmer}.
 */
@SdkInternalApi
public interface HttpWarmupInvoker {

    /**
     * Invokes {@link HttpClientWarmer#warmAll()} on every warmer. Best-effort; never throws.
     */
    void invokeAll();
}
