/*
 * Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"). You may not use this file except in compliance with
 * the License. A copy of the License is located at
 * 
 * http://aws.amazon.com/apache2.0
 * 
 * or in the "license" file accompanying this file. This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
 * CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions
 * and limitations under the License.
 */

package software.amazon.awssdk.services.s3.model;

import java.util.EnumSet;
import java.util.Map;
import java.util.Set;
import software.amazon.awssdk.annotations.Generated;
import software.amazon.awssdk.utils.internal.EnumUtils;

@Generated("software.amazon.awssdk:codegen")
public enum ObjectStorageClass {
    STANDARD("STANDARD"),

    REDUCED_REDUNDANCY("REDUCED_REDUNDANCY"),

    GLACIER("GLACIER"),

    STANDARD_IA("STANDARD_IA"),

    ONEZONE_IA("ONEZONE_IA"),

    INTELLIGENT_TIERING("INTELLIGENT_TIERING"),

    DEEP_ARCHIVE("DEEP_ARCHIVE"),

    OUTPOSTS("OUTPOSTS"),

    GLACIER_IR("GLACIER_IR"),

    SNOW("SNOW"),

    EXPRESS_ONEZONE("EXPRESS_ONEZONE"),

    FSX_OPENZFS("FSX_OPENZFS"),

    FSX_ONTAP("FSX_ONTAP"),

    AWS_BACKUP_WARM("AWS_BACKUP_WARM"),

    AWS_BACKUP_LOW_COST_WARM("AWS_BACKUP_LOW_COST_WARM"),

    UNKNOWN_TO_SDK_VERSION(null);

    private static final Map<String, ObjectStorageClass> VALUE_MAP = EnumUtils.uniqueIndex(ObjectStorageClass.class,
            ObjectStorageClass::toString);

    private final String value;

    private ObjectStorageClass(String value) {
        this.value = value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    /**
     * Use this in place of valueOf to convert the raw string returned by the service into the enum value.
     *
     * @param value
     *        real value
     * @return ObjectStorageClass corresponding to the value
     */
    public static ObjectStorageClass fromValue(String value) {
        if (value == null) {
            return null;
        }
        return VALUE_MAP.getOrDefault(value, UNKNOWN_TO_SDK_VERSION);
    }

    /**
     * Use this in place of {@link #values()} to return a {@link Set} of all values known to the SDK. This will return
     * all known enum values except {@link #UNKNOWN_TO_SDK_VERSION}.
     *
     * @return a {@link Set} of known {@link ObjectStorageClass}s
     */
    public static Set<ObjectStorageClass> knownValues() {
        Set<ObjectStorageClass> knownValues = EnumSet.allOf(ObjectStorageClass.class);
        knownValues.remove(UNKNOWN_TO_SDK_VERSION);
        return knownValues;
    }
}
