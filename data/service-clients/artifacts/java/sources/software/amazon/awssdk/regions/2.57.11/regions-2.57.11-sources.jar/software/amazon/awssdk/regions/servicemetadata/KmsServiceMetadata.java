/*
 * Copyright 2021-2026 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"). You may not use this file except in compliance with
 * the License. A copy of the License is located at
 * 
 * http://aws.amazon.com/apache2.0
 * 
 * or in the "license" file accompanying this file. This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
 * CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions
 * and limitations under the License.
 */

package software.amazon.awssdk.regions.servicemetadata;

import java.net.URI;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import software.amazon.awssdk.annotations.Generated;
import software.amazon.awssdk.annotations.SdkPublicApi;
import software.amazon.awssdk.regions.EndpointTag;
import software.amazon.awssdk.regions.PartitionEndpointKey;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.regions.ServiceEndpointKey;
import software.amazon.awssdk.regions.ServiceMetadata;
import software.amazon.awssdk.regions.ServicePartitionMetadata;
import software.amazon.awssdk.regions.internal.DefaultServicePartitionMetadata;
import software.amazon.awssdk.regions.internal.util.ServiceMetadataUtils;
import software.amazon.awssdk.utils.ImmutableMap;
import software.amazon.awssdk.utils.Pair;

@Generated("software.amazon.awssdk:codegen")
@SdkPublicApi
public final class KmsServiceMetadata implements ServiceMetadata {
    private static final String ENDPOINT_PREFIX = "kms";

    private static final List<Region> REGIONS = Collections.unmodifiableList(Arrays.asList(Region.of("af-south-1"),
            Region.of("af-south-1-fips"), Region.of("ap-east-1"), Region.of("ap-east-1-fips"), Region.of("ap-east-2"),
            Region.of("ap-northeast-1"), Region.of("ap-northeast-1-fips"), Region.of("ap-northeast-2"),
            Region.of("ap-northeast-2-fips"), Region.of("ap-northeast-3"), Region.of("ap-northeast-3-fips"),
            Region.of("ap-south-1"), Region.of("ap-south-1-fips"), Region.of("ap-south-2"), Region.of("ap-southeast-1"),
            Region.of("ap-southeast-1-fips"), Region.of("ap-southeast-2"), Region.of("ap-southeast-2-fips"),
            Region.of("ap-southeast-3"), Region.of("ap-southeast-4"), Region.of("ap-southeast-5"), Region.of("ap-southeast-6"),
            Region.of("ap-southeast-7"), Region.of("ca-central-1"), Region.of("ca-central-1-fips"), Region.of("ca-west-1"),
            Region.of("eu-central-1"), Region.of("eu-central-1-fips"), Region.of("eu-central-2"), Region.of("eu-north-1"),
            Region.of("eu-north-1-fips"), Region.of("eu-south-1"), Region.of("eu-south-1-fips"), Region.of("eu-south-2"),
            Region.of("eu-west-1"), Region.of("eu-west-1-fips"), Region.of("eu-west-2"), Region.of("eu-west-2-fips"),
            Region.of("eu-west-3"), Region.of("eu-west-3-fips"), Region.of("il-central-1"), Region.of("me-central-1"),
            Region.of("me-south-1"), Region.of("me-south-1-fips"), Region.of("mx-central-1"), Region.of("sa-east-1"),
            Region.of("sa-east-1-fips"), Region.of("us-east-1"), Region.of("us-east-1-fips"), Region.of("us-east-2"),
            Region.of("us-east-2-fips"), Region.of("us-west-1"), Region.of("us-west-1-fips"), Region.of("us-west-2"),
            Region.of("us-west-2-fips"), Region.of("cn-north-1"), Region.of("cn-northwest-1"), Region.of("us-gov-east-1"),
            Region.of("us-gov-east-1-fips"), Region.of("us-gov-west-1"), Region.of("us-gov-west-1-fips"),
            Region.of("us-iso-east-1"), Region.of("us-iso-east-1-fips"), Region.of("us-iso-west-1"),
            Region.of("us-iso-west-1-fips"), Region.of("us-isob-east-1"), Region.of("us-isob-east-1-fips"),
            Region.of("us-isob-west-1"), Region.of("eu-isoe-west-1"), Region.of("us-isof-east-1"), Region.of("us-isof-south-1"),
            Region.of("eusc-de-east-1")));

    private static final List<ServicePartitionMetadata> PARTITIONS = Collections.unmodifiableList(Arrays.asList(
            new DefaultServicePartitionMetadata("aws", null), new DefaultServicePartitionMetadata("aws-cn", null),
            new DefaultServicePartitionMetadata("aws-us-gov", null), new DefaultServicePartitionMetadata("aws-iso", null),
            new DefaultServicePartitionMetadata("aws-iso-b", null), new DefaultServicePartitionMetadata("aws-iso-e", null),
            new DefaultServicePartitionMetadata("aws-iso-f", null), new DefaultServicePartitionMetadata("aws-eusc", null)));

    private static final Map<ServiceEndpointKey, String> SIGNING_REGIONS_BY_REGION = ImmutableMap
            .<ServiceEndpointKey, String> builder().allowDuplicateKeys(true)
            .put(ServiceEndpointKey.builder().region(Region.of("af-south-1-fips")).build(), "af-south-1")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-east-1-fips")).build(), "ap-east-1")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-northeast-1-fips")).build(), "ap-northeast-1")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-northeast-2-fips")).build(), "ap-northeast-2")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-northeast-3-fips")).build(), "ap-northeast-3")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-south-1-fips")).build(), "ap-south-1")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-southeast-1-fips")).build(), "ap-southeast-1")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-southeast-2-fips")).build(), "ap-southeast-2")
            .put(ServiceEndpointKey.builder().region(Region.of("ca-central-1-fips")).build(), "ca-central-1")
            .put(ServiceEndpointKey.builder().region(Region.of("eu-central-1-fips")).build(), "eu-central-1")
            .put(ServiceEndpointKey.builder().region(Region.of("eu-north-1-fips")).build(), "eu-north-1")
            .put(ServiceEndpointKey.builder().region(Region.of("eu-south-1-fips")).build(), "eu-south-1")
            .put(ServiceEndpointKey.builder().region(Region.of("eu-west-1-fips")).build(), "eu-west-1")
            .put(ServiceEndpointKey.builder().region(Region.of("eu-west-2-fips")).build(), "eu-west-2")
            .put(ServiceEndpointKey.builder().region(Region.of("eu-west-3-fips")).build(), "eu-west-3")
            .put(ServiceEndpointKey.builder().region(Region.of("me-south-1-fips")).build(), "me-south-1")
            .put(ServiceEndpointKey.builder().region(Region.of("sa-east-1-fips")).build(), "sa-east-1")
            .put(ServiceEndpointKey.builder().region(Region.of("us-east-1-fips")).build(), "us-east-1")
            .put(ServiceEndpointKey.builder().region(Region.of("us-east-2-fips")).build(), "us-east-2")
            .put(ServiceEndpointKey.builder().region(Region.of("us-west-1-fips")).build(), "us-west-1")
            .put(ServiceEndpointKey.builder().region(Region.of("us-west-2-fips")).build(), "us-west-2")
            .put(ServiceEndpointKey.builder().region(Region.of("us-iso-east-1-fips")).build(), "us-iso-east-1")
            .put(ServiceEndpointKey.builder().region(Region.of("us-iso-west-1-fips")).build(), "us-iso-west-1")
            .put(ServiceEndpointKey.builder().region(Region.of("us-isob-east-1-fips")).build(), "us-isob-east-1")
            .put(ServiceEndpointKey.builder().region(Region.of("us-gov-east-1-fips")).build(), "us-gov-east-1")
            .put(ServiceEndpointKey.builder().region(Region.of("us-gov-west-1-fips")).build(), "us-gov-west-1").build();

    private static final Map<Pair<String, PartitionEndpointKey>, String> SIGNING_REGIONS_BY_PARTITION = ImmutableMap
            .<Pair<String, PartitionEndpointKey>, String> builder().build();

    private static final Map<ServiceEndpointKey, String> DNS_SUFFIXES_BY_REGION = ImmutableMap
            .<ServiceEndpointKey, String> builder().build();

    private static final Map<Pair<String, PartitionEndpointKey>, String> DNS_SUFFIXES_BY_PARTITION = ImmutableMap
            .<Pair<String, PartitionEndpointKey>, String> builder().build();

    private static final Map<ServiceEndpointKey, String> HOSTNAMES_BY_REGION = ImmutableMap
            .<ServiceEndpointKey, String> builder()
            .allowDuplicateKeys(true)
            .put(ServiceEndpointKey.builder().region(Region.of("af-south-1")).tags(EndpointTag.of("fips")).build(),
                    "kms-fips.af-south-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("af-south-1-fips")).build(), "kms-fips.af-south-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-east-1")).tags(EndpointTag.of("fips")).build(),
                    "kms-fips.ap-east-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-east-1-fips")).build(), "kms-fips.ap-east-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-northeast-1")).tags(EndpointTag.of("fips")).build(),
                    "kms-fips.ap-northeast-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-northeast-1-fips")).build(),
                    "kms-fips.ap-northeast-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-northeast-2")).tags(EndpointTag.of("fips")).build(),
                    "kms-fips.ap-northeast-2.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-northeast-2-fips")).build(),
                    "kms-fips.ap-northeast-2.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-northeast-3")).tags(EndpointTag.of("fips")).build(),
                    "kms-fips.ap-northeast-3.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-northeast-3-fips")).build(),
                    "kms-fips.ap-northeast-3.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-south-1")).tags(EndpointTag.of("fips")).build(),
                    "kms-fips.ap-south-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-south-1-fips")).build(), "kms-fips.ap-south-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-south-2")).tags(EndpointTag.of("fips")).build(),
                    "kms-fips.ap-south-2.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-southeast-1")).tags(EndpointTag.of("fips")).build(),
                    "kms-fips.ap-southeast-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-southeast-1-fips")).build(),
                    "kms-fips.ap-southeast-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-southeast-2")).tags(EndpointTag.of("fips")).build(),
                    "kms-fips.ap-southeast-2.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-southeast-2-fips")).build(),
                    "kms-fips.ap-southeast-2.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-southeast-3")).tags(EndpointTag.of("fips")).build(),
                    "kms-fips.ap-southeast-3.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-southeast-4")).tags(EndpointTag.of("fips")).build(),
                    "kms-fips.ap-southeast-4.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-southeast-5")).tags(EndpointTag.of("fips")).build(),
                    "kms-fips.ap-southeast-5.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-southeast-7")).tags(EndpointTag.of("fips")).build(),
                    "kms-fips.ap-southeast-7.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("ca-central-1")).tags(EndpointTag.of("fips")).build(),
                    "kms-fips.ca-central-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("ca-central-1-fips")).build(),
                    "kms-fips.ca-central-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("ca-west-1")).tags(EndpointTag.of("fips")).build(),
                    "kms-fips.ca-west-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("eu-central-1")).tags(EndpointTag.of("fips")).build(),
                    "kms-fips.eu-central-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("eu-central-1-fips")).build(),
                    "kms-fips.eu-central-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("eu-central-2")).tags(EndpointTag.of("fips")).build(),
                    "kms-fips.eu-central-2.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("eu-north-1")).tags(EndpointTag.of("fips")).build(),
                    "kms-fips.eu-north-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("eu-north-1-fips")).build(), "kms-fips.eu-north-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("eu-south-1")).tags(EndpointTag.of("fips")).build(),
                    "kms-fips.eu-south-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("eu-south-1-fips")).build(), "kms-fips.eu-south-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("eu-south-2")).tags(EndpointTag.of("fips")).build(),
                    "kms-fips.eu-south-2.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("eu-west-1")).tags(EndpointTag.of("fips")).build(),
                    "kms-fips.eu-west-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("eu-west-1-fips")).build(), "kms-fips.eu-west-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("eu-west-2")).tags(EndpointTag.of("fips")).build(),
                    "kms-fips.eu-west-2.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("eu-west-2-fips")).build(), "kms-fips.eu-west-2.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("eu-west-3")).tags(EndpointTag.of("fips")).build(),
                    "kms-fips.eu-west-3.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("eu-west-3-fips")).build(), "kms-fips.eu-west-3.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("il-central-1")).tags(EndpointTag.of("fips")).build(),
                    "kms-fips.il-central-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("me-central-1")).tags(EndpointTag.of("fips")).build(),
                    "kms-fips.me-central-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("me-south-1")).tags(EndpointTag.of("fips")).build(),
                    "kms-fips.me-south-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("me-south-1-fips")).build(), "kms-fips.me-south-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("mx-central-1")).tags(EndpointTag.of("fips")).build(),
                    "kms-fips.mx-central-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("sa-east-1")).tags(EndpointTag.of("fips")).build(),
                    "kms-fips.sa-east-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("sa-east-1-fips")).build(), "kms-fips.sa-east-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("us-east-1")).tags(EndpointTag.of("fips")).build(),
                    "kms-fips.us-east-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("us-east-1-fips")).build(), "kms-fips.us-east-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("us-east-2")).tags(EndpointTag.of("fips")).build(),
                    "kms-fips.us-east-2.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("us-east-2-fips")).build(), "kms-fips.us-east-2.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("us-west-1")).tags(EndpointTag.of("fips")).build(),
                    "kms-fips.us-west-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("us-west-1-fips")).build(), "kms-fips.us-west-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("us-west-2")).tags(EndpointTag.of("fips")).build(),
                    "kms-fips.us-west-2.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("us-west-2-fips")).build(), "kms-fips.us-west-2.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("us-iso-east-1")).tags(EndpointTag.of("fips")).build(),
                    "kms-fips.us-iso-east-1.c2s.ic.gov")
            .put(ServiceEndpointKey.builder().region(Region.of("us-iso-east-1-fips")).build(),
                    "kms-fips.us-iso-east-1.c2s.ic.gov")
            .put(ServiceEndpointKey.builder().region(Region.of("us-iso-west-1")).tags(EndpointTag.of("fips")).build(),
                    "kms-fips.us-iso-west-1.c2s.ic.gov")
            .put(ServiceEndpointKey.builder().region(Region.of("us-iso-west-1-fips")).build(),
                    "kms-fips.us-iso-west-1.c2s.ic.gov")
            .put(ServiceEndpointKey.builder().region(Region.of("us-isob-east-1")).tags(EndpointTag.of("fips")).build(),
                    "kms-fips.us-isob-east-1.sc2s.sgov.gov")
            .put(ServiceEndpointKey.builder().region(Region.of("us-isob-east-1-fips")).build(),
                    "kms-fips.us-isob-east-1.sc2s.sgov.gov")
            .put(ServiceEndpointKey.builder().region(Region.of("eu-isoe-west-1")).tags(EndpointTag.of("fips")).build(),
                    "kms-fips.eu-isoe-west-1.cloud.adc-e.uk")
            .put(ServiceEndpointKey.builder().region(Region.of("us-isof-east-1")).tags(EndpointTag.of("fips")).build(),
                    "kms-fips.us-isof-east-1.csp.hci.ic.gov")
            .put(ServiceEndpointKey.builder().region(Region.of("us-isof-south-1")).tags(EndpointTag.of("fips")).build(),
                    "kms-fips.us-isof-south-1.csp.hci.ic.gov")
            .put(ServiceEndpointKey.builder().region(Region.of("us-gov-east-1")).tags(EndpointTag.of("fips")).build(),
                    "kms-fips.us-gov-east-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("us-gov-east-1-fips")).build(),
                    "kms-fips.us-gov-east-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("us-gov-west-1")).tags(EndpointTag.of("fips")).build(),
                    "kms-fips.us-gov-west-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("us-gov-west-1-fips")).build(),
                    "kms-fips.us-gov-west-1.amazonaws.com").build();

    private static final Map<Pair<String, PartitionEndpointKey>, String> HOSTNAMES_BY_PARTITION = ImmutableMap
            .<Pair<String, PartitionEndpointKey>, String> builder().build();

    @Override
    public List<Region> regions() {
        return REGIONS;
    }

    @Override
    public List<ServicePartitionMetadata> servicePartitions() {
        return PARTITIONS;
    }

    @Override
    public URI endpointFor(ServiceEndpointKey key) {
        return ServiceMetadataUtils.endpointFor(ServiceMetadataUtils.hostname(key, HOSTNAMES_BY_REGION, HOSTNAMES_BY_PARTITION),
                ENDPOINT_PREFIX, key.region().id(),
                ServiceMetadataUtils.dnsSuffix(key, DNS_SUFFIXES_BY_REGION, DNS_SUFFIXES_BY_PARTITION));
    }

    @Override
    public Region signingRegion(ServiceEndpointKey key) {
        return ServiceMetadataUtils.signingRegion(key, SIGNING_REGIONS_BY_REGION, SIGNING_REGIONS_BY_PARTITION);
    }
}
