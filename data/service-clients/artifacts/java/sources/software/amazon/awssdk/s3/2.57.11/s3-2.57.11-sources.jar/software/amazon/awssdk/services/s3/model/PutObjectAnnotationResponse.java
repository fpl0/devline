/*
 * Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"). You may not use this file except in compliance with
 * the License. A copy of the License is located at
 * 
 * http://aws.amazon.com/apache2.0
 * 
 * or in the "license" file accompanying this file. This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
 * CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions
 * and limitations under the License.
 */

package software.amazon.awssdk.services.s3.model;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.function.BiConsumer;
import java.util.function.Function;
import software.amazon.awssdk.annotations.Generated;
import software.amazon.awssdk.annotations.Mutable;
import software.amazon.awssdk.annotations.NotThreadSafe;
import software.amazon.awssdk.core.SdkField;
import software.amazon.awssdk.core.SdkPojo;
import software.amazon.awssdk.core.protocol.MarshallLocation;
import software.amazon.awssdk.core.protocol.MarshallingType;
import software.amazon.awssdk.core.traits.LocationTrait;
import software.amazon.awssdk.utils.ToString;
import software.amazon.awssdk.utils.builder.CopyableBuilder;
import software.amazon.awssdk.utils.builder.ToCopyableBuilder;

/**
 */
@Generated("software.amazon.awssdk:codegen")
public final class PutObjectAnnotationResponse extends S3Response implements
        ToCopyableBuilder<PutObjectAnnotationResponse.Builder, PutObjectAnnotationResponse> {
    private static final SdkField<String> KEY_FIELD = SdkField
            .<String> builder(MarshallingType.STRING)
            .memberName("Key")
            .getter(getter(PutObjectAnnotationResponse::key))
            .setter(setter(Builder::key))
            .traits(LocationTrait.builder().location(MarshallLocation.PAYLOAD).locationName("Key").unmarshallLocationName("Key")
                    .build()).build();

    private static final SdkField<String> ANNOTATION_NAME_FIELD = SdkField
            .<String> builder(MarshallingType.STRING)
            .memberName("AnnotationName")
            .getter(getter(PutObjectAnnotationResponse::annotationName))
            .setter(setter(Builder::annotationName))
            .traits(LocationTrait.builder().location(MarshallLocation.PAYLOAD).locationName("AnnotationName")
                    .unmarshallLocationName("AnnotationName").build()).build();

    private static final SdkField<String> OBJECT_VERSION_ID_FIELD = SdkField
            .<String> builder(MarshallingType.STRING)
            .memberName("ObjectVersionId")
            .getter(getter(PutObjectAnnotationResponse::objectVersionId))
            .setter(setter(Builder::objectVersionId))
            .traits(LocationTrait.builder().location(MarshallLocation.HEADER).locationName("x-amz-object-version-id")
                    .unmarshallLocationName("x-amz-object-version-id").build()).build();

    private static final SdkField<String> E_TAG_FIELD = SdkField
            .<String> builder(MarshallingType.STRING)
            .memberName("ETag")
            .getter(getter(PutObjectAnnotationResponse::eTag))
            .setter(setter(Builder::eTag))
            .traits(LocationTrait.builder().location(MarshallLocation.HEADER).locationName("ETag").unmarshallLocationName("ETag")
                    .build()).build();

    private static final SdkField<String> CHECKSUM_CRC32_FIELD = SdkField
            .<String> builder(MarshallingType.STRING)
            .memberName("ChecksumCRC32")
            .getter(getter(PutObjectAnnotationResponse::checksumCRC32))
            .setter(setter(Builder::checksumCRC32))
            .traits(LocationTrait.builder().location(MarshallLocation.HEADER).locationName("x-amz-checksum-crc32")
                    .unmarshallLocationName("x-amz-checksum-crc32").build()).build();

    private static final SdkField<String> CHECKSUM_CRC32_C_FIELD = SdkField
            .<String> builder(MarshallingType.STRING)
            .memberName("ChecksumCRC32C")
            .getter(getter(PutObjectAnnotationResponse::checksumCRC32C))
            .setter(setter(Builder::checksumCRC32C))
            .traits(LocationTrait.builder().location(MarshallLocation.HEADER).locationName("x-amz-checksum-crc32c")
                    .unmarshallLocationName("x-amz-checksum-crc32c").build()).build();

    private static final SdkField<String> CHECKSUM_CRC64_NVME_FIELD = SdkField
            .<String> builder(MarshallingType.STRING)
            .memberName("ChecksumCRC64NVME")
            .getter(getter(PutObjectAnnotationResponse::checksumCRC64NVME))
            .setter(setter(Builder::checksumCRC64NVME))
            .traits(LocationTrait.builder().location(MarshallLocation.HEADER).locationName("x-amz-checksum-crc64nvme")
                    .unmarshallLocationName("x-amz-checksum-crc64nvme").build()).build();

    private static final SdkField<String> CHECKSUM_SHA1_FIELD = SdkField
            .<String> builder(MarshallingType.STRING)
            .memberName("ChecksumSHA1")
            .getter(getter(PutObjectAnnotationResponse::checksumSHA1))
            .setter(setter(Builder::checksumSHA1))
            .traits(LocationTrait.builder().location(MarshallLocation.HEADER).locationName("x-amz-checksum-sha1")
                    .unmarshallLocationName("x-amz-checksum-sha1").build()).build();

    private static final SdkField<String> CHECKSUM_SHA256_FIELD = SdkField
            .<String> builder(MarshallingType.STRING)
            .memberName("ChecksumSHA256")
            .getter(getter(PutObjectAnnotationResponse::checksumSHA256))
            .setter(setter(Builder::checksumSHA256))
            .traits(LocationTrait.builder().location(MarshallLocation.HEADER).locationName("x-amz-checksum-sha256")
                    .unmarshallLocationName("x-amz-checksum-sha256").build()).build();

    private static final SdkField<String> CHECKSUM_SHA512_FIELD = SdkField
            .<String> builder(MarshallingType.STRING)
            .memberName("ChecksumSHA512")
            .getter(getter(PutObjectAnnotationResponse::checksumSHA512))
            .setter(setter(Builder::checksumSHA512))
            .traits(LocationTrait.builder().location(MarshallLocation.HEADER).locationName("x-amz-checksum-sha512")
                    .unmarshallLocationName("x-amz-checksum-sha512").build()).build();

    private static final SdkField<String> CHECKSUM_MD5_FIELD = SdkField
            .<String> builder(MarshallingType.STRING)
            .memberName("ChecksumMD5")
            .getter(getter(PutObjectAnnotationResponse::checksumMD5))
            .setter(setter(Builder::checksumMD5))
            .traits(LocationTrait.builder().location(MarshallLocation.HEADER).locationName("x-amz-checksum-md5")
                    .unmarshallLocationName("x-amz-checksum-md5").build()).build();

    private static final SdkField<String> CHECKSUM_XXHASH64_FIELD = SdkField
            .<String> builder(MarshallingType.STRING)
            .memberName("ChecksumXXHASH64")
            .getter(getter(PutObjectAnnotationResponse::checksumXXHASH64))
            .setter(setter(Builder::checksumXXHASH64))
            .traits(LocationTrait.builder().location(MarshallLocation.HEADER).locationName("x-amz-checksum-xxhash64")
                    .unmarshallLocationName("x-amz-checksum-xxhash64").build()).build();

    private static final SdkField<String> CHECKSUM_XXHASH3_FIELD = SdkField
            .<String> builder(MarshallingType.STRING)
            .memberName("ChecksumXXHASH3")
            .getter(getter(PutObjectAnnotationResponse::checksumXXHASH3))
            .setter(setter(Builder::checksumXXHASH3))
            .traits(LocationTrait.builder().location(MarshallLocation.HEADER).locationName("x-amz-checksum-xxhash3")
                    .unmarshallLocationName("x-amz-checksum-xxhash3").build()).build();

    private static final SdkField<String> CHECKSUM_XXHASH128_FIELD = SdkField
            .<String> builder(MarshallingType.STRING)
            .memberName("ChecksumXXHASH128")
            .getter(getter(PutObjectAnnotationResponse::checksumXXHASH128))
            .setter(setter(Builder::checksumXXHASH128))
            .traits(LocationTrait.builder().location(MarshallLocation.HEADER).locationName("x-amz-checksum-xxhash128")
                    .unmarshallLocationName("x-amz-checksum-xxhash128").build()).build();

    private static final SdkField<String> CHECKSUM_TYPE_FIELD = SdkField
            .<String> builder(MarshallingType.STRING)
            .memberName("ChecksumType")
            .getter(getter(PutObjectAnnotationResponse::checksumTypeAsString))
            .setter(setter(Builder::checksumType))
            .traits(LocationTrait.builder().location(MarshallLocation.HEADER).locationName("x-amz-checksum-type")
                    .unmarshallLocationName("x-amz-checksum-type").build()).build();

    private static final SdkField<String> SERVER_SIDE_ENCRYPTION_FIELD = SdkField
            .<String> builder(MarshallingType.STRING)
            .memberName("ServerSideEncryption")
            .getter(getter(PutObjectAnnotationResponse::serverSideEncryptionAsString))
            .setter(setter(Builder::serverSideEncryption))
            .traits(LocationTrait.builder().location(MarshallLocation.HEADER).locationName("x-amz-server-side-encryption")
                    .unmarshallLocationName("x-amz-server-side-encryption").build()).build();

    private static final SdkField<String> REQUEST_CHARGED_FIELD = SdkField
            .<String> builder(MarshallingType.STRING)
            .memberName("RequestCharged")
            .getter(getter(PutObjectAnnotationResponse::requestChargedAsString))
            .setter(setter(Builder::requestCharged))
            .traits(LocationTrait.builder().location(MarshallLocation.HEADER).locationName("x-amz-request-charged")
                    .unmarshallLocationName("x-amz-request-charged").build()).build();

    private static final List<SdkField<?>> SDK_FIELDS = Collections.unmodifiableList(Arrays.asList(KEY_FIELD,
            ANNOTATION_NAME_FIELD, OBJECT_VERSION_ID_FIELD, E_TAG_FIELD, CHECKSUM_CRC32_FIELD, CHECKSUM_CRC32_C_FIELD,
            CHECKSUM_CRC64_NVME_FIELD, CHECKSUM_SHA1_FIELD, CHECKSUM_SHA256_FIELD, CHECKSUM_SHA512_FIELD, CHECKSUM_MD5_FIELD,
            CHECKSUM_XXHASH64_FIELD, CHECKSUM_XXHASH3_FIELD, CHECKSUM_XXHASH128_FIELD, CHECKSUM_TYPE_FIELD,
            SERVER_SIDE_ENCRYPTION_FIELD, REQUEST_CHARGED_FIELD));

    private static final Map<String, SdkField<?>> SDK_NAME_TO_FIELD = memberNameToFieldInitializer();

    private final String key;

    private final String annotationName;

    private final String objectVersionId;

    private final String eTag;

    private final String checksumCRC32;

    private final String checksumCRC32C;

    private final String checksumCRC64NVME;

    private final String checksumSHA1;

    private final String checksumSHA256;

    private final String checksumSHA512;

    private final String checksumMD5;

    private final String checksumXXHASH64;

    private final String checksumXXHASH3;

    private final String checksumXXHASH128;

    private final String checksumType;

    private final String serverSideEncryption;

    private final String requestCharged;

    private PutObjectAnnotationResponse(BuilderImpl builder) {
        super(builder);
        this.key = builder.key;
        this.annotationName = builder.annotationName;
        this.objectVersionId = builder.objectVersionId;
        this.eTag = builder.eTag;
        this.checksumCRC32 = builder.checksumCRC32;
        this.checksumCRC32C = builder.checksumCRC32C;
        this.checksumCRC64NVME = builder.checksumCRC64NVME;
        this.checksumSHA1 = builder.checksumSHA1;
        this.checksumSHA256 = builder.checksumSHA256;
        this.checksumSHA512 = builder.checksumSHA512;
        this.checksumMD5 = builder.checksumMD5;
        this.checksumXXHASH64 = builder.checksumXXHASH64;
        this.checksumXXHASH3 = builder.checksumXXHASH3;
        this.checksumXXHASH128 = builder.checksumXXHASH128;
        this.checksumType = builder.checksumType;
        this.serverSideEncryption = builder.serverSideEncryption;
        this.requestCharged = builder.requestCharged;
    }

    /**
     * <p>
     * The object key.
     * </p>
     * 
     * @return The object key.
     */
    public final String key() {
        return key;
    }

    /**
     * <p>
     * The name of the annotation.
     * </p>
     * 
     * @return The name of the annotation.
     */
    public final String annotationName() {
        return annotationName;
    }

    /**
     * <p>
     * The version ID of the object that the annotation was attached to.
     * </p>
     * 
     * @return The version ID of the object that the annotation was attached to.
     */
    public final String objectVersionId() {
        return objectVersionId;
    }

    /**
     * <p>
     * The entity tag of the annotation.
     * </p>
     * 
     * @return The entity tag of the annotation.
     */
    public final String eTag() {
        return eTag;
    }

    /**
     * <p>
     * The CRC32 checksum of the stored annotation.
     * </p>
     * 
     * @return The CRC32 checksum of the stored annotation.
     */
    public final String checksumCRC32() {
        return checksumCRC32;
    }

    /**
     * <p>
     * The CRC32C checksum of the stored annotation.
     * </p>
     * 
     * @return The CRC32C checksum of the stored annotation.
     */
    public final String checksumCRC32C() {
        return checksumCRC32C;
    }

    /**
     * <p>
     * The CRC64NVME checksum of the stored annotation.
     * </p>
     * 
     * @return The CRC64NVME checksum of the stored annotation.
     */
    public final String checksumCRC64NVME() {
        return checksumCRC64NVME;
    }

    /**
     * <p>
     * The SHA1 checksum of the stored annotation.
     * </p>
     * 
     * @return The SHA1 checksum of the stored annotation.
     */
    public final String checksumSHA1() {
        return checksumSHA1;
    }

    /**
     * <p>
     * The SHA256 checksum of the stored annotation.
     * </p>
     * 
     * @return The SHA256 checksum of the stored annotation.
     */
    public final String checksumSHA256() {
        return checksumSHA256;
    }

    /**
     * <p>
     * The SHA512 checksum of the stored annotation.
     * </p>
     * 
     * @return The SHA512 checksum of the stored annotation.
     */
    public final String checksumSHA512() {
        return checksumSHA512;
    }

    /**
     * <p>
     * The MD5 checksum of the stored annotation.
     * </p>
     * 
     * @return The MD5 checksum of the stored annotation.
     */
    public final String checksumMD5() {
        return checksumMD5;
    }

    /**
     * <p>
     * The XXHASH64 checksum of the stored annotation.
     * </p>
     * 
     * @return The XXHASH64 checksum of the stored annotation.
     */
    public final String checksumXXHASH64() {
        return checksumXXHASH64;
    }

    /**
     * <p>
     * The XXHASH3 checksum of the stored annotation.
     * </p>
     * 
     * @return The XXHASH3 checksum of the stored annotation.
     */
    public final String checksumXXHASH3() {
        return checksumXXHASH3;
    }

    /**
     * <p>
     * The XXHASH128 checksum of the stored annotation.
     * </p>
     * 
     * @return The XXHASH128 checksum of the stored annotation.
     */
    public final String checksumXXHASH128() {
        return checksumXXHASH128;
    }

    /**
     * <p>
     * The type of checksum used.
     * </p>
     * <p>
     * If the service returns an enum value that is not available in the current SDK version, {@link #checksumType} will
     * return {@link ChecksumType#UNKNOWN_TO_SDK_VERSION}. The raw value returned by the service is available from
     * {@link #checksumTypeAsString}.
     * </p>
     * 
     * @return The type of checksum used.
     * @see ChecksumType
     */
    public final ChecksumType checksumType() {
        return ChecksumType.fromValue(checksumType);
    }

    /**
     * <p>
     * The type of checksum used.
     * </p>
     * <p>
     * If the service returns an enum value that is not available in the current SDK version, {@link #checksumType} will
     * return {@link ChecksumType#UNKNOWN_TO_SDK_VERSION}. The raw value returned by the service is available from
     * {@link #checksumTypeAsString}.
     * </p>
     * 
     * @return The type of checksum used.
     * @see ChecksumType
     */
    public final String checksumTypeAsString() {
        return checksumType;
    }

    /**
     * <p>
     * The server-side encryption algorithm used to encrypt the annotation.
     * </p>
     * <p>
     * If the service returns an enum value that is not available in the current SDK version,
     * {@link #serverSideEncryption} will return {@link ServerSideEncryption#UNKNOWN_TO_SDK_VERSION}. The raw value
     * returned by the service is available from {@link #serverSideEncryptionAsString}.
     * </p>
     * 
     * @return The server-side encryption algorithm used to encrypt the annotation.
     * @see ServerSideEncryption
     */
    public final ServerSideEncryption serverSideEncryption() {
        return ServerSideEncryption.fromValue(serverSideEncryption);
    }

    /**
     * <p>
     * The server-side encryption algorithm used to encrypt the annotation.
     * </p>
     * <p>
     * If the service returns an enum value that is not available in the current SDK version,
     * {@link #serverSideEncryption} will return {@link ServerSideEncryption#UNKNOWN_TO_SDK_VERSION}. The raw value
     * returned by the service is available from {@link #serverSideEncryptionAsString}.
     * </p>
     * 
     * @return The server-side encryption algorithm used to encrypt the annotation.
     * @see ServerSideEncryption
     */
    public final String serverSideEncryptionAsString() {
        return serverSideEncryption;
    }

    /**
     * Returns the value of the RequestCharged property for this object.
     * <p>
     * If the service returns an enum value that is not available in the current SDK version, {@link #requestCharged}
     * will return {@link RequestCharged#UNKNOWN_TO_SDK_VERSION}. The raw value returned by the service is available
     * from {@link #requestChargedAsString}.
     * </p>
     * 
     * @return The value of the RequestCharged property for this object.
     * @see RequestCharged
     */
    public final RequestCharged requestCharged() {
        return RequestCharged.fromValue(requestCharged);
    }

    /**
     * Returns the value of the RequestCharged property for this object.
     * <p>
     * If the service returns an enum value that is not available in the current SDK version, {@link #requestCharged}
     * will return {@link RequestCharged#UNKNOWN_TO_SDK_VERSION}. The raw value returned by the service is available
     * from {@link #requestChargedAsString}.
     * </p>
     * 
     * @return The value of the RequestCharged property for this object.
     * @see RequestCharged
     */
    public final String requestChargedAsString() {
        return requestCharged;
    }

    @Override
    public Builder toBuilder() {
        return new BuilderImpl(this);
    }

    public static Builder builder() {
        return new BuilderImpl();
    }

    public static Class<? extends Builder> serializableBuilderClass() {
        return BuilderImpl.class;
    }

    @Override
    public final int hashCode() {
        int hashCode = 1;
        hashCode = 31 * hashCode + super.hashCode();
        hashCode = 31 * hashCode + Objects.hashCode(key());
        hashCode = 31 * hashCode + Objects.hashCode(annotationName());
        hashCode = 31 * hashCode + Objects.hashCode(objectVersionId());
        hashCode = 31 * hashCode + Objects.hashCode(eTag());
        hashCode = 31 * hashCode + Objects.hashCode(checksumCRC32());
        hashCode = 31 * hashCode + Objects.hashCode(checksumCRC32C());
        hashCode = 31 * hashCode + Objects.hashCode(checksumCRC64NVME());
        hashCode = 31 * hashCode + Objects.hashCode(checksumSHA1());
        hashCode = 31 * hashCode + Objects.hashCode(checksumSHA256());
        hashCode = 31 * hashCode + Objects.hashCode(checksumSHA512());
        hashCode = 31 * hashCode + Objects.hashCode(checksumMD5());
        hashCode = 31 * hashCode + Objects.hashCode(checksumXXHASH64());
        hashCode = 31 * hashCode + Objects.hashCode(checksumXXHASH3());
        hashCode = 31 * hashCode + Objects.hashCode(checksumXXHASH128());
        hashCode = 31 * hashCode + Objects.hashCode(checksumTypeAsString());
        hashCode = 31 * hashCode + Objects.hashCode(serverSideEncryptionAsString());
        hashCode = 31 * hashCode + Objects.hashCode(requestChargedAsString());
        return hashCode;
    }

    @Override
    public final boolean equals(Object obj) {
        return super.equals(obj) && equalsBySdkFields(obj);
    }

    @Override
    public final boolean equalsBySdkFields(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (!(obj instanceof PutObjectAnnotationResponse)) {
            return false;
        }
        PutObjectAnnotationResponse other = (PutObjectAnnotationResponse) obj;
        return Objects.equals(key(), other.key()) && Objects.equals(annotationName(), other.annotationName())
                && Objects.equals(objectVersionId(), other.objectVersionId()) && Objects.equals(eTag(), other.eTag())
                && Objects.equals(checksumCRC32(), other.checksumCRC32())
                && Objects.equals(checksumCRC32C(), other.checksumCRC32C())
                && Objects.equals(checksumCRC64NVME(), other.checksumCRC64NVME())
                && Objects.equals(checksumSHA1(), other.checksumSHA1())
                && Objects.equals(checksumSHA256(), other.checksumSHA256())
                && Objects.equals(checksumSHA512(), other.checksumSHA512()) && Objects.equals(checksumMD5(), other.checksumMD5())
                && Objects.equals(checksumXXHASH64(), other.checksumXXHASH64())
                && Objects.equals(checksumXXHASH3(), other.checksumXXHASH3())
                && Objects.equals(checksumXXHASH128(), other.checksumXXHASH128())
                && Objects.equals(checksumTypeAsString(), other.checksumTypeAsString())
                && Objects.equals(serverSideEncryptionAsString(), other.serverSideEncryptionAsString())
                && Objects.equals(requestChargedAsString(), other.requestChargedAsString());
    }

    /**
     * Returns a string representation of this object. This is useful for testing and debugging. Sensitive data will be
     * redacted from this string using a placeholder value.
     */
    @Override
    public final String toString() {
        return ToString.builder("PutObjectAnnotationResponse").add("Key", key()).add("AnnotationName", annotationName())
                .add("ObjectVersionId", objectVersionId()).add("ETag", eTag()).add("ChecksumCRC32", checksumCRC32())
                .add("ChecksumCRC32C", checksumCRC32C()).add("ChecksumCRC64NVME", checksumCRC64NVME())
                .add("ChecksumSHA1", checksumSHA1()).add("ChecksumSHA256", checksumSHA256())
                .add("ChecksumSHA512", checksumSHA512()).add("ChecksumMD5", checksumMD5())
                .add("ChecksumXXHASH64", checksumXXHASH64()).add("ChecksumXXHASH3", checksumXXHASH3())
                .add("ChecksumXXHASH128", checksumXXHASH128()).add("ChecksumType", checksumTypeAsString())
                .add("ServerSideEncryption", serverSideEncryptionAsString()).add("RequestCharged", requestChargedAsString())
                .build();
    }

    public final <T> Optional<T> getValueForField(String fieldName, Class<T> clazz) {
        switch (fieldName) {
        case "Key":
            return Optional.ofNullable(clazz.cast(key()));
        case "AnnotationName":
            return Optional.ofNullable(clazz.cast(annotationName()));
        case "ObjectVersionId":
            return Optional.ofNullable(clazz.cast(objectVersionId()));
        case "ETag":
            return Optional.ofNullable(clazz.cast(eTag()));
        case "ChecksumCRC32":
            return Optional.ofNullable(clazz.cast(checksumCRC32()));
        case "ChecksumCRC32C":
            return Optional.ofNullable(clazz.cast(checksumCRC32C()));
        case "ChecksumCRC64NVME":
            return Optional.ofNullable(clazz.cast(checksumCRC64NVME()));
        case "ChecksumSHA1":
            return Optional.ofNullable(clazz.cast(checksumSHA1()));
        case "ChecksumSHA256":
            return Optional.ofNullable(clazz.cast(checksumSHA256()));
        case "ChecksumSHA512":
            return Optional.ofNullable(clazz.cast(checksumSHA512()));
        case "ChecksumMD5":
            return Optional.ofNullable(clazz.cast(checksumMD5()));
        case "ChecksumXXHASH64":
            return Optional.ofNullable(clazz.cast(checksumXXHASH64()));
        case "ChecksumXXHASH3":
            return Optional.ofNullable(clazz.cast(checksumXXHASH3()));
        case "ChecksumXXHASH128":
            return Optional.ofNullable(clazz.cast(checksumXXHASH128()));
        case "ChecksumType":
            return Optional.ofNullable(clazz.cast(checksumTypeAsString()));
        case "ServerSideEncryption":
            return Optional.ofNullable(clazz.cast(serverSideEncryptionAsString()));
        case "RequestCharged":
            return Optional.ofNullable(clazz.cast(requestChargedAsString()));
        default:
            return Optional.empty();
        }
    }

    @Override
    public final List<SdkField<?>> sdkFields() {
        return SDK_FIELDS;
    }

    @Override
    public final Map<String, SdkField<?>> sdkFieldNameToField() {
        return SDK_NAME_TO_FIELD;
    }

    private static Map<String, SdkField<?>> memberNameToFieldInitializer() {
        Map<String, SdkField<?>> map = new HashMap<>();
        map.put("Key", KEY_FIELD);
        map.put("AnnotationName", ANNOTATION_NAME_FIELD);
        map.put("x-amz-object-version-id", OBJECT_VERSION_ID_FIELD);
        map.put("ETag", E_TAG_FIELD);
        map.put("x-amz-checksum-crc32", CHECKSUM_CRC32_FIELD);
        map.put("x-amz-checksum-crc32c", CHECKSUM_CRC32_C_FIELD);
        map.put("x-amz-checksum-crc64nvme", CHECKSUM_CRC64_NVME_FIELD);
        map.put("x-amz-checksum-sha1", CHECKSUM_SHA1_FIELD);
        map.put("x-amz-checksum-sha256", CHECKSUM_SHA256_FIELD);
        map.put("x-amz-checksum-sha512", CHECKSUM_SHA512_FIELD);
        map.put("x-amz-checksum-md5", CHECKSUM_MD5_FIELD);
        map.put("x-amz-checksum-xxhash64", CHECKSUM_XXHASH64_FIELD);
        map.put("x-amz-checksum-xxhash3", CHECKSUM_XXHASH3_FIELD);
        map.put("x-amz-checksum-xxhash128", CHECKSUM_XXHASH128_FIELD);
        map.put("x-amz-checksum-type", CHECKSUM_TYPE_FIELD);
        map.put("x-amz-server-side-encryption", SERVER_SIDE_ENCRYPTION_FIELD);
        map.put("x-amz-request-charged", REQUEST_CHARGED_FIELD);
        return Collections.unmodifiableMap(map);
    }

    private static <T> Function<Object, T> getter(Function<PutObjectAnnotationResponse, T> g) {
        return obj -> g.apply((PutObjectAnnotationResponse) obj);
    }

    private static <T> BiConsumer<Object, T> setter(BiConsumer<Builder, T> s) {
        return (obj, val) -> s.accept((Builder) obj, val);
    }

    @Mutable
    @NotThreadSafe
    public interface Builder extends S3Response.Builder, SdkPojo, CopyableBuilder<Builder, PutObjectAnnotationResponse> {
        /**
         * <p>
         * The object key.
         * </p>
         * 
         * @param key
         *        The object key.
         * @return Returns a reference to this object so that method calls can be chained together.
         */
        Builder key(String key);

        /**
         * <p>
         * The name of the annotation.
         * </p>
         * 
         * @param annotationName
         *        The name of the annotation.
         * @return Returns a reference to this object so that method calls can be chained together.
         */
        Builder annotationName(String annotationName);

        /**
         * <p>
         * The version ID of the object that the annotation was attached to.
         * </p>
         * 
         * @param objectVersionId
         *        The version ID of the object that the annotation was attached to.
         * @return Returns a reference to this object so that method calls can be chained together.
         */
        Builder objectVersionId(String objectVersionId);

        /**
         * <p>
         * The entity tag of the annotation.
         * </p>
         * 
         * @param eTag
         *        The entity tag of the annotation.
         * @return Returns a reference to this object so that method calls can be chained together.
         */
        Builder eTag(String eTag);

        /**
         * <p>
         * The CRC32 checksum of the stored annotation.
         * </p>
         * 
         * @param checksumCRC32
         *        The CRC32 checksum of the stored annotation.
         * @return Returns a reference to this object so that method calls can be chained together.
         */
        Builder checksumCRC32(String checksumCRC32);

        /**
         * <p>
         * The CRC32C checksum of the stored annotation.
         * </p>
         * 
         * @param checksumCRC32C
         *        The CRC32C checksum of the stored annotation.
         * @return Returns a reference to this object so that method calls can be chained together.
         */
        Builder checksumCRC32C(String checksumCRC32C);

        /**
         * <p>
         * The CRC64NVME checksum of the stored annotation.
         * </p>
         * 
         * @param checksumCRC64NVME
         *        The CRC64NVME checksum of the stored annotation.
         * @return Returns a reference to this object so that method calls can be chained together.
         */
        Builder checksumCRC64NVME(String checksumCRC64NVME);

        /**
         * <p>
         * The SHA1 checksum of the stored annotation.
         * </p>
         * 
         * @param checksumSHA1
         *        The SHA1 checksum of the stored annotation.
         * @return Returns a reference to this object so that method calls can be chained together.
         */
        Builder checksumSHA1(String checksumSHA1);

        /**
         * <p>
         * The SHA256 checksum of the stored annotation.
         * </p>
         * 
         * @param checksumSHA256
         *        The SHA256 checksum of the stored annotation.
         * @return Returns a reference to this object so that method calls can be chained together.
         */
        Builder checksumSHA256(String checksumSHA256);

        /**
         * <p>
         * The SHA512 checksum of the stored annotation.
         * </p>
         * 
         * @param checksumSHA512
         *        The SHA512 checksum of the stored annotation.
         * @return Returns a reference to this object so that method calls can be chained together.
         */
        Builder checksumSHA512(String checksumSHA512);

        /**
         * <p>
         * The MD5 checksum of the stored annotation.
         * </p>
         * 
         * @param checksumMD5
         *        The MD5 checksum of the stored annotation.
         * @return Returns a reference to this object so that method calls can be chained together.
         */
        Builder checksumMD5(String checksumMD5);

        /**
         * <p>
         * The XXHASH64 checksum of the stored annotation.
         * </p>
         * 
         * @param checksumXXHASH64
         *        The XXHASH64 checksum of the stored annotation.
         * @return Returns a reference to this object so that method calls can be chained together.
         */
        Builder checksumXXHASH64(String checksumXXHASH64);

        /**
         * <p>
         * The XXHASH3 checksum of the stored annotation.
         * </p>
         * 
         * @param checksumXXHASH3
         *        The XXHASH3 checksum of the stored annotation.
         * @return Returns a reference to this object so that method calls can be chained together.
         */
        Builder checksumXXHASH3(String checksumXXHASH3);

        /**
         * <p>
         * The XXHASH128 checksum of the stored annotation.
         * </p>
         * 
         * @param checksumXXHASH128
         *        The XXHASH128 checksum of the stored annotation.
         * @return Returns a reference to this object so that method calls can be chained together.
         */
        Builder checksumXXHASH128(String checksumXXHASH128);

        /**
         * <p>
         * The type of checksum used.
         * </p>
         * 
         * @param checksumType
         *        The type of checksum used.
         * @see ChecksumType
         * @return Returns a reference to this object so that method calls can be chained together.
         * @see ChecksumType
         */
        Builder checksumType(String checksumType);

        /**
         * <p>
         * The type of checksum used.
         * </p>
         * 
         * @param checksumType
         *        The type of checksum used.
         * @see ChecksumType
         * @return Returns a reference to this object so that method calls can be chained together.
         * @see ChecksumType
         */
        Builder checksumType(ChecksumType checksumType);

        /**
         * <p>
         * The server-side encryption algorithm used to encrypt the annotation.
         * </p>
         * 
         * @param serverSideEncryption
         *        The server-side encryption algorithm used to encrypt the annotation.
         * @see ServerSideEncryption
         * @return Returns a reference to this object so that method calls can be chained together.
         * @see ServerSideEncryption
         */
        Builder serverSideEncryption(String serverSideEncryption);

        /**
         * <p>
         * The server-side encryption algorithm used to encrypt the annotation.
         * </p>
         * 
         * @param serverSideEncryption
         *        The server-side encryption algorithm used to encrypt the annotation.
         * @see ServerSideEncryption
         * @return Returns a reference to this object so that method calls can be chained together.
         * @see ServerSideEncryption
         */
        Builder serverSideEncryption(ServerSideEncryption serverSideEncryption);

        /**
         * Sets the value of the RequestCharged property for this object.
         *
         * @param requestCharged
         *        The new value for the RequestCharged property for this object.
         * @see RequestCharged
         * @return Returns a reference to this object so that method calls can be chained together.
         * @see RequestCharged
         */
        Builder requestCharged(String requestCharged);

        /**
         * Sets the value of the RequestCharged property for this object.
         *
         * @param requestCharged
         *        The new value for the RequestCharged property for this object.
         * @see RequestCharged
         * @return Returns a reference to this object so that method calls can be chained together.
         * @see RequestCharged
         */
        Builder requestCharged(RequestCharged requestCharged);
    }

    static final class BuilderImpl extends S3Response.BuilderImpl implements Builder {
        private String key;

        private String annotationName;

        private String objectVersionId;

        private String eTag;

        private String checksumCRC32;

        private String checksumCRC32C;

        private String checksumCRC64NVME;

        private String checksumSHA1;

        private String checksumSHA256;

        private String checksumSHA512;

        private String checksumMD5;

        private String checksumXXHASH64;

        private String checksumXXHASH3;

        private String checksumXXHASH128;

        private String checksumType;

        private String serverSideEncryption;

        private String requestCharged;

        private BuilderImpl() {
        }

        private BuilderImpl(PutObjectAnnotationResponse model) {
            super(model);
            key(model.key);
            annotationName(model.annotationName);
            objectVersionId(model.objectVersionId);
            eTag(model.eTag);
            checksumCRC32(model.checksumCRC32);
            checksumCRC32C(model.checksumCRC32C);
            checksumCRC64NVME(model.checksumCRC64NVME);
            checksumSHA1(model.checksumSHA1);
            checksumSHA256(model.checksumSHA256);
            checksumSHA512(model.checksumSHA512);
            checksumMD5(model.checksumMD5);
            checksumXXHASH64(model.checksumXXHASH64);
            checksumXXHASH3(model.checksumXXHASH3);
            checksumXXHASH128(model.checksumXXHASH128);
            checksumType(model.checksumType);
            serverSideEncryption(model.serverSideEncryption);
            requestCharged(model.requestCharged);
        }

        public final String getKey() {
            return key;
        }

        public final void setKey(String key) {
            this.key = key;
        }

        @Override
        public final Builder key(String key) {
            this.key = key;
            return this;
        }

        public final String getAnnotationName() {
            return annotationName;
        }

        public final void setAnnotationName(String annotationName) {
            this.annotationName = annotationName;
        }

        @Override
        public final Builder annotationName(String annotationName) {
            this.annotationName = annotationName;
            return this;
        }

        public final String getObjectVersionId() {
            return objectVersionId;
        }

        public final void setObjectVersionId(String objectVersionId) {
            this.objectVersionId = objectVersionId;
        }

        @Override
        public final Builder objectVersionId(String objectVersionId) {
            this.objectVersionId = objectVersionId;
            return this;
        }

        public final String getETag() {
            return eTag;
        }

        public final void setETag(String eTag) {
            this.eTag = eTag;
        }

        @Override
        public final Builder eTag(String eTag) {
            this.eTag = eTag;
            return this;
        }

        public final String getChecksumCRC32() {
            return checksumCRC32;
        }

        public final void setChecksumCRC32(String checksumCRC32) {
            this.checksumCRC32 = checksumCRC32;
        }

        @Override
        public final Builder checksumCRC32(String checksumCRC32) {
            this.checksumCRC32 = checksumCRC32;
            return this;
        }

        public final String getChecksumCRC32C() {
            return checksumCRC32C;
        }

        public final void setChecksumCRC32C(String checksumCRC32C) {
            this.checksumCRC32C = checksumCRC32C;
        }

        @Override
        public final Builder checksumCRC32C(String checksumCRC32C) {
            this.checksumCRC32C = checksumCRC32C;
            return this;
        }

        public final String getChecksumCRC64NVME() {
            return checksumCRC64NVME;
        }

        public final void setChecksumCRC64NVME(String checksumCRC64NVME) {
            this.checksumCRC64NVME = checksumCRC64NVME;
        }

        @Override
        public final Builder checksumCRC64NVME(String checksumCRC64NVME) {
            this.checksumCRC64NVME = checksumCRC64NVME;
            return this;
        }

        public final String getChecksumSHA1() {
            return checksumSHA1;
        }

        public final void setChecksumSHA1(String checksumSHA1) {
            this.checksumSHA1 = checksumSHA1;
        }

        @Override
        public final Builder checksumSHA1(String checksumSHA1) {
            this.checksumSHA1 = checksumSHA1;
            return this;
        }

        public final String getChecksumSHA256() {
            return checksumSHA256;
        }

        public final void setChecksumSHA256(String checksumSHA256) {
            this.checksumSHA256 = checksumSHA256;
        }

        @Override
        public final Builder checksumSHA256(String checksumSHA256) {
            this.checksumSHA256 = checksumSHA256;
            return this;
        }

        public final String getChecksumSHA512() {
            return checksumSHA512;
        }

        public final void setChecksumSHA512(String checksumSHA512) {
            this.checksumSHA512 = checksumSHA512;
        }

        @Override
        public final Builder checksumSHA512(String checksumSHA512) {
            this.checksumSHA512 = checksumSHA512;
            return this;
        }

        public final String getChecksumMD5() {
            return checksumMD5;
        }

        public final void setChecksumMD5(String checksumMD5) {
            this.checksumMD5 = checksumMD5;
        }

        @Override
        public final Builder checksumMD5(String checksumMD5) {
            this.checksumMD5 = checksumMD5;
            return this;
        }

        public final String getChecksumXXHASH64() {
            return checksumXXHASH64;
        }

        public final void setChecksumXXHASH64(String checksumXXHASH64) {
            this.checksumXXHASH64 = checksumXXHASH64;
        }

        @Override
        public final Builder checksumXXHASH64(String checksumXXHASH64) {
            this.checksumXXHASH64 = checksumXXHASH64;
            return this;
        }

        public final String getChecksumXXHASH3() {
            return checksumXXHASH3;
        }

        public final void setChecksumXXHASH3(String checksumXXHASH3) {
            this.checksumXXHASH3 = checksumXXHASH3;
        }

        @Override
        public final Builder checksumXXHASH3(String checksumXXHASH3) {
            this.checksumXXHASH3 = checksumXXHASH3;
            return this;
        }

        public final String getChecksumXXHASH128() {
            return checksumXXHASH128;
        }

        public final void setChecksumXXHASH128(String checksumXXHASH128) {
            this.checksumXXHASH128 = checksumXXHASH128;
        }

        @Override
        public final Builder checksumXXHASH128(String checksumXXHASH128) {
            this.checksumXXHASH128 = checksumXXHASH128;
            return this;
        }

        public final String getChecksumType() {
            return checksumType;
        }

        public final void setChecksumType(String checksumType) {
            this.checksumType = checksumType;
        }

        @Override
        public final Builder checksumType(String checksumType) {
            this.checksumType = checksumType;
            return this;
        }

        @Override
        public final Builder checksumType(ChecksumType checksumType) {
            this.checksumType(checksumType == null ? null : checksumType.toString());
            return this;
        }

        public final String getServerSideEncryption() {
            return serverSideEncryption;
        }

        public final void setServerSideEncryption(String serverSideEncryption) {
            this.serverSideEncryption = serverSideEncryption;
        }

        @Override
        public final Builder serverSideEncryption(String serverSideEncryption) {
            this.serverSideEncryption = serverSideEncryption;
            return this;
        }

        @Override
        public final Builder serverSideEncryption(ServerSideEncryption serverSideEncryption) {
            this.serverSideEncryption(serverSideEncryption == null ? null : serverSideEncryption.toString());
            return this;
        }

        public final String getRequestCharged() {
            return requestCharged;
        }

        public final void setRequestCharged(String requestCharged) {
            this.requestCharged = requestCharged;
        }

        @Override
        public final Builder requestCharged(String requestCharged) {
            this.requestCharged = requestCharged;
            return this;
        }

        @Override
        public final Builder requestCharged(RequestCharged requestCharged) {
            this.requestCharged(requestCharged == null ? null : requestCharged.toString());
            return this;
        }

        @Override
        public PutObjectAnnotationResponse build() {
            return new PutObjectAnnotationResponse(this);
        }

        @Override
        public List<SdkField<?>> sdkFields() {
            return SDK_FIELDS;
        }

        @Override
        public Map<String, SdkField<?>> sdkFieldNameToField() {
            return SDK_NAME_TO_FIELD;
        }
    }
}
