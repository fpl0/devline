/*
 * Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License").
 * You may not use this file except in compliance with the License.
 * A copy of the License is located at
 *
 *  http://aws.amazon.com/apache2.0
 *
 * or in the "license" file accompanying this file. This file is distributed
 * on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 * express or implied. See the License for the specific language governing
 * permissions and limitations under the License.
 */

package software.amazon.awssdk.services.s3.internal.multipart;

import static software.amazon.awssdk.services.s3.internal.multipart.MultipartUploadHelper.contentLengthMismatchForPart;
import static software.amazon.awssdk.services.s3.internal.multipart.MultipartUploadHelper.partNumMismatch;
import static software.amazon.awssdk.services.s3.multipart.S3MultipartExecutionAttribute.JAVA_PROGRESS_LISTENER;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;
import java.util.concurrent.atomic.AtomicReferenceArray;
import java.util.function.Consumer;
import java.util.stream.IntStream;
import org.reactivestreams.Subscriber;
import org.reactivestreams.Subscription;
import software.amazon.awssdk.annotations.SdkInternalApi;
import software.amazon.awssdk.core.async.AsyncRequestBody;
import software.amazon.awssdk.core.async.CloseableAsyncRequestBody;
import software.amazon.awssdk.core.async.listener.PublisherListener;
import software.amazon.awssdk.core.exception.SdkClientException;
import software.amazon.awssdk.services.s3.model.CompletedPart;
import software.amazon.awssdk.services.s3.model.PutObjectRequest;
import software.amazon.awssdk.services.s3.model.PutObjectResponse;
import software.amazon.awssdk.services.s3.model.UploadPartRequest;
import software.amazon.awssdk.services.s3.multipart.S3ResumeToken;
import software.amazon.awssdk.utils.Logger;
import software.amazon.awssdk.utils.NumericUtils;
import software.amazon.awssdk.utils.Pair;
import software.amazon.awssdk.utils.Validate;

@SdkInternalApi
public class KnownContentLengthAsyncRequestBodySubscriber implements Subscriber<CloseableAsyncRequestBody> {

    private static final Logger log = Logger.loggerFor(KnownContentLengthAsyncRequestBodySubscriber.class);

    /**
     * The number of AsyncRequestBody has been received but yet to be processed
     */
    private final AtomicInteger asyncRequestBodyInFlight = new AtomicInteger(0);
    private final AtomicInteger partNumber = new AtomicInteger(1);
    private final MultipartUploadHelper multipartUploadHelper;
    private final long totalSize;
    private final long partSize;
    private final int expectedNumParts;
    private final int existingNumParts;
    private final String uploadId;
    private final Collection<CompletableFuture<CompletedPart>> futures = new ConcurrentLinkedQueue<>();
    private final PutObjectRequest putObjectRequest;
    private final CompletableFuture<PutObjectResponse> returnFuture;
    private final AtomicReferenceArray<CompletedPart> completedParts;
    private final Map<Integer, CompletedPart> existingParts;
    private final PublisherListener<Long> progressListener;
    private final int maxInFlightParts;
    private final Object subscriptionLock = new Object();
    private Subscription subscription;
    private volatile boolean isDone;
    /**
     * Tracks whether pause can return a resume token. Once CompleteMultipartUpload starts, the state remains COMPLETING even if
     * it later fails because S3 may already have processed the request.
     */
    private final AtomicReference<State> state = new AtomicReference<>(State.RUNNING);

    KnownContentLengthAsyncRequestBodySubscriber(MpuRequestContext mpuRequestContext,
            CompletableFuture<PutObjectResponse> returnFuture,
            MultipartUploadHelper multipartUploadHelper,
            int maxInFlightParts) {
        this.totalSize = mpuRequestContext.contentLength();
        this.partSize = mpuRequestContext.partSize();
        this.expectedNumParts = mpuRequestContext.expectedNumParts();
        this.putObjectRequest = mpuRequestContext.request().left();
        this.returnFuture = returnFuture;
        this.uploadId = mpuRequestContext.uploadId();
        this.existingParts = mpuRequestContext.existingParts() == null ? new HashMap<>() : mpuRequestContext.existingParts();
        this.existingNumParts = NumericUtils.saturatedCast(mpuRequestContext.numPartsCompleted());
        this.completedParts = new AtomicReferenceArray<>(expectedNumParts);
        this.multipartUploadHelper = multipartUploadHelper;
        this.maxInFlightParts = maxInFlightParts;
        this.progressListener = putObjectRequest.overrideConfiguration()
                                                .map(c -> c.executionAttributes()
                                                           .getAttribute(JAVA_PROGRESS_LISTENER))
                                                .orElseGet(PublisherListener::noOp);
    }

    public S3ResumeToken pause() {
        if (state.compareAndSet(State.RUNNING, State.PAUSED)) {
            for (CompletableFuture<CompletedPart> cf : futures) {
                if (!cf.isDone()) {
                    cf.cancel(true);
                }
            }
            // Part failures are not handled after a pause, so nothing else would complete the upload.
            returnFuture.cancel(true);
            return resumeToken();
        }

        if (state.get() == State.FAILING) {
            // The automatic abort may not have reached S3, for example during a network outage, so the upload may still
            // be resumable.
            return resumeToken();
        }

        log.debug(() -> "The upload was already paused or initiated CompleteMultipartUpload.");
        return null;
    }

    private S3ResumeToken resumeToken() {
        long numPartsCompleted = futures.stream().filter(f -> f.isDone() && !f.isCompletedExceptionally()).count();
        return S3ResumeToken.builder()
                            .uploadId(uploadId)
                            .partSize(partSize)
                            .totalNumParts((long) expectedNumParts)
                            .numPartsCompleted(numPartsCompleted + existingNumParts)
                            .build();
    }

    @Override
    public void onSubscribe(Subscription s) {
        Validate.paramNotNull(s, "subscription");
        if (this.subscription != null) {
            log.warn(() -> "The subscriber has already been subscribed. Cancelling the incoming subscription");
            s.cancel();
            return;
        }
        this.subscription = s;
        s.request(maxInFlightParts);
        returnFuture.whenComplete((r, t) -> {
            if (t != null) {
                s.cancel();
                // Abort if this failure claims a running upload, or if CompleteMultipartUpload is in flight. In the second case
                // the state stays COMPLETING so that pause() returns no token, because S3 may already have completed the upload.
                if (tryMarkFailing() || state.get() == State.COMPLETING) {
                    multipartUploadHelper.failRequestsElegantly(futures, t, uploadId, returnFuture, putObjectRequest);
                }
            }
        });
    }

    @Override
    public void onNext(CloseableAsyncRequestBody asyncRequestBody) {
        if (state.get() != State.RUNNING || isDone) {
            discard(asyncRequestBody);
            return;
        }

        int currentPartNum = partNumber.getAndIncrement();

        log.debug(() -> String.format("Received asyncRequestBody for part number %d with length %s", currentPartNum,
                asyncRequestBody.contentLength()));

        if (existingParts.containsKey(currentPartNum)) {
            asyncRequestBody.subscribe(new CancelledSubscriber<>());
            asyncRequestBody.contentLength().ifPresent(progressListener::subscriberOnNext);
            asyncRequestBody.close();

            synchronized (subscriptionLock) {
                subscription.request(1);
            }
            return;
        }

        Optional<SdkClientException> sdkClientException = validatePart(asyncRequestBody, currentPartNum);
        if (sdkClientException.isPresent()) {
            if (tryMarkFailing()) {
                multipartUploadHelper.failRequestsElegantly(futures,
                        sdkClientException.get(),
                        uploadId,
                        returnFuture,
                        putObjectRequest);
            }
            discard(asyncRequestBody);
            subscription.cancel();
            return;
        }

        asyncRequestBodyInFlight.incrementAndGet();
        UploadPartRequest uploadRequest = SdkPojoConversionUtils.toUploadPartRequest(putObjectRequest,
                                                                                     currentPartNum,
                                                                                     uploadId);

        Consumer<CompletedPart> completedPartConsumer = completedPart -> completedParts.set(
            completedPart.partNumber() - 1,
            completedPart);
        CompletableFuture<CompletedPart> partFuture = multipartUploadHelper.sendIndividualUploadPartRequest(
            uploadId, completedPartConsumer, futures, Pair.of(uploadRequest, asyncRequestBody), progressListener);
        partFuture.whenComplete((r, t) -> {
            asyncRequestBody.close();
            if (t != null) {
                if (tryMarkFailing()) {
                    multipartUploadHelper.failRequestsElegantly(futures, t, uploadId, returnFuture,
                                                                putObjectRequest);
                    subscription.cancel();
                }
            } else {
                int inFlight = asyncRequestBodyInFlight.decrementAndGet();
                if (!isDone && inFlight < maxInFlightParts) {
                    synchronized (subscriptionLock) {
                        subscription.request(1);
                    }
                }
                completeMultipartUploadIfFinished();
            }
        });

        // A pause or failure that ran before this part's future was registered could not cancel it.
        if (state.get() != State.RUNNING) {
            partFuture.cancel(true);
        }
    }

    private Optional<SdkClientException> validatePart(AsyncRequestBody asyncRequestBody, int currentPartNum) {
        if (!asyncRequestBody.contentLength().isPresent()) {
            return Optional.of(MultipartUploadHelper.contentLengthMissingForPart(currentPartNum));
        }

        Long currentPartSize = asyncRequestBody.contentLength().get();

        if (currentPartNum > expectedNumParts) {
            return Optional.of(partNumMismatch(expectedNumParts, currentPartNum));
        }

        if (currentPartNum == expectedNumParts) {
            return validateLastPartSize(currentPartSize);
        }

        if (currentPartSize != partSize) {
            return Optional.of(contentLengthMismatchForPart(partSize, currentPartSize, currentPartNum));
        }
        return Optional.empty();
    }

    private Optional<SdkClientException> validateLastPartSize(Long currentPartSize) {
        long remainder = totalSize % partSize;
        long expectedLastPartSize = remainder == 0 ? partSize : remainder;
        if (currentPartSize != expectedLastPartSize) {
            return Optional.of(
                SdkClientException.create("Content length of the last part must be equal to the "
                                          + "expected last part size. Expected: " + expectedLastPartSize
                                          + ", Actual: " + currentPartSize));
        }
        return Optional.empty();
    }

    private static void discard(CloseableAsyncRequestBody asyncRequestBody) {
        asyncRequestBody.subscribe(new CancelledSubscriber<>());
        asyncRequestBody.close();
    }

    private boolean tryMarkFailing() {
        return state.compareAndSet(State.RUNNING, State.FAILING);
    }

    @Override
    public void onError(Throwable t) {
        log.debug(() -> "Received onError ", t);
        if (tryMarkFailing()) {
            isDone = true;
            multipartUploadHelper.failRequestsElegantly(futures, t, uploadId, returnFuture, putObjectRequest);
        }
    }

    @Override
    public void onComplete() {
        log.debug(() -> "Received onComplete()");
        isDone = true;
        completeMultipartUploadIfFinished();
    }

    private void completeMultipartUploadIfFinished() {
        // All atomics including asyncRequestBodyInFlight MUST be re-read here rather than passed in by the caller.
        if (isDone && asyncRequestBodyInFlight.get() == 0 && state.compareAndSet(State.RUNNING, State.COMPLETING)) {
            CompletedPart[] parts;

            if (existingParts.isEmpty()) {
                parts = IntStream.range(0, completedParts.length())
                        .mapToObj(completedParts::get)
                        .toArray(CompletedPart[]::new);
            } else {
                // List of CompletedParts needs to be in ascending order
                parts = mergeCompletedParts();
            }

            int actualNumParts = partNumber.get() - 1;
            if (actualNumParts != expectedNumParts) {
                SdkClientException exception = partNumMismatch(expectedNumParts, actualNumParts);
                state.set(State.FAILING);
                multipartUploadHelper.failRequestsElegantly(futures, exception, uploadId, returnFuture, putObjectRequest);
                return;
            }

            multipartUploadHelper.completeMultipartUpload(returnFuture, uploadId, parts, putObjectRequest, totalSize);
        }
    }

    private CompletedPart[] mergeCompletedParts() {
        CompletedPart[] merged = new CompletedPart[expectedNumParts];
        int currPart = 1;
        while (currPart < expectedNumParts + 1) {
            CompletedPart completedPart = existingParts.containsKey(currPart) ? existingParts.get(currPart)
                                                                              : completedParts.get(currPart - 1);
            merged[currPart - 1] = completedPart;
            currPart++;
        }
        return merged;
    }

    private enum State {
        RUNNING,
        PAUSED,
        COMPLETING,
        FAILING
    }
}
