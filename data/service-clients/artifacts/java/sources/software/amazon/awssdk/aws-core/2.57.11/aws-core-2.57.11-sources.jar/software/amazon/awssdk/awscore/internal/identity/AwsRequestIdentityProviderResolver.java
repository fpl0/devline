/*
 * Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License").
 * You may not use this file except in compliance with the License.
 * A copy of the License is located at
 *
 *  http://aws.amazon.com/apache2.0
 *
 * or in the "license" file accompanying this file. This file is distributed
 * on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 * express or implied. See the License for the specific language governing
 * permissions and limitations under the License.
 */

package software.amazon.awssdk.awscore.internal.identity;

import software.amazon.awssdk.annotations.SdkInternalApi;
import software.amazon.awssdk.auth.credentials.AwsCredentials;
import software.amazon.awssdk.auth.credentials.StaticCredentialsProvider;
import software.amazon.awssdk.auth.signer.AwsSignerExecutionAttribute;
import software.amazon.awssdk.awscore.AwsRequestOverrideConfiguration;
import software.amazon.awssdk.core.SdkRequest;
import software.amazon.awssdk.core.interceptor.ExecutionAttributes;
import software.amazon.awssdk.core.spi.identity.RequestIdentityProviderResolver;
import software.amazon.awssdk.identity.spi.IdentityProviders;

/**
 * AWS implementation of {@link RequestIdentityProviderResolver} that reads credential overrides
 * from {@link AwsRequestOverrideConfiguration} and deprecated {@link AwsSignerExecutionAttribute#AWS_CREDENTIALS}.
 */
@SdkInternalApi
public final class AwsRequestIdentityProviderResolver implements RequestIdentityProviderResolver {

    private static final AwsRequestIdentityProviderResolver INSTANCE = new AwsRequestIdentityProviderResolver();

    private AwsRequestIdentityProviderResolver() {
    }

    public static AwsRequestIdentityProviderResolver create() {
        return INSTANCE;
    }

    @Override
    public IdentityProviders resolve(SdkRequest request, IdentityProviders base, ExecutionAttributes executionAttributes) {
        if (base == null) {
            return null;
        }

        IdentityProviders resolvedProviders = request.overrideConfiguration()
            .filter(c -> c instanceof AwsRequestOverrideConfiguration)
            .map(c -> (AwsRequestOverrideConfiguration) c)
            .map(c -> base.copy(b -> {
                c.credentialsIdentityProvider().ifPresent(b::putIdentityProvider);
                c.tokenIdentityProvider().ifPresent(b::putIdentityProvider);
            }))
            .orElse(null);

        if (resolvedProviders != null) {
            return resolvedProviders;
        }

        // Support deprecated AWS_CREDENTIALS execution attribute for backwards compatibility
        // with interceptors that set credentials via AwsSignerExecutionAttribute.AWS_CREDENTIALS
        AwsCredentials credentials = executionAttributes.getOptionalAttribute(AwsSignerExecutionAttribute.AWS_CREDENTIALS)
                                                        .orElse(null);
        if (credentials != null) {
            return base.copy(b -> b.putIdentityProvider(StaticCredentialsProvider.create(credentials)));
        }

        return base;
    }
}
