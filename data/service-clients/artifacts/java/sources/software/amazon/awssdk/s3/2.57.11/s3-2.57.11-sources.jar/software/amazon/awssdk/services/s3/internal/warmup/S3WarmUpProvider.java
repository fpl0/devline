/*
 * Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"). You may not use this file except in compliance with
 * the License. A copy of the License is located at
 * 
 * http://aws.amazon.com/apache2.0
 * 
 * or in the "license" file accompanying this file. This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
 * CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions
 * and limitations under the License.
 */

package software.amazon.awssdk.services.s3.internal.warmup;

import java.net.URI;
import java.nio.charset.StandardCharsets;
import software.amazon.awssdk.annotations.Generated;
import software.amazon.awssdk.annotations.SdkInternalApi;
import software.amazon.awssdk.auth.credentials.AnonymousCredentialsProvider;
import software.amazon.awssdk.core.ClientType;
import software.amazon.awssdk.core.warmup.SdkWarmUpProvider;
import software.amazon.awssdk.core.warmup.http.CannedResponseAsyncHttpClient;
import software.amazon.awssdk.core.warmup.http.CannedResponseHttpClient;
import software.amazon.awssdk.http.SdkHttpClient;
import software.amazon.awssdk.http.async.SdkAsyncHttpClient;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.s3.S3AsyncClient;
import software.amazon.awssdk.services.s3.S3Client;

@Generated("software.amazon.awssdk:codegen")
@SdkInternalApi
public final class S3WarmUpProvider implements SdkWarmUpProvider {
    private static final byte[] CANNED_RESPONSE = "<Response/>".getBytes(StandardCharsets.UTF_8);

    @Override
    public String syncClientClassName() {
        return "software.amazon.awssdk.services.s3.S3Client";
    }

    @Override
    public String asyncClientClassName() {
        return "software.amazon.awssdk.services.s3.S3AsyncClient";
    }

    @Override
    public void warmUpClient(ClientType clientType) {
        if (clientType == ClientType.SYNC) {
            SdkHttpClient httpClient = CannedResponseHttpClient.builder().responseBody(CANNED_RESPONSE).statusCode(200).build();
            try (S3Client client = S3Client.builder().httpClient(httpClient)
                    .credentialsProvider(AnonymousCredentialsProvider.create()).region(Region.US_EAST_1)
                    .endpointOverride(URI.create("http://localhost")).build()) {
                client.listBuckets();
            }
        }
        if (clientType == ClientType.ASYNC) {
            SdkAsyncHttpClient asyncHttpClient = CannedResponseAsyncHttpClient.builder().responseBody(CANNED_RESPONSE)
                    .statusCode(200).build();
            try (S3AsyncClient asyncClient = S3AsyncClient.builder().httpClient(asyncHttpClient)
                    .credentialsProvider(AnonymousCredentialsProvider.create()).region(Region.US_EAST_1)
                    .endpointOverride(URI.create("http://localhost")).build()) {
                asyncClient.listBuckets().join();
            }
        }
    }
}
