/*
 * oauth2-oidc-sdk
 *
 * Copyright 2012-2021, Connect2id Ltd and contributors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use
 * this file except in compliance with the License. You may obtain a copy of the
 * License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed
 * under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
 * CONDITIONS OF ANY KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations under the License.
 */

package com.nimbusds.oauth2.sdk.dpop.verifiers;


import com.nimbusds.jose.util.Base64URL;
import com.nimbusds.jwt.JWTClaimsSet;
import com.nimbusds.jwt.proc.BadJWTException;
import com.nimbusds.jwt.proc.DefaultJWTClaimsVerifier;
import com.nimbusds.oauth2.sdk.id.JWTID;
import com.nimbusds.oauth2.sdk.util.CollectionUtils;
import com.nimbusds.oauth2.sdk.util.StringUtils;
import com.nimbusds.oauth2.sdk.util.URIUtils;
import com.nimbusds.oauth2.sdk.util.singleuse.AlreadyUsedException;
import com.nimbusds.oauth2.sdk.util.singleuse.SingleUseChecker;
import com.nimbusds.openid.connect.sdk.Nonce;
import net.jcip.annotations.ThreadSafe;

import java.net.URI;
import java.text.ParseException;
import java.util.*;


/**
 * DPoP proof JWT claims set verifier.
 */
@ThreadSafe
class DPoPProofClaimsSetVerifier extends DefaultJWTClaimsVerifier<DPoPProofContext> {


	private final long maxClockSkewSeconds;

	private final long maxAgeSeconds;

	private final Set<Nonce> acceptedNonces;

	private final SingleUseChecker<DPoPProofUse> singleUseChecker;

	@Deprecated
	private final SingleUseChecker<Map.Entry<DPoPIssuer, JWTID>> deprecatedSingleUseChecker;


	/**
	 * Creates a new DPoP proof JWT claims set verifier.
	 *
	 * @param acceptedMethod      The accepted HTTP request method (case-
	 *                            insensitive). Must not be {@code null}.
	 * @param acceptedURI         The accepted endpoint URI. Any query or
	 *                            fragment component will be stripped from
	 *                            it before performing the comparison. Must
	 *                            not be {@code null}.
	 * @param acceptedNonces      The accepted nonce values, {@code null}
	 *                            if none are expected.
	 * @param maxClockSkewSeconds The maximum permitted DPoP proof "iat"
	 *                            clock skew, in seconds. A proof with
	 *                            "iat" in the future is accepted if it is
	 *                            within this skew tolerance. Intended to
	 *                            prevent rejections due to client and
	 *                            server system time differences.
	 * @param maxAgeSeconds       The maximum accepted DPoP proof "iat" age
	 *                            relative to the current system time, in
	 *                            seconds. Intended to limit replay by
	 *                            bounding how long a proof is valid after
	 *                            issue.
	 * @param requireATH          {@code true} to require an "ath" (access
	 *                            token hash) claim.
	 * @param singleUseChecker    The single use checker for the "jti" (JWT
	 *                            ID) claims, {@code null} if not
	 *                            specified.
	 */
	public DPoPProofClaimsSetVerifier(final URI acceptedURI,
					  final String acceptedMethod,
					  final Set<Nonce> acceptedNonces,
					  final long maxClockSkewSeconds,
					  final long maxAgeSeconds,
					  final boolean requireATH,
					  final SingleUseChecker<DPoPProofUse> singleUseChecker) {

		super(null,
			composeExactMatchClaims(acceptedURI, acceptedMethod),
			composedRequiredClaimsWithAnyValue(CollectionUtils.isNotEmpty(acceptedNonces), requireATH),
			composeProhibitedClaims(CollectionUtils.isEmpty(acceptedNonces))
		);

		if (maxAgeSeconds < maxClockSkewSeconds) {
			throw new IllegalArgumentException("The iat max age must be greater than or equal to the iat max clock skew");
		}

		this.maxClockSkewSeconds = maxClockSkewSeconds;
		this.maxAgeSeconds = maxAgeSeconds;

		this.acceptedNonces = CollectionUtils.isNotEmpty(acceptedNonces) ? Collections.unmodifiableSet(acceptedNonces) : null;

		this.singleUseChecker = singleUseChecker;
		this.deprecatedSingleUseChecker = null;
	}


	/**
	 * Creates a new DPoP proof JWT claims set verifier.
	 *
	 * @param acceptedMethod      The accepted HTTP request method (case-
	 *                            insensitive). Must not be {@code null}.
	 * @param acceptedURI         The accepted endpoint URI. Any query or
	 *                            fragment component will be stripped from
	 *                            it before performing the comparison. Must
	 *                            not be {@code null}.
	 * @param acceptedNonces      The accepted nonce values, {@code null}
	 *                            if none are expected.
	 * @param maxClockSkewSeconds The maximum permitted DPoP proof "iat"
	 *                            clock skew, in seconds. A proof with
	 *                            "iat" in the future is accepted if it is
	 *                            within this skew tolerance. Intended to
	 *                            prevent rejections due to client and
	 *                            server system time differences.
	 * @param requireATH          {@code true} to require an "ath" (access
	 *                            token hash) claim.
	 * @param singleUseChecker    The single use checker for the "jti" (JWT
	 *                            ID) claims, {@code null} if not
	 *                            specified.
	 */
	@Deprecated
	public DPoPProofClaimsSetVerifier(final URI acceptedURI,
					  final String acceptedMethod,
					  final Set<Nonce> acceptedNonces,
					  final long maxClockSkewSeconds,
					  final boolean requireATH,
					  final SingleUseChecker<Map.Entry<DPoPIssuer, JWTID>> singleUseChecker) {

		super(null,
			composeExactMatchClaims(acceptedURI, acceptedMethod),
			composedRequiredClaimsWithAnyValue(CollectionUtils.isNotEmpty(acceptedNonces), requireATH),
			composeProhibitedClaims(CollectionUtils.isEmpty(acceptedNonces))
		);

		this.maxClockSkewSeconds = maxClockSkewSeconds;
		this.maxAgeSeconds = 0;

		this.acceptedNonces = CollectionUtils.isNotEmpty(acceptedNonces) ? Collections.unmodifiableSet(acceptedNonces) : null;

		this.singleUseChecker = null;
		this.deprecatedSingleUseChecker = singleUseChecker;
	}


	private static JWTClaimsSet composeExactMatchClaims(final URI uri, final String method) {
		JWTClaimsSet.Builder b = new JWTClaimsSet.Builder()
			.claim("htm", method)
			.claim("htu", URIUtils.getBaseURI(uri).toString());
		return b.build();
	}


	private static Set<String> composedRequiredClaimsWithAnyValue(final boolean requireNonce, final boolean requireATH) {
                Set<String> claimNames = new HashSet<>(Arrays.asList("jti", "iat"));
		if (requireNonce) {
			claimNames.add("nonce");
		}
		if (requireATH) {
			claimNames.add("ath");
		}
		return Collections.unmodifiableSet(claimNames);
	}


	private static Set<String> composeProhibitedClaims(final boolean prohibitNonce) {
		return prohibitNonce ? Collections.singleton("nonce") : null;
	}


	@Override
	public void verify(final JWTClaimsSet claimsSet,
			   final DPoPProofContext context)
		throws BadJWTException {

		context.setJWTClaimsSet(claimsSet);

		super.verify(claimsSet, context);

		// Check time window
		Date iat = claimsSet.getIssueTime();

		final Date now = new Date();

		long maxPastSecs = Math.max(maxClockSkewSeconds, maxAgeSeconds);
		Date maxPast = new Date(now.getTime() - maxPastSecs * 1000L);

		if (iat.before(maxPast)) {
			throw new BadJWTException("DPoP proof iat too old (>" + maxPastSecs + "s)");
		}

		Date maxFuture = new Date(now.getTime() + maxClockSkewSeconds * 1000L);

		if (iat.after(maxFuture)) {
			throw new BadJWTException("DPoP proof iat too far in future (>" + maxClockSkewSeconds + "s)");
		}

		// Check nonce(s)
		if (CollectionUtils.isNotEmpty(acceptedNonces)) {
			Nonce nonce;
                        try {
                                nonce = new Nonce(claimsSet.getStringClaim("nonce"));
                        } catch (ParseException | IllegalArgumentException e) {
                                throw new BadJWTException("Illegal JWT nonce claim");
                        }

                        if (! acceptedNonces.contains(nonce)) {
				throw new BadJWTException("JWT nonce claim value rejected");
			}
		}

		if (singleUseChecker != null || deprecatedSingleUseChecker != null) {

			JWTID jti = new JWTID(claimsSet.getJWTID());

			try {
				if (singleUseChecker != null) {
					singleUseChecker.markAsUsed(new DPoPProofUse(context.getIssuer(), jti, maxAgeSeconds));
				} else {
					deprecatedSingleUseChecker.markAsUsed(new AbstractMap.SimpleImmutableEntry<>(context.getIssuer(), jti));
				}
			} catch (AlreadyUsedException e) {
				throw new BadJWTException("The jti was already used in the past " + maxAgeSeconds + " seconds");
			}
		}

		if (getRequiredClaims().contains("ath")) {
			Base64URL ath;
			try {
				String athValue = claimsSet.getStringClaim("ath");
				if (StringUtils.isBlank(athValue)) {
					throw new BadJWTException("Missing JWT ath claim");
				}
				ath = new Base64URL(athValue);
			} catch (ParseException e) {
				throw new BadJWTException("Illegal JWT ath claim", e);
			}
			context.setAccessTokenHash(ath);
		}
	}
}
