/*
 * oauth2-oidc-sdk
 *
 * Copyright 2012-2024, Connect2id Ltd and contributors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use
 * this file except in compliance with the License. You may obtain a copy of the
 * License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed
 * under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
 * CONDITIONS OF ANY KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations under the License.
 */

package com.nimbusds.oauth2.sdk.auth;


import com.nimbusds.oauth2.sdk.ParseException;
import com.nimbusds.oauth2.sdk.id.ClientID;

import java.util.Collection;
import java.util.Iterator;


/**
 * Client authentication utility methods.
 */
class Utils {


	/**
	 * Ensures that all client authentication candidates share the same
	 * {@code client_id}.
	 *
	 * @param candidates The client authentication candidates. Must not
	 *                   be {@code null} or empty.
	 *
	 * @return The common client ID.
	 *
	 * @throws ParseException If the candidates have different client IDs.
	 */
	static ClientID ensureSameClientID(final Collection<? extends ClientAuthentication> candidates)
		throws ParseException {

		Iterator<? extends ClientAuthentication> it = candidates.iterator();
		ClientID clientID = it.next().getClientID();

		while (it.hasNext()) {

			ClientID otherID = it.next().getClientID();

			if (! clientID.equals(otherID)) {
				throw new ParseException("The client authentication methods have different client_id values");
			}
		}

		return clientID;
	}


	private Utils() { }
}
