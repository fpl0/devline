/*
 * oauth2-oidc-sdk
 *
 * Copyright 2012-2026, Connect2id Ltd and contributors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use
 * this file except in compliance with the License. You may obtain a copy of the
 * License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed
 * under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
 * CONDITIONS OF ANY KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations under the License.
 */

package com.nimbusds.oauth2.sdk;


import com.nimbusds.common.contenttype.ContentType;
import com.nimbusds.oauth2.sdk.auth.ClientAuthentication;
import com.nimbusds.oauth2.sdk.http.HTTPRequest;
import com.nimbusds.oauth2.sdk.id.ClientID;
import com.nimbusds.oauth2.sdk.util.CollectionUtils;
import com.nimbusds.oauth2.sdk.util.URLUtils;
import com.nimbusds.openid.connect.sdk.AuthenticationRequest;
import com.nimbusds.openid.connect.sdk.op.AuthenticationRequestDetector;
import net.jcip.annotations.Immutable;

import java.net.URI;
import java.util.*;


/**
 * Pushed authorisation request (PAR).
 *
 * <p>Example HTTP request:
 *
 * <pre>
 * POST /as/par HTTP/1.1
 * Host: as.example.com
 * Content-Type: application/x-www-form-urlencoded
 * Authorization: Basic czZCaGRSa3F0Mzo3RmpmcDBaQnIxS3REUmJuZlZkbUl3
 *
 * response_type=code
 * &amp;client_id=s6BhdRkqt3
 * &amp;state=af0ifjsldkj
 * &amp;redirect_uri=https%3A%2F%2Fclient.example.org%2Fcb
 * </pre>
 *
 * <p>Related specifications:
 *
 * <ul>
 *     <li>OAuth 2.0 Pushed Authorization Requests (RFC 9126)
 * </ul>
 */
@Immutable
public class PushedAuthorizationRequest extends AbstractOptionallyAuthenticatedRequest {


	/**
	 * The pushed authorisation request.
	 */
	private final AuthorizationRequest authzRequest;


	/**
	 * Creates a new pushed authorisation request for a confidential
	 * client.
	 *
	 * @param endpoint     The URI of the PAR endpoint. May be
	 *                     {@code null} if the {@link #toHTTPRequest}
	 *                     method is not going to be used.
	 * @param clientAuth   The client authentication. Must not be
	 *                     {@code null}.
	 * @param authzRequest The authorisation request. Must not be
	 *                     {@code null}.
	 */
	public PushedAuthorizationRequest(final URI endpoint,
					  final ClientAuthentication clientAuth,
					  final AuthorizationRequest authzRequest) {
		this(endpoint, Collections.singletonList(clientAuth), authzRequest);
	}


	/**
	 * Creates a new pushed authorisation request for a confidential
	 * client.
	 *
	 * @param endpoint             The URI of the PAR endpoint. May be
	 *                             {@code null} if the
	 *                             {@link #toHTTPRequest} method is not
	 *                             going to be used.
	 * @param clientAuthCandidates The client authentication candidates.
	 *                             Must not be {@code null}.
	 * @param authzRequest         The authorisation request. Must not be
	 *                             {@code null}.
	 */
	public PushedAuthorizationRequest(final URI endpoint,
					  final List<ClientAuthentication> clientAuthCandidates,
					  final AuthorizationRequest authzRequest) {
		super(endpoint, Objects.requireNonNull(clientAuthCandidates));
		for (ClientAuthentication ca: clientAuthCandidates) {
			Objects.requireNonNull(ca);
		}

		if (authzRequest.getRequestURI() != null) {
			throw new IllegalArgumentException("The request_uri parameter is prohibited");
		}
		this.authzRequest = authzRequest;
	}


	/**
	 * Creates a new pushed authorisation request for a public client.
	 *
	 * @param endpoint     The URI of the PAR endpoint. May be
	 *                     {@code null} if the {@link #toHTTPRequest}
	 *                     method is not going to be used.
	 * @param authzRequest The authorisation request. Must not be
	 *                     {@code null}.
	 */
	public PushedAuthorizationRequest(final URI endpoint,
					  final AuthorizationRequest authzRequest) {

		super(endpoint, (ClientAuthentication) null);
		if (authzRequest.getRequestURI() != null) {
			throw new IllegalArgumentException("The request_uri parameter is prohibited");
		}
		this.authzRequest = authzRequest;
	}


	/**
	 * Returns the pushed authorisation request.
	 *
	 * @return The pushed authorisation request.
	 */
	public AuthorizationRequest getAuthorizationRequest() {
		return authzRequest;
	}


	@Override
	public HTTPRequest toHTTPRequest() {

		if (getEndpointURI() == null)
			throw new SerializeException("The endpoint URI is not specified");

		HTTPRequest httpRequest = new HTTPRequest(HTTPRequest.Method.POST, getEndpointURI());
		httpRequest.setEntityContentType(ContentType.APPLICATION_URLENCODED);

		if (getClientAuthentication() != null) {
			for (ClientAuthentication ca: getClientAuthenticationCandidates()) {
				ca.applyTo(httpRequest);
			}
		}

		Map<String, List<String>> params;
		try {
			params = new LinkedHashMap<>(httpRequest.getBodyAsFormParameters());
		} catch (ParseException e) {
			throw new SerializeException(e.getMessage(), e);
		}
		params.putAll(authzRequest.toParameters());
		httpRequest.setBody(URLUtils.serializeParameters(params));

		return httpRequest;
	}


	/**
	 * Parses a pushed authorisation request from the specified HTTP
	 * request.
	 *
	 * @param httpRequest The HTTP request. Must not be {@code null}.
	 *
	 * @return The pushed authorisation request.
	 *
	 * @throws ParseException If the HTTP request couldn't be parsed to a
	 *                        pushed authorisation request.
	 */
	public static PushedAuthorizationRequest parse(final HTTPRequest httpRequest)
		throws ParseException {

		// Only HTTP POST accepted
		URI uri = httpRequest.getURI();
		httpRequest.ensureMethod(HTTPRequest.Method.POST);
		httpRequest.ensureEntityContentType(ContentType.APPLICATION_URLENCODED);

		// Parse client authentication candidates, if any
		List<ClientAuthentication> clientAuthCandidates;
		try {
			clientAuthCandidates = ClientAuthentication.parseCandidates(httpRequest);
		} catch (ParseException e) {
			throw new ParseException(e.getMessage(), OAuth2Error.INVALID_REQUEST.appendDescription(": " + e.getMessage()));
		}

		// No fragment! May use query component!
		Map<String,List<String>> params = httpRequest.getBodyAsFormParameters();

		if (CollectionUtils.isNotEmpty(clientAuthCandidates)) {

			ClientID clientID = null;
			for (ClientAuthentication ca: clientAuthCandidates) {
				if (ca ==  null) {
					continue;
				}
				clientID = ca.getClientID();
				for (String paramName: ca.getFormParameterNames()) {
					// strip form params for client auth
					params.remove(paramName);
				}
			}

			// client_id not required in authZ params if auth is present
			if (! params.containsKey("client_id") && clientID != null) {
				params.put("client_id", Collections.singletonList(clientID.getValue()));
			}
		}

		// Parse the authZ request, allow for OpenID
		AuthorizationRequest authzRequest;
		if (AuthenticationRequestDetector.isLikelyOpenID(params)) {
			authzRequest = AuthenticationRequest.parse(params);
		} else {
			authzRequest = AuthorizationRequest.parse(params);
		}

		if (authzRequest.getRequestURI() != null) {
			String msg = "The request_uri parameter is prohibited";
			throw new ParseException(msg, OAuth2Error.INVALID_REQUEST.appendDescription(": " + msg));
		}

		if (CollectionUtils.isNotEmpty(clientAuthCandidates)) {
			return new PushedAuthorizationRequest(uri, clientAuthCandidates, authzRequest);
		} else {
			return new PushedAuthorizationRequest(uri, authzRequest);
		}
	}
}
