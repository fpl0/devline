/*
 * oauth2-oidc-sdk
 *
 * Copyright 2012-2026 Connect2id Ltd and contributors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use
 * this file except in compliance with the License. You may obtain a copy of the
 * License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed
 * under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
 * CONDITIONS OF ANY KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations under the License.
 */

package com.nimbusds.oauth2.sdk.util;


import com.nimbusds.common.contenttype.ContentType;
import com.nimbusds.jose.JWEObject;
import com.nimbusds.jwt.proc.BadJWTException;

import java.util.Locale;


/**
 * JSON Web Token (JWT) utilities.
 */
public final class JWTUtils {


        /**
         * Ensures the JWE {@code cty} (content type) header of a nested
         * encrypted JWT is {@code JWT}.
         *
         * <p>See RFC 7519, section 5.2.
         *
         * @param jweObject The encrypted JWT. Must not be {@code null}.
         *
         * @throws BadJWTException If the content type of the nested JWT is
         *                         not {@code JWT}.
         */
        public static void ensureContentTypeForNestedJWT(final JWEObject jweObject)
                throws BadJWTException {

                if (! ContentType.APPLICATION_JWT.getSubType().equalsIgnoreCase(jweObject.getHeader().getContentType())) {
                        throw new BadJWTException("The JWE cty (content type) header of a nested encrypted JWT must be " +
                                ContentType.APPLICATION_JWT.getSubType().toUpperCase(Locale.ROOT));
                }
        }


        /**
         * Prevents public instantiation.
         */
        private JWTUtils() {}
}
