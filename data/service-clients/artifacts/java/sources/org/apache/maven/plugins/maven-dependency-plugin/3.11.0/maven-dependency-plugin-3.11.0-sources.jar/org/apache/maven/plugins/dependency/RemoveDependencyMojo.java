/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
package org.apache.maven.plugins.dependency;

import javax.inject.Inject;

import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.Locale;

import eu.maveniverse.domtrip.Document;
import eu.maveniverse.domtrip.Element;
import eu.maveniverse.domtrip.maven.Coordinates;
import eu.maveniverse.domtrip.maven.PomEditor;
import org.apache.maven.execution.MavenSession;
import org.apache.maven.model.Dependency;
import org.apache.maven.model.DependencyManagement;
import org.apache.maven.model.Model;
import org.apache.maven.model.io.xpp3.MavenXpp3Reader;
import org.apache.maven.plugin.MojoExecutionException;
import org.apache.maven.plugin.MojoFailureException;
import org.apache.maven.plugins.annotations.Mojo;
import org.apache.maven.plugins.annotations.Parameter;
import org.apache.maven.plugins.dependency.pom.DependencyEntry;
import org.apache.maven.project.MavenProject;
import org.codehaus.plexus.util.xml.XmlStreamReader;
import org.codehaus.plexus.util.xml.pull.XmlPullParserException;
import org.sonatype.plexus.build.incremental.BuildContext;

/**
 * Removes a dependency from the project's {@code pom.xml}.
 * Supports removing from {@code <dependencies>} or {@code <dependencyManagement>}.
 *
 * <p>Matching uses groupId, artifactId, type, and classifier for precision.
 * If the dependency exists in Maven's resolved model but uses property references
 * in the raw POM, a clear error directs the user to edit manually.</p>
 * When removing a managed dependency from a parent POM, warns if child modules
 * reference it without an explicit version.
 *
 * @since 3.11.0
 */
@Mojo(name = "remove", requiresProject = true, threadSafe = true)
public class RemoveDependencyMojo extends AbstractDependencyMojo {

    /**
     * Dependency coordinates: {@code groupId:artifactId[:version]}
     * or {@code groupId:artifactId[:extension[:classifier]]:version}.
     * Only groupId and artifactId are required. Type and classifier, if provided,
     * are used for precise matching when multiple dependency variants exist
     * (e.g., jar vs test-jar).
     *
     * @since 3.11.0
     */
    @Parameter(property = "gav")
    private String gav;

    /**
     * When {@code true}, remove from {@code <dependencyManagement>} instead of {@code <dependencies>}.
     *
     * @since 3.11.0
     */
    @Parameter(property = "managed", defaultValue = "false")
    private boolean managed;

    /**
     * Dependency type for precise matching (e.g., {@code pom}, {@code war}, {@code test-jar}).
     * When not specified, defaults to {@code "jar"}.
     *
     * @since 3.11.0
     */
    @Parameter(property = "type")
    private String type;

    /**
     * Dependency classifier for precise matching (e.g., {@code sources}, {@code javadoc}, {@code tests}).
     *
     * @since 3.11.0
     */
    @Parameter(property = "classifier")
    private String classifier;

    /**
     * Target a specific Maven profile by its {@code <id>}. When set, the dependency is removed
     * from the profile's {@code <dependencies>} or {@code <dependencyManagement>} section.
     * The profile must already exist in the POM.
     *
     * @since 3.11.0
     */
    @Parameter(property = "profile")
    private String profile;

    @Inject
    public RemoveDependencyMojo(MavenSession session, BuildContext buildContext, MavenProject project) {
        super(session, buildContext, project);
    }

    @Override
    protected void doExecute() throws MojoExecutionException, MojoFailureException {
        DependencyEntry coords = resolveCoordinates();

        boolean targetManaged = managed;
        MavenProject targetProject = getProject();
        File pomFile = targetProject.getFile();
        if (pomFile == null) {
            throw new MojoExecutionException("Cannot remove dependency: project has no POM file to modify.");
        }

        // Safety check for managed dependency removal in parent POM
        if (targetManaged
                && targetProject.getModules() != null
                && !targetProject.getModules().isEmpty()) {
            checkChildModuleDependencies(targetProject, coords.getGroupId(), coords.getArtifactId());
        }

        try {
            PomEditor editor = loadPomEditor(pomFile);
            PomEditor.Dependencies dependencies = dependenciesFor(editor, pomFile);
            Coordinates coordinates = Coordinates.of(
                    coords.getGroupId(), coords.getArtifactId(), null, coords.getClassifier(), coords.getType());
            boolean removed = targetManaged
                    ? dependencies.deleteManagedDependency(coordinates)
                    : dependencies.deleteDependency(coordinates);

            if (!removed) {
                // Cross-reference with resolved model to detect property-interpolated coords
                if (existsInResolvedModel(targetProject, coords, targetManaged)) {
                    String section = targetManaged ? "<dependencyManagement>" : "<dependencies>";
                    throw new MojoFailureException("Dependency " + coords.getGroupId() + ":"
                            + coords.getArtifactId()
                            + " exists in " + section + " but uses property references in the POM. "
                            + "Please remove it manually.");
                }
                String section = targetManaged ? "<dependencyManagement>" : "<dependencies>";
                throw new MojoFailureException("Dependency " + coords.getGroupId() + ":" + coords.getArtifactId()
                        + " not found in " + section + ".");
            }

            savePomEditor(editor, pomFile);

            // Sync in-memory model so chained goals see the change
            Model model = targetProject.getModel();
            if (model != null) {
                String removeType =
                        (coords.getType() != null && !coords.getType().isEmpty()) ? coords.getType() : "jar";
                String removeClassifier = (coords.getClassifier() != null
                                && !coords.getClassifier().isEmpty())
                        ? coords.getClassifier()
                        : "";
                if (targetManaged) {
                    DependencyManagement dm = model.getDependencyManagement();
                    if (dm != null && dm.getDependencies() != null) {
                        dm.getDependencies()
                                .removeIf(d -> coords.getGroupId().equals(d.getGroupId())
                                        && coords.getArtifactId().equals(d.getArtifactId())
                                        && removeType.equals(d.getType() != null ? d.getType() : "jar")
                                        && removeClassifier.equals(d.getClassifier() != null ? d.getClassifier() : ""));
                    }
                } else if (model.getDependencies() != null) {
                    model.getDependencies()
                            .removeIf(d -> coords.getGroupId().equals(d.getGroupId())
                                    && coords.getArtifactId().equals(d.getArtifactId())
                                    && removeType.equals(d.getType() != null ? d.getType() : "jar")
                                    && removeClassifier.equals(d.getClassifier() != null ? d.getClassifier() : ""));
                }
            }

            getLog().info("Removed dependency " + coords.getGroupId() + ":" + coords.getArtifactId() + " from "
                    + pomFile.getName());
        } catch (IOException e) {
            throw new MojoExecutionException("Failed to modify POM file: " + pomFile, e);
        }
    }

    private PomEditor.Dependencies dependenciesFor(PomEditor editor, File pomFile) throws MojoFailureException {
        PomEditor.Dependencies dependencies = editor.dependencies();
        if (profile == null || profile.isEmpty()) {
            return dependencies;
        }
        Element profileElement = editor.profiles().findProfile(profile);
        if (profileElement == null) {
            throw new MojoFailureException("Profile '" + profile + "' not found in " + pomFile.getName() + ".");
        }
        return dependencies.forProfile(profileElement);
    }

    private static PomEditor loadPomEditor(File pomFile) throws IOException {
        try {
            String content = new String(Files.readAllBytes(pomFile.toPath()), StandardCharsets.UTF_8);
            String upper = content.toUpperCase(Locale.ROOT);
            if (upper.contains("<!DOCTYPE") || upper.contains("<!ENTITY")) {
                throw new IOException("DOCTYPE/ENTITY declarations are not allowed in POM files (security risk)");
            }

            PomEditor editor = new PomEditor(Document.of(pomFile.toPath()));
            String rootName = editor.root().name();
            if (!"project".equals(rootName)) {
                throw new IOException(
                        "Not a valid POM file: expected <project> root element but found <" + rootName + ">");
            }
            return editor;
        } catch (RuntimeException e) {
            throw new IOException("Failed to parse POM file: " + pomFile, e);
        }
    }

    private static void savePomEditor(PomEditor editor, File pomFile) throws IOException {
        Path target = pomFile.toPath();
        File tempFile = File.createTempFile("pom", ".xml.tmp", pomFile.getParentFile());
        boolean success = false;
        try {
            try (OutputStream os = Files.newOutputStream(tempFile.toPath())) {
                editor.document().toXml(os);
            }
            Files.move(tempFile.toPath(), target, StandardCopyOption.REPLACE_EXISTING);
            success = true;
        } finally {
            if (!success) {
                Files.deleteIfExists(tempFile.toPath());
            }
        }
    }

    private DependencyEntry resolveCoordinates() throws MojoFailureException {
        if (gav == null || gav.isEmpty()) {
            throw new MojoFailureException("You must specify -Dgav=groupId:artifactId");
        }

        DependencyEntry coords;
        try {
            coords = DependencyEntry.parse(gav);
        } catch (IllegalArgumentException e) {
            throw new MojoFailureException(e.getMessage());
        }

        // Explicit parameters override GAV shorthand values
        if (type != null) {
            coords.setType(type);
        }
        if (classifier != null) {
            coords.setClassifier(classifier);
        }

        try {
            coords.validate();
        } catch (IllegalArgumentException e) {
            throw new MojoFailureException(e.getMessage());
        }

        return coords;
    }

    private void checkChildModuleDependencies(MavenProject parentProject, String depGroupId, String depArtifactId)
            throws MojoExecutionException {
        if (parentProject.getBasedir() == null) {
            getLog().debug("Parent project basedir is null, skipping child module dependency check");
            return;
        }
        StringBuilder affected = new StringBuilder();
        MavenXpp3Reader pomReader = new MavenXpp3Reader();

        for (String moduleName : parentProject.getModules()) {
            File modulePom = resolveModulePom(parentProject.getBasedir(), moduleName);
            if (!modulePom.exists()) {
                continue;
            }
            try (Reader reader = new XmlStreamReader(modulePom)) {
                Model model = pomReader.read(reader);
                if (model.getDependencies() != null) {
                    for (Dependency dep : model.getDependencies()) {
                        if (depGroupId.equals(dep.getGroupId())
                                && depArtifactId.equals(dep.getArtifactId())
                                && (dep.getVersion() == null || dep.getVersion().isEmpty())) {
                            if (affected.length() > 0) {
                                affected.append(", ");
                            }
                            affected.append(moduleName);
                            break;
                        }
                    }
                }
            } catch (IOException | XmlPullParserException e) {
                getLog().debug("Could not read module POM: " + modulePom + " - " + e.getMessage());
            }
        }

        if (affected.length() > 0) {
            getLog().warn("The following child modules depend on " + depGroupId + ":" + depArtifactId
                    + " without an explicit version and will break: [" + affected + "]. Proceeding with removal.");
        }
    }

    private static File resolveModulePom(File parentBasedir, String moduleName) {
        File modulePath = new File(parentBasedir, moduleName);
        if (modulePath.isFile() || moduleName.endsWith(".xml")) {
            return modulePath;
        }
        return new File(modulePath, "pom.xml");
    }
}
