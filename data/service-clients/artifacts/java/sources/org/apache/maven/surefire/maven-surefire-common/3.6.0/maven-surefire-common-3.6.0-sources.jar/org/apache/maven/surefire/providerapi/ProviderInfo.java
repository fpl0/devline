/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
package org.apache.maven.surefire.providerapi;

import javax.annotation.Nonnull;

import java.util.List;
import java.util.Set;

import org.apache.maven.artifact.Artifact;
import org.apache.maven.plugin.MojoExecutionException;
import org.apache.maven.plugin.surefire.TestClassPath;

import static org.apache.maven.plugin.surefire.SurefireDependencyResolver.isWithinVersionSpec;

/**
 * @author Kristian Rosenvold
 */
public interface ProviderInfo {

    enum Engine {
        JUNIT3,
        JUNIT4,
        TESTNG,
        JUNIT_PLATFORM
    }

    @Nonnull
    String getProviderName();

    boolean isApplicable();

    @Nonnull
    Set<Artifact> getProviderClasspath() throws MojoExecutionException;

    void addProviderProperties() throws MojoExecutionException;

    @Nonnull
    List<String[]> getJpmsArguments(@Nonnull ProviderRequirements forkRequirements);

    default boolean isAnyJunit4(Artifact artifact) {
        return isWithinVersionSpec(artifact, "[4.12,)");
    }

    default TestClassPath decorateTestClassPath(TestClassPath testClasspath) throws MojoExecutionException {
        // no op
        return testClasspath;
    }
}
