/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
package org.apache.maven.plugins.dependency.fromDependencies;

import java.util.ArrayList;
import java.util.Collection;

import org.apache.maven.model.Dependency;

class OrDependencyMatcher implements DependencyMatcher {

    private Collection<DependencyMatcher> matchers;

    OrDependencyMatcher(Collection<DependencyMatcher> matchers) {
        this.matchers = new ArrayList<>(validate(matchers));
    }

    private Collection<DependencyMatcher> validate(Collection<DependencyMatcher> matchers) {
        if (matchers == null || matchers.isEmpty()) {
            throw new IllegalArgumentException("There must be at least 1 dependencyMatcher");
        }
        return matchers;
    }

    @Override
    public boolean matches(Dependency dependency) {
        for (DependencyMatcher matcher : matchers) {
            if (matcher.matches(dependency)) {
                return true;
            }
        }
        return false;
    }
}
