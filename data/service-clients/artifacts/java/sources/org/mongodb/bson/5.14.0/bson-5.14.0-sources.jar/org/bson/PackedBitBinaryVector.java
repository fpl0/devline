/*
 * Copyright 2008-present MongoDB, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.bson;

import org.bson.annotations.Beta;
import org.bson.annotations.Reason;

import java.util.Arrays;
import java.util.Objects;

import static org.bson.assertions.Assertions.assertNotNull;
import static org.bson.assertions.Assertions.isTrueArgument;
import static org.bson.assertions.Assertions.notNull;

/**
 * Represents a packed bit vector, where each element of the vector is represented by a single bit (0 or 1).
 * <p>
 * The {@link PackedBitBinaryVector} is used to store data efficiently using the BSON Binary Subtype 9 format.
 *
 * @mongodb.server.release 6.0
 * @see BinaryVector#packedBitVector(byte[], byte)
 * @see BsonBinary#BsonBinary(BinaryVector)
 * @see BsonBinary#asVector()
 * @since 5.3
 */
@Beta(Reason.SERVER)
public final class PackedBitBinaryVector extends BinaryVector {

    private final byte padding;
    private final byte[] data;

    PackedBitBinaryVector(final byte[] data, final byte padding) {
        super(DataType.PACKED_BIT);
        this.data = notNull("data", data);
        this.padding = padding;
        isTrueArgument("Padding must be between 0 and 7 bits. Provided padding: " + padding, padding >= 0 && padding <= 7);
        isTrueArgument("Padding must be 0 if vector is empty. Provided padding: " + padding, padding == 0 || data.length > 0);
        if (padding > 0) {
            int mask = (1 << padding) - 1;
            if ((data[data.length - 1] & mask) != 0) {
                // JAVA-5848 in version 6.0.0 will convert this logging into an IllegalArgumentException
                LOGGER.warn("The last " + padding + " padded bits should be zero in the final byte.");
            }
        }
    }

    /**
     * Retrieve the underlying byte array representing this {@link PackedBitBinaryVector} vector, where
     * each bit represents an element of the vector (either 0 or 1).
     * <p>
     * Note that the {@linkplain #getPadding() padding value} should be considered when interpreting the final byte of the array,
     * as it indicates how many least-significant bits are to be ignored.
     *
     * @return the underlying byte array representing this {@link PackedBitBinaryVector} vector.
     * @see #getPadding()
     */
    public byte[] getData() {
        return assertNotNull(data);
    }

    /**
     * Returns the padding value for this vector.
     *
     * <p>Padding refers to the number of least-significant bits in the final byte that are ignored when retrieving
     * {@linkplain #getData() the vector array}. For instance, if the padding value is 3, this means that the last byte contains
     * 3 least-significant unused bits, which should be disregarded during operations.</p>
     * <p>
     *
     * NOTE: The underlying byte array is not copied; changes to the returned array will be reflected in this instance.
     *
     * @return the padding value (between 0 and 7).
     */
    public byte getPadding() {
        return this.padding;
    }

    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        PackedBitBinaryVector that = (PackedBitBinaryVector) o;
        return padding == that.padding && Arrays.equals(data, that.data);
    }

    @Override
    public int hashCode() {
        return Objects.hash(padding, Arrays.hashCode(data));
    }

    @Override
    public String toString() {
        return "PackedBitVector{"
                + "padding=" + padding
                + ", data=" + Arrays.toString(data)
                + ", dataType=" + getDataType()
                + '}';
    }
}
